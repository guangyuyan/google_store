#!/bin/sh
day=`date -d "1 hour ago" +"%Y-%m-%d"`
hour=`date -d "1 hour ago" +"%H"`

echo $day
echo $hour

if [ ! -d "/home/wllu/data/cpc_v1_online_8/tfrecords/$day" ]; then
  mkdir /home/wllu/data/cpc_v1_online_8/tfrecords/$day
fi


hadoop fs -get /user/yzliu/data/cpc_v1_online_7_ns02/tfrecord/$day/$hour /home/wllu/data/cpc_v1_online_8/tfrecords/$day


python /home/wllu/schedule/generate_config_files_hourly.py "$day" /home/wllu/data/cpc_v1_online_8/tfrecords/
python /home/wllu/schedule/generate_config_files_hourly_fixed_steps.py "$day" /home/wllu/data/cpc_v1_online_8/tfrecords/
python /home/wllu/schedule/generate_config_files_hourly_post_fit.py "$day" /home/wllu/data/cpc_v1_online_8/tfrecords/