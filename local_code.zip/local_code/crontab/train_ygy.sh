#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v8
base_dir=./run/vivo
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/vivo/train_ygy.sh ${summaries_dir}

day=`date -d "1 hour ago" +"%Y-%m-%d"`
hour=`date -d "1 hour ago" +"%H"`

dir_tail=$day'_'$hour


CUDA_VISIBLE_DEVICES=$2 python -m module.vivo.trainer \
  --model ${model_ver} \
  --model_name ${model_ver}_$1 \
  --output_transform_exponent 1.0819 \
  --output_transform_scale 1.6104 \
  --deep_layers 512,256 \
  --cross_layers 2 \
  --learning_rate 0.0002 \
  --epochs 10 \
  --data_per_valid 5000000 \
  --patient_valid_passes 5 \
  --train_data /home/wllu/data/cfg/split_data_train/$dir_tail \
  --valid_data /home/wllu/data/cfg/split_data_valid/$dir_tail \
  --prebatch 256 \
  --batch_size 128 \
  --parallel_parse 16 \
  --parallel_reads_per_file 16 \
  --interleave_cycle 16 \
  --prefetch_buffer 2048 \
  --shuffle_buffer 1024 \
  --model_path ${outputs_dir} \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:2} \
  2>&1 | tee ${summaries_dir}/$1.log
