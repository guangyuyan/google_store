#!/usr/bin/env python
import csv
import os
import pandas as pd
print(os.getcwd())
df = pd.read_csv('./feature_list_bak.csv')
#featuresmap = dict()
#f = open('feature_map.py', 'w', encoding='utf-8')
feat = list()
for index, row in df.iterrows():
    if row['len'] > 1:
        for i in range(int(row['len'])):
            feat.append(row['feature']+str(i))    
    else:
        feat.append(row['feature'])
print(len(feat))
f = open('feature_1119.txt', 'w')
#wr = csv.writer(f, quoting=csv.QUOTE_ALL)
wr = csv.writer(f)
wr.writerow(feat)
