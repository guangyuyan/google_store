#!/usr/bin/env python3
import lightgbm as lgb

raw_data = 'tf2csv_valid.libsvm' 
train_data = lgb.Dataset(raw_data)
train_data.save_binary('tf2csv_valid.libsvmbin')
