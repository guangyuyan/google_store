import phraug.csv2libsvm
nohup python3 ./phraug/csv2libsvm.py tf2csv_train.csv tf2csv_train.libsvm 0 False 2>&1 &
