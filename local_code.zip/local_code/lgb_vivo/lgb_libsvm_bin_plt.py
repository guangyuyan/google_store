#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <fuhl@>
#
# Distributed under terms of the CloudBrain license.

"""
LightGBM model: Train a LightGBM model for binary classification, and generate feature importance
"""

import os
import argparse
import lightgbm as lgb

import matplotlib
import pandas as pd
matplotlib.use('agg')
import matplotlib.pyplot as plt

outputs_dir = 'lightgbm_1024_dir'

# create dataset for lightgbm
train_raw_data = './data/tf2csv_train.libsvmbin'
#valid_raw_data = './data/tf2csv_valid.libsvmbin'
header_file = open('header.txt','r')
header_list = header_file.read().split(',')
#header_list[-1]= 'ad_time_dur23'
train_data = lgb.Dataset(train_raw_data, feature_name = header_list, categorical_feature=header_list[1:56],free_raw_data=False)
#test_data = train_data.create_valid(valid_raw_data)
#test_data = lgb.Dataset(valid_raw_data, reference=train_data)

# specify your configurations as a dict
params = {
    'boosting_type': 'gbdt',
    'objective': 'binary',
    'metric': {'auc', 'binary_logloss'},
    # (int, optional (default=31)) – Maximum tree leaves for base learners.
    'num_leaves': 1023,
    'learning_rate': 0.05,
    # (int, optional (default=-1)) – Maximum tree depth for base learners, -1 means no limit.
    'max_depth': 10,
}
# feature_name and categorical_feature
'''
gbm = lgb.train(params,
                train_data,
                num_boost_round=2000,
                valid_sets=[test_data],  # eval training data
                early_stopping_rounds=5)
'''
print('Start making cross validation set...')
lgb.cv(params, train_data, num_boost_round = 2000, nfold=5, early_stopping_rounds=3)
print('Start training...')
bst = lgb.train(params, train_data, num_boost_round=2000)
# save model to file
print('Save model...')
bst.save_model('model.txt', num_iteration=bst.best_iteration)
print('Saved model!')

# *******importance_type = 'spilt' ************************
print('Start importance analysis...')
importance = bst.feature_importance(importance_type='split')
feature_name = bst.feature_name()
feature_importance = pd.DataFrame({'feature_name': feature_name, 'importance': importance})
feature_importance.to_csv(outputs_dir + '/lgb_feature_importance_spilt.csv', index=False)

plt.figure(figsize=(40, 15))
lgb.plot_importance(bst, max_num_features=30)
plt.title("Feature importance (spilt)")
foo_fig = plt.gcf()  # 'get current figure'
foo_fig.savefig(outputs_dir + '/lgb_feature_importance_spilt.eps', format='eps', dpi=2000)
plt.savefig(outputs_dir + '/lgb_feature_importance_spilt.png')
# *******  importance_type = 'gain' ************************
print('Start gain analysis...')
importance = bst.feature_importance(importance_type='gain')
feature_name = bst.feature_name()
feature_importance = pd.DataFrame({'feature_name': feature_name, 'importance': importance})
feature_importance.to_csv(outputs_dir + '/lgb_feature_importance_gain.csv', index=False)

plt.figure(figsize=(40, 15))
lgb.plot_importance(bst, max_num_features=30)
plt.title("Feature importance (gain)")
foo_fig = plt.gcf()  # 'get current figure'
foo_fig.savefig(outputs_dir + '/lgb_feature_importance_gain.eps', format='eps', dpi=2000)
plt.savefig(outputs_dir + '/lgb_feature_importance_gain.png')
print('end')
