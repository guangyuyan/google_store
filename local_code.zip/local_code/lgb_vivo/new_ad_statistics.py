#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

'''
transform tfrecords file to csv, and statistics ad life hours 
'''

import os
import tensorflow as tf
import numpy as np
import pickle
import pandas as pd
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from collections import Counter
from module.vivo.model_v0 import BaseVivoDXLModel

os.environ["CUDA_VISIBLE_DEVICES"]="5"

batch_size = 101
dim = batch_size*256

def load_data_from_file(sess,  model_class, work_dir):
    data_iterator = model_class.tfrecord_pipeline(
        model_class.read_list_from_file(work_dir),
        batch_size,
        epochs=1,
        shuffle=False).make_initializable_iterator()
    sess.run(data_iterator.initializer)

    raw_features, raw_labels = model_class.reshape_input(
        data_iterator.get_next())
    model_class.reshape_sparse2dense(raw_features)
    for key, feature in raw_features.copy().items():
        if isinstance(feature, dict):
            raw_features.pop(key)
            for subkey in feature:
                raw_features[key+subkey] = feature[subkey]

    result_base = {}
    result = {}
    try:
        count = 1    
        while True:
            features = sess.run(raw_features)
            explode_count = Counter(features['ad_explode_time'][:,0])
#            print('Processing batch count: ', count)
            result_base = Counter(result_base)
            result_base = dict(result_base + explode_count)
            count = count + 1
    except tf.errors.OutOfRangeError:
        print("Index out of range")
    return result_base

def main(model_class):
    for hour in range(6):
        work_dir = '/home/wllu/cb/prj_vivo_dxl_fhl/deep_cross/cfg/cpc_yunnao_5-2018-11-12/test_0'+str(hour)
#        print('Start to process data: ', work_dir) 
        if not work_dir:
            print('Please specify work directory')
            return
        with tf.Session() as sess:
            data = load_data_from_file(sess, model_class, work_dir)
#            for k,v in data.items():
#                print(k)
#                print(v)
#            print(data)
            df = pd.DataFrame(sorted(data.items(),key=lambda x:x[0]))
            df_transpose = df.T
#            print(df_transpose)
#            print(sorted(data.items(),key=lambda x:x[0]))
            df_transpose.to_csv('final_data.csv', mode='a', header=False)
#            print(df.T)
#            print(df['22'])
            plt.bar(range(len(data)), data.values(), align="center")
            plt.xticks(range(len(data)), list(data.keys())) 
            plt.title('ads life')
            foo_fig = plt.gcf()  # 'get current figure'
            foo_fig.savefig('./life', format='eps', dpi=2000)
            plt.savefig('./ads_life/ads_life_'+str(hour)+'.png')
#            with open(str(hour),'w') as fi:
#                pickle.dump(data, fi)
if __name__ == '__main__':
    data = main(BaseVivoDXLModel)
