#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
base module of lgb
"""
