#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

'''
transform tfrecords file to csv 
'''

import os
import tensorflow as tf
import numpy as np
from module.vivo.model_v0_fhl import BaseVivoDXLModel

os.environ["CUDA_VISIBLE_DEVICES"]="5"

tf.app.flags.DEFINE_string('work_dir', '/home/wllu/cb/prj_vivo_dxl_fhl/deep_cross/cfg/test_adsId_05', 'Working directory(Data path)')
batch_size = 10
dim = batch_size*256

def load_data_from_file(sess,  model_class):
    data_iterator = model_class.tfrecord_pipeline(
        model_class.read_list_from_file(tf.app.flags.FLAGS.work_dir),
        batch_size,
        epochs=1,
        shuffle=False).make_initializable_iterator()
    sess.run(data_iterator.initializer)

    raw_features, raw_labels = model_class.reshape_input(
        data_iterator.get_next())
    model_class.reshape_sparse2dense(raw_features)
    for key, feature in raw_features.copy().items():
        if isinstance(feature, dict):
            raw_features.pop(key)
            for subkey in feature:
                raw_features[key+subkey] = feature[subkey]

    data = []
    try:
        count = 1    
        while count < 2:
#            temp_arr = np.random.rand(dim, 1)
            final_data = sess.run(raw_features)
            print('count: ', count)
#            for k, v in feature_label[0].items():
#                print('temp_arr:',temp_arr.shape)
#                print('v:', v.shape)
#                temp_arr = np.concatenate([temp_arr, v], axis = 1)
#            final_data = np.concatenate([feature_label[1], temp_arr], axis = 1)
#            final_data = np.delete(final_data, 1, axis=1)
#            p_samp = np.sum(final_data, axis = 0)[0]
#            n_samp = 25856 - np.sum(final_data, axis = 0)[0]
#            print('num of postive sample :', p_samp)
#            print('num of negative sample :', n_samp)
#            print('negative ratio: ', n_samp/(n_samp+p_samp))
#            print('the shape of final_data is: ',final_data.shape )
            print(final_data)
            f = open('tf2csv_valid.csv', 'a')
            np.savetxt(f, final_data, fmt=','.join(['%i']*55 + ['%1.12g']*1825 + ['%s']*2), delimiter=',') 
            count = count + 1
    except tf.errors.OutOfRangeError:
        return data

def main(model_class):
    if not tf.app.flags.FLAGS.work_dir:
        print('Please specify work directory')
        return
    with tf.Session() as sess:
        data = load_data_from_file(sess,
                                   model_class)
if __name__ == '__main__':
    data = main(BaseVivoDXLModel)
