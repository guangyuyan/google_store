#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

'''
Utils for client to use rpc conneting sever(send features and get labels back)
'''

import tensorflow as tf
import numpy as np

# server_model_name is the model name given by flag when run tensorflow server
tf.app.flags.DEFINE_string('work_dir', '/home/wllu/cb/test_code/google_store/deep_cross/tf2csv_data_cfg', 'Working directory(Data path)')
batch_size = 108
dim = batch_size*256

def load_data_from_file(sess,  model_class):
    data_iterator = model_class.tfrecord_pipeline(
        model_class.read_list_from_file(tf.app.flags.FLAGS.work_dir),
        batch_size,
        epochs=1,
        shuffle=False).make_initializable_iterator()
    sess.run(data_iterator.initializer)

    raw_features, raw_labels = model_class.reshape_input(
        data_iterator.get_next())
    model_class.reshape_sparse2dense(raw_features)
    for key, feature in raw_features.copy().items():
        if isinstance(feature, dict):
            raw_features.pop(key)
            for subkey in feature:
                raw_features[key+subkey] = feature[subkey]

    # read data
    data = []
    try:
        count = 1    
        while True:
            print('count: ', count)
            temp_arr = np.random.rand(dim, 1)
#            print('temp_arr shape: ', temp_arr.shape)
            feature_label = sess.run([raw_features, raw_labels])
            for k, v in feature_label[0].items():
                temp_arr = np.concatenate([temp_arr, v], axis = 1)
            final_data = np.concatenate([feature_label[1], temp_arr], axis = 1)
            final_data = np.delete(final_data, 1, axis=1)
            print('the shape of final_data is: ',final_data.shape )
            f = open('tf2csv_test.csv', 'a')
            np.savetxt(f, final_data, fmt='%i,'*56+'%1.11g,'*1824+'%1.11g'*1, delimiter=',') 
#            print(final_data.shape)
            count = count + 1
    except tf.errors.OutOfRangeError:
        # print('File end! Reuse data, Loading size: %d' % (len(data)))
        return data


def client_test(model_class):
    if not tf.app.flags.FLAGS.work_dir:
        print('Please specify work directory')
        return
    with tf.Session() as sess:
        data = load_data_from_file(sess,
                                   model_class)
