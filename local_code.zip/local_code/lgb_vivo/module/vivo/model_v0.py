#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base DXL with VIVO news feed data
"""

from .vivo_trainable import VivoTrainable
from ..base.model_dxl import BaseDXLModel, PREDICT_NODE_NAME, POSITION_FEATURE_NAME
from .summary import CATEGORY_FEATURES, NUMERICAL_FEATURES, VOC_SIZE
import tensorflow as tf

OUTPUT_NAME = "predictions"

tf.app.flags.DEFINE_integer("vocabulary_size", 400, "categorical feature size")

class BaseVivoDXLModel(BaseDXLModel, VivoTrainable):
    voc_emb_size = None

    def __init__(self, flags):
        BaseDXLModel.__init__(self, flags)
        VivoTrainable.__init__(self, flags)
        self.NUM_POSITIONS = 100
        if self.flags.vocabulary_size:
            self.vocabulary_size = self.flags.vocabulary_size
        else:
            self.vocabulary_size = 2 ** self.flags.hash_bits
        tf.logging.warn('vocabulary_size:{}'.format(self.vocabulary_size))
        BaseVivoDXLModel.voc_emb_size = self.load_voc_summary()
        self.model_inputs = {}
        self.model_outputs = {}

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_file,  batch_size,
                          epochs, shuffle=True):
        return VivoTrainable.tfrecord_pipeline(tfrecord_file, batch_size,
                                               epochs, shuffle)

    @classmethod
    def reshape_input(cls, features):
        label = tf.reshape(features['clicked'], [-1, 1])
        reshaped = dict()
        for key, dim in CATEGORY_FEATURES.items():
            reshaped[key] = tf.reshape(
                features[key],
                [-1, dim])
        for key, dim in NUMERICAL_FEATURES.items():
            reshaped[key] = tf.reshape(
                features[key],
                [-1, dim])
        return reshaped, label

    @classmethod
    def load_voc_summary(cls):
        voc_emb_size = dict()
        for key, voc_size in VOC_SIZE.items():
            emb_size = cls.compute_emb_size(voc_size)
            voc_emb_size[key] = [voc_size+2, emb_size]
        for k, v in voc_emb_size.items():
            cls.print_emb_info(k, v[0], v[1])
        return voc_emb_size

    def build_predictions_with_positions(self, v, raw_position):
        score = tf.layers.Dense(1)(v)
        """
        position is 1-d embedding of the raw positions.
        During training, there is 1 raw_position for each training sample.
        But during inference, there may be k different raw_positions, and hence
        the predictions will be k different as well.
        """
        num_positions = tf.to_int32(
            tf.reduce_prod(tf.shape(raw_position)) / tf.shape(score)[0])
        position = self.embedding(raw_position, POSITION_FEATURE_NAME, None,
                                  num_features=num_positions,
                                  voc_size=self.NUM_POSITIONS,
                                  emb_size=1)
        return tf.sigmoid(score + position, name=PREDICT_NODE_NAME)

    def build(self):
        features, labels = self.build_input()
        self.model_inputs = self.build_model_tensors_info(features)
        self.features = features
        self.labels = [labels]
        v = self.build_network(features)

        with tf.device('/gpu:0'):
            if POSITION_FEATURE_NAME not in features:
                preds = self.build_predictions(v)
            else:
                preds = self.build_predictions_with_positions(
                    v, features[POSITION_FEATURE_NAME])
            if self.flags.ns_rate < 1:
                preds = preds / (preds + tf.divide(tf.subtract(1.0, preds),
                                                   self.flags.ns_rate))
            self.preds = [preds]
            if self.prediction_signature is None:
                self.model_outputs[OUTPUT_NAME] = \
                    tf.saved_model.utils.build_tensor_info(preds)
                self.set_prediction_signature(
                    self.model_inputs, self.model_outputs)
            loss = self.build_loss(labels, preds)
            self.costs = self.build_eval_metric_ops(labels, preds, loss)
            self.build_cost_summary()
            self.train_op = self.build_train_op(loss)
