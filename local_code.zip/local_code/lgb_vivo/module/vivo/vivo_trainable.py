#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
"""

from ..base.base_trainable import BaseTrainable
#from .summary import CATEGORY_FEATURES, NUMERICAL_FEATURES
from .summary_fhl import CATEGORY_FEATURES, NUMERICAL_FEATURES, STRING_FEATURES
import tensorflow as tf

tf.app.flags.DEFINE_integer("dense_features", 1044, 'categorical features')
tf.app.flags.DEFINE_integer("sparse_features", 55, 'continuous features')


class VivoTrainable(BaseTrainable, object):

    def __init__(self, flags):
        super(VivoTrainable, self).__init__(flags)

    @classmethod
    def parser(cls, record):
        flags = tf.app.flags.FLAGS
        prebatch = flags.prebatch
        feature_map = {'clicked': tf.FixedLenFeature([prebatch], tf.int64)}
        for key, dim in CATEGORY_FEATURES.items():
            feature_map[key] = tf.FixedLenFeature([dim * prebatch], tf.int64)
        for key, dim in NUMERICAL_FEATURES.items():
            feature_map[key] = tf.FixedLenFeature([dim * prebatch], tf.float32)
        for key, dim in STRING_FEATURES.items():
            feature_map[key] = tf.FixedLenFeature([dim * prebatch], tf.string)        
        features = tf.parse_single_example(record, features=feature_map)
        return features
