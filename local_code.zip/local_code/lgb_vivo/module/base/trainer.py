#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
trainer
"""

from .usage_model import set_usage_model
import tensorflow as tf
# import threading

def train(model):
    set_usage_model()
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    # coord = tf.train.Coordinator()
    with tf.Session(config=sess_config) as session:
        model.train(session)
        # threads = []
        # for i in range(4):
        #     t = threading.Thread(target=model.train, args=(session, ))
        #     t.start()
        #     threads.append(t)
        # coord.join(threads)
