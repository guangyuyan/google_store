#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

'''
Utils for client to use rpc conneting sever(send features and get labels back)
'''


import grpc
from grpc.framework.interfaces.face.face import \
    CancellationError, ExpirationError
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
import threading
import time

tf.app.flags.DEFINE_float('expire_time', 5.0, 'Max time to wait for response')
tf.app.flags.DEFINE_integer('concurrency', 1, 'Max concurrent requests')
tf.app.flags.DEFINE_integer('num_tests', 2000, 'Number of test requests')
# server_model_name is the model name given by flag when run tensorflow server
tf.app.flags.DEFINE_string('server_model_name', 'model_v1',
                           'Model Name in server')
tf.app.flags.DEFINE_string('server', '', 'PredictionService host:port')
tf.app.flags.DEFINE_string('work_dir', '', 'Working directory(Data path)')
tf.app.flags.DEFINE_bool('show_result', False, 'print result or not')


class _ResultCounter(object):
    '''Counter for the prediction results.'''

    def __init__(self, num_tests, concurrency):
        self._num_tests = num_tests
        self._concurrency = concurrency
        self._cancel = 0
        self._expire = 0
        self._done = 0
        self._active = 0
        self._condition = threading.Condition()
        self._mutex = threading.Lock()
        self._timecost = []

    def inc_cancel(self):
        self._mutex.acquire()
        try:
            self._cancel += 1
        finally:
            self._mutex.release()

    def inc_expire(self):
        self._mutex.acquire()
        try:
            self._expire += 1
        finally:
            self._mutex.release()

    def finish(self, tc):
        with self._condition:
            self._done += 1
            self._active -= 1
            self._timecost.append(tc)
            self._condition.notifyAll()

    def get_timecost_info(self):
        with self._condition:
            while self._done != self._num_tests:
                self._condition.wait()
            timecost_info = {}
            self._timecost = [tc*1000 for tc in self._timecost]
            self._timecost.sort()
            timecost_info['Max'] = self._timecost[len(self._timecost)-1]
            timecost_info['The99%'] = self._timecost[int(
                round(len(self._timecost)*.99))-1]
            timecost_info['The90%'] = self._timecost[int(
                round(len(self._timecost)*.9))-1]
            timecost_info['Average'] = sum(self._timecost)/len(self._timecost)
            timecost_info['Min'] = self._timecost[0]
            return timecost_info

    def get_cancel_rate(self):
        with self._condition:
            # Must check before main function exit
            while self._done != self._num_tests:
                self._condition.wait()
            return self._cancel / float(self._num_tests)

    def get_expire_rate(self):
        with self._condition:
            while self._done != self._num_tests:
                self._condition.wait()
            return self._expire / float(self._num_tests)

    def throttle(self):
        with self._condition:
            while self._active == self._concurrency:
                self._condition.wait()
            self._active += 1


def _create_rpc_callback(labels, result_counter, start_time):
    def _callback(result_future):
        exception = result_future.exception()
        if exception:
            if isinstance(exception, CancellationError):
                result_counter.inc_cancel()
            elif isinstance(exception, ExpirationError):
                result_counter.inc_expire()
            else:
                print(exception)
        elif tf.flags.FLAGS.show_result:
            for key, result in result_future.result().outputs.items():
                print('result is '+key)
                print(result.float_val)
        end_time = time.time()
        result_counter.finish(end_time-start_time)
    return _callback


def do_inference(hostport, num_tests, data, sess, concurrency):
    channel = grpc.insecure_channel(hostport)
    stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)
    result_counter = _ResultCounter(num_tests, concurrency)
    total_prepare_time = 0.0
    data_len = len(data)
    tstart = time.time()
    for i in range(num_tests):
        pstart = time.time()
        request = predict_pb2.PredictRequest()
        request.model_spec.name = tf.app.flags.FLAGS.server_model_name
        request.model_spec.signature_name = \
            tf.saved_model.signature_constants \
              .DEFAULT_SERVING_SIGNATURE_DEF_KEY
        features, labels = data[i % data_len]
        for key, feature in features.items():
            request.inputs[key].CopyFrom(
                tf.contrib.util.make_tensor_proto(feature,
                                                  shape=feature.shape))

        pend = time.time()
        total_prepare_time = total_prepare_time + (pend-pstart)
        result_counter.throttle()
        result_future = stub.Predict.future(request,
                                            tf.app.flags.FLAGS.expire_time)
        result_future.add_done_callback(
            _create_rpc_callback(labels, result_counter, time.time()))
    expire_rate = result_counter.get_expire_rate()
    tend = time.time()
    print('QPS: %.2f\t' % (num_tests/(tend-tstart)), end='\t')
    # print('Total predict time cost: %.4fs, QPS: %.2f' \
    #       % (tend-tstart, num_tests/(tend-tstart)))
    # print('Total Prepare Time: %.2fms, Average: %.2fms' \
    #       % (total_prepare_time*1000, total_prepare_time*1000/num_tests))
    return expire_rate, result_counter.get_timecost_info()


def load_data_from_file(sess, num_tests, model_class):
    data_iterator = model_class.tfrecord_pipeline(
        model_class.read_list_from_file(tf.app.flags.FLAGS.work_dir),
        tf.app.flags.FLAGS.batch_size,
        epochs=1,
        shuffle=False).make_initializable_iterator()
    sess.run(data_iterator.initializer)

    # build graph
    raw_features, raw_labels = model_class.reshape_input(
        data_iterator.get_next())
    model_class.reshape_sparse2dense(raw_features)
    for key, feature in raw_features.copy().items():
        if isinstance(feature, dict):
            raw_features.pop(key)
            for subkey in feature:
                raw_features[key+subkey] = feature[subkey]

    # read data
    data = []
    try:
        for i in range(num_tests):
            data.append(sess.run([raw_features, raw_labels]))
        return data
    except tf.errors.OutOfRangeError:
        # print('File end! Reuse data, Loading size: %d' % (len(data)))
        return data


def client_test(model_class):
    if not tf.app.flags.FLAGS.server:
        print('Please specify server host:port')
        return
    if not tf.app.flags.FLAGS.work_dir:
        print('Please specify work directory')
        return
    with tf.Session() as sess:
        data = load_data_from_file(sess,
                                   tf.app.flags.FLAGS.num_tests,
                                   model_class)
        expire_rate, timecost_info = do_inference(
            tf.app.flags.FLAGS.server, tf.app.flags.FLAGS.num_tests,
            data, sess, tf.app.flags.FLAGS.concurrency)
    # print('\nInference ExpirationError rate: %s%%' % (expire_rate * 100))
    # print('%s%%     %s seconds' % (expire_rate * 100, ave_timecost))
    # print('Expire Rate: %s%%' % (expire_rate*100)),
    # for key in timecost_info:
    #    print('%s: %.2fms   ' % (key, timecost_info[key])),
    # print
    for key, value in sorted(timecost_info.items()):
        print('{}: {}'.format(key, value), end='\t')
    print('', end='\n')
