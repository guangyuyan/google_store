#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
trainer
"""


import tensorflow as tf
# import threading


def calc_step_rate(mode, min_lr, max_lr, stop_step, update_step):
    if mode == 1:
        step_rate = (max_lr - min_lr) / (stop_step / update_step)
    elif mode == 2:
        step_rate = (max_lr / min_lr) ** (update_step / (stop_step * 1.0))
    else:
        step_rate = 0
    return step_rate


def set_lr_customized_schedule():
    '''
    lr scheduling mode
        - no valid
        - set summary step to be 1
    '''
    tf.app.flags.FLAGS.data_per_valid = 0
    tf.app.flags.FLAGS.steps_per_summary = 1

    tf.logging.warn('  -lr schedule mode: {} min lr: {} max lr: {} in {} steps per {} steps'.format(tf.app.flags.FLAGS.lr_schedule_mode, 
                                                                                       tf.app.flags.FLAGS.learning_rate, 
                                                                                       tf.app.flags.FLAGS.lr_schedule_max, 
                                                                                       tf.app.flags.FLAGS.stop_steps,
                                                                                       tf.app.flags.FLAGS.lr_schedule_update_step))
    tf.logging.warn('      step rate {}'.format(calc_step_rate(tf.app.flags.FLAGS.lr_schedule_mode, 
                                                               tf.app.flags.FLAGS.learning_rate, 
                                                               tf.app.flags.FLAGS.lr_schedule_max, 
                                                               tf.app.flags.FLAGS.stop_steps,
                                                               tf.app.flags.FLAGS.lr_schedule_update_step)))    
    tf.logging.warn('      data_per_valid set to {}'.format(tf.app.flags.FLAGS.data_per_valid))
    tf.logging.warn('      steps_per_summary set to {}'.format(tf.app.flags.FLAGS.steps_per_summary))


def check_fidelity():
    '''
    check flags fidelity and issue warning if there is potential conflict in flag settings
    '''
    pass


def set_usage_model():

    tf.logging.warn('*' * 25 + 'Setting Usage Model' + '*' * 25)

    if tf.app.flags.FLAGS.lr_schedule_mode != 0:
        set_lr_customized_schedule()

    check_fidelity()

    tf.logging.warn('*' * 23 + 'Done Setting Usage Model' + '*' * 22)
