#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base DXL model with base network and helper functions.
"""

from .fm_core import TFFMCore
from .model_base import BaseModel

import math
import numpy as np
import tensorflow as tf

tf.app.flags.DEFINE_enum(
    "sparse_embedding_combiner", "mean", ["mean", "sqrtn"],
    "mean is the weighted sum divided by the total weight."
    "sqrtn is the weighted sum divided by the square root of the sum of "
    "the squares of the weights.")

PREDICT_LAYER_NAME = "predict"
PREDICT_NODE_NAME = PREDICT_LAYER_NAME + "/Sigmoid"
POSITION_FEATURE_NAME = "position"


class BaseDXLModel(BaseModel):
    def __init__(self, flags):
        super(BaseDXLModel, self).__init__(flags)

    def build_predictions(self, v):
        # TODO(xjfan): Find a way to explicitly define the output node name.
        # Currently it relays on TF appending /Sigmoid after PREDICT_LAYER_NAME
        return tf.layers.Dense(1, activation=tf.nn.sigmoid,
                               name=PREDICT_LAYER_NAME)(v)

    def build_loss(self, labels, preds):
        return tf.reduce_mean(tf.losses.log_loss(labels, preds))

    def build_eval_metric_ops(self, labels, predictions, loss):
        """Return a dict of the evaluation Ops.
        Args:
            labels (Tensor): Labels tensor for training and evaluation.
            predictions (Tensor): Predictions Tensor.
        Returns:
            Dict of metric results keyed by name.
            Each metric has two ops. The second op is to update the internal
            states for streaming data. The value of second op *SEEMS* to be the
            correct value of the metric on streaming data although there is no
            explicit document on it.
        """
        with tf.device('/cpu:0'):
            loss_streaming = tf.metrics.mean(loss)
            roc = tf.metrics.auc(labels, predictions, curve='ROC')
            pr = tf.metrics.auc(labels, predictions, curve='PR',
                                summation_method='careful_interpolation')
            preds_streaming = tf.metrics.mean(predictions)
            labels_streaming = tf.metrics.mean(labels)
            return {
                'loss': loss,
                'stream_loss': loss_streaming[1],
                'roc': roc[1],
                'pr': pr[1],
                'calibration': preds_streaming[1]/labels_streaming[1]
            }

    def hashing_id(self, ids):
        with tf.name_scope('hashing'):
            hashed_ids = tf.mod(ids, self.vocabulary_size - 1) + 1
            zero = tf.zeros_like(ids, dtype=tf.int64)
            return tf.where(tf.equal(ids, zero), zero, hashed_ids)

    def init_embedding_weights(self, layer_name, voc_size, emb_size,
                               initial_range, name_scope):
        """
        initialize embedding_weights, where
        id 0 is reserved for UNK, and its embedding fix to all zeros
        """
        with tf.variable_scope(name_scope):
            unknown_id = tf.get_variable('-'.join([layer_name, 'unknown']),
                                         [1, emb_size], trainable=False,
                                         initializer=tf.zeros_initializer)
            normal_ids = tf.get_variable(
                '-'.join([layer_name, 'normal']),
                [voc_size - 1, emb_size],
                initializer=tf.random_uniform_initializer(
                    minval=-initial_range, maxval=initial_range)
                if initial_range else None)
            return tf.concat([unknown_id, normal_ids], axis=0)

    def safe_ids_for_emb(self, ids, voc_size):
        """
        if id >= voc_size, then it set to 0 which means UNK, and the embedding
        should be all zeros.
        """
        return tf.where(tf.less_equal(ids, voc_size),
                        ids, tf.zeros_like(ids))

    def single_embedding(self, ids, layer_name, voc_size, emb_size,
                         initial_range, name_scope='embedding', dropout=0):
        """
        input ids shape: B x 1
        output shape: B x E
        dropout: may tie with the unknown_id ratio
        """
        with tf.variable_scope(name_scope):
            safe_ids = self.safe_ids_for_emb(ids, voc_size)
            emb = self.init_embedding_weights(
                layer_name, voc_size, emb_size, initial_range, name_scope)
            out = tf.nn.embedding_lookup(emb, safe_ids)
            out = tf.reshape(out, [-1, emb_size])
            if dropout > 0:
                '''
                drop or keep the embedding for one feature at whole.
                '''
                out = tf.layers.dropout(out, rate=dropout,
                                        training=self.is_training,
                                        noise_shape=[tf.shape(out)[0], 1])
            return out

    def embedding(self, ids, layer_name, initial_range,
                  num_features=None, voc_size=None, emb_size=None,
                  name_scope='embedding', dropout=0):
        """
        input ids shape: B x F
        output shape: B x (F x E)
        """
        if num_features is None:
            num_features = self.flags.sparse_features
        if voc_size is None:
            voc_size = self.vocabulary_size
        if emb_size is None:
            emb_size = self.flags.embedding_size
        with tf.name_scope(name_scope):
            out = self.single_embedding(ids, layer_name, voc_size, emb_size,
                                        initial_range, name_scope, dropout)
            out = tf.reshape(out, [-1, num_features * emb_size])
            return out

    def sparse_embedding(self, ids, layer_name, voc_size, emb_size,
                         initial_range, name_scope='embedding',
                         combiner='mean'):
        with tf.name_scope(name_scope):
            # TODO(byzhang): find a way to guard id for sparse tensor
            emb = self.init_embedding_weights(
                layer_name, voc_size, emb_size, initial_range, name_scope)
            out = tf.nn.embedding_lookup_sparse(emb, ids, None,
                                                combiner=combiner)
            return out

    def build_sparse_embedding(self, ids, layer_name, voc_size,
                               emb_size):
        out = self.sparse_embedding(
            ids, layer_name, voc_size, emb_size, None,
            combiner=self.flags.sparse_embedding_combiner)
        if self.flags.summary_mode == 'all':
            tf.summary.histogram(out.name, out)
        return out

    def binary_embedding(self, emb):
        with tf.name_scope('embedding'):
            out = tf.sigmoid(emb)
            if self.flags.summary_mode == 'all':
                tf.summary.histogram("unkown/{}".format(out.name), out)
            return out

    def build_single_embedding(self, ids, layer_name, voc_size,
                               emb_size, dropout=0):
        out = self.single_embedding(ids, layer_name, voc_size,
                                    emb_size, None, dropout=dropout)
        if self.flags.summary_mode == 'all':
            tf.summary.histogram(ids.name, ids)
            tf.summary.histogram(out.name, out)
        return out

    def minmax_dense(self, fv):
        with tf.name_scope('dense'):
            fv = tf.maximum(tf.minimum(fv, self.get_dense_max()),
                            self.get_dense_min()) - self.get_dense_min()
            return fv

    def minmax_normalize_float(self, fv):
        with tf.name_scope('dense'):
            return self.minmax_dense(fv) / self.get_dense_norm()

    def minmax_normalize_int(self, iv):
        with tf.name_scope('dense'):
            iv = self.minmax_dense(iv)
            ids = tf.cast(tf.sqrt(iv), dtype=tf.int64)
            return iv / self.get_dense_norm(), ids

    def BN(self, fv):
        with tf.name_scope('BN'):
            fv = tf.layers.batch_normalization(fv,
                                               fused=True,
                                               training=self.is_training,
                                               renorm=self.flags.renorm)
            return fv

    def binary_dense(self, fv):
        with tf.name_scope('binary_dense'):
            dim = fv.get_shape()[-1]
            fv = tf.expand_dims(fv, 2)
            scale = tf.get_variable(
                name="scale",
                shape=[dim, self.flags.num_buckets],
                dtype=tf.float32,
                initializer=tf.random_normal_initializer(
                    mean=self.flags.num_buckets * math.sqrt(
                        self.flags.bucket_peak) / 2))
            if self.flags.summary_mode == 'all':
                for i in range(dim):
                    row = tf.slice(scale, [i, 0], [1, self.flags.num_buckets])
                    tf.summary.histogram("normal/scale_{}".format(i), row)
            offset = tf.get_variable(
                name="offset",
                shape=[dim, self.flags.num_buckets],
                dtype=tf.float32,
                initializer=tf.random_uniform_initializer(minval=-1, maxval=1))
            if self.flags.summary_mode == 'all':
                for i in range(dim):
                    row = tf.slice(offset, [i, 0], [1, self.flags.num_buckets])
                    tf.summary.histogram("normal/offset_{}".format(i), row)
            bin_dense = tf.tanh(
                self.flags.bucket_peak - tf.square(scale*(fv - offset)))
            if self.flags.summary_mode == 'all':
                tf.summary.image('bin_dense_out',
                                 tf.expand_dims(255 * bin_dense, 3),
                                 max_outputs=12)
            return tf.reshape(bin_dense, [-1, dim * self.flags.num_buckets])

    def concat(self, inputs):
        return inputs

    def dropout_layer(self, inputs):
        # TODO(xjfan): test if tflite supports tf.layers.dropout
        return tf.layers.dropout(inputs,
                                 rate=(1 - self.flags.keep_prob),
                                 training=self.is_training)

    def one_deep_level(self, inputs, prefix, hidden, activation, sparse):
        with tf.name_scope('{}_deep'.format(prefix)):
            w = tf.layers.Dense(
              hidden, activation=activation,
              name='{}_weight'.format(prefix),
              kernel_initializer=tf.zeros_initializer() if sparse else None,
              kernel_regularizer=tf.keras.regularizers.l1_l2(l1=self.flags.l1,
                                                             l2=self.flags.l2)
              if sparse else None)
            outputs = w.apply(inputs)
            if self.flags.summary_mode == 'all':
                tf.summary.histogram(outputs.name, outputs)
                nnz = tf.count_nonzero(outputs)
                tf.summary.scalar('nnz/{}'.format(outputs.name), nnz)
                for weight in tf.get_collection(
                            tf.GraphKeys.TRAINABLE_VARIABLES,
                            scope=w.scope_name):
                    tf.summary.histogram("unknown/{}".format(weight.name),
                                         weight)
            if self.flags.res_deep:
                return outputs + inputs
            return outputs

    def deep_net(self, raw_inputs, hidden, activation, sparse=False):
        with tf.name_scope('deep'):
            outputs = tf.concat(raw_inputs, -1)
            for i, hs in enumerate(hidden):
                outputs = self.dropout_layer(outputs)
                outputs = self.one_deep_level(outputs, 'deep_{}'.format(i),
                                              hs, activation, sparse)
        return outputs

    def self_attentive_deep_net(self, raw_inputs, hidden, activation,
                                concat_last_deep=True,
                                sparse=False):
        outputs = []
        with tf.name_scope('deep'):
            output = tf.concat(raw_inputs, -1)
            for i, hs in enumerate(hidden):
                output = self.dropout_layer(output)
                output = self.one_deep_level(output, 'deep_{}'.format(i),
                                             hs, activation, sparse)
                outputs.append(output)
            """
            H: column wise matrix of each deep layer
            """
            H = tf.stack(outputs, axis=2)
            """
            S = H' * H
            """
            S = tf.matmul(tf.transpose(H, perm=[0, 2, 1]), H)
            """
            Column wise softmax as attention
            """
            attention = tf.nn.softmax(S, axis=1)
            """
            G = H * A
            """
            G = tf.matmul(H, attention)
            """
            Sum over deep layers
            """
            G = tf.reduce_sum(G, axis=-1)

            if concat_last_deep:
                return tf.concat([outputs[-1], G], axis=-1)
            else:
                return G

    def one_cross_level(self, x0, x, name, use_bias, sparse):
        with tf.name_scope(name):
            w = tf.layers.Dense(
              1,
              kernel_regularizer=tf.keras.regularizers.l1_l2(l1=self.flags.l1,
                                                             l2=self.flags.l2)
              if sparse else None,
              kernel_initializer=tf.zeros_initializer()
              if sparse else None,
              name='{}_weight'.format(name),
              use_bias=use_bias)
            p = w.apply(x)
            if self.flags.summary_mode == 'all':
                for weight in tf.get_collection(
                                tf.GraphKeys.TRAINABLE_VARIABLES,
                                scope=w.scope_name):
                    tf.summary.histogram(
                                "normal/{}".format(weight.name), weight)
                    nnz = tf.count_nonzero(weight)
                    tf.summary.scalar('nnz/{}'.format(weight.name), nnz)
            return p * x0

    def cross_net(self, raw_inputs, num_layers, use_bias=True, sparse=False):
        with tf.name_scope('cross'):
            inputs = tf.concat(raw_inputs, -1)
            t = inputs
            for i in range(num_layers):
                t += self.one_cross_level(inputs, t,
                                          '{}'.format(i), use_bias, sparse)
            if self.flags.summary_mode == 'all':
                tf.summary.histogram(t.name, t)
        return t

    def fm_net(self, raw_inputs, order, rank):
        with tf.name_scope('fm'):
            inputs = tf.concat(raw_inputs, -1)
            fm_model = TFFMCore(inputs, order=order, rank=rank)
            n_features = inputs.get_shape()[-1]
            fm_model.set_num_features(int(n_features))
            fm_model.build_fm()
            fm_out = fm_model.get_outputs()
            if self.flags.summary_mode == 'all':
                tf.summary.histogram(fm_out.name, fm_out)
        return fm_out

    def deep_multiply_net(self, raw_inputs, hiddens, activation, sparse):
        with tf.name_scope('deep_multiply'):
            inputs = tf.concat(raw_inputs, -1)
            for i, hs in enumerate(hiddens):
                with tf.name_scope('deep'):
                    deep1 = self.one_deep_level(
                        inputs, 'deep_multiply1_{}'.format(i),
                        hs, activation, sparse)
                    deep2 = self.one_deep_level(
                        inputs, 'deep_multiply2_{}'.format(i),
                        hs, activation, sparse)
                    inputs = deep1 + deep2 + tf.multiply(deep1, deep2)
            return inputs

    def deep_cross_net(self, raw_inputs, hiddens, activation, sparse):
        with tf.name_scope('deep_cross'):
            inputs = tf.concat(raw_inputs, -1)
            for i, hs in enumerate(hiddens):
                with tf.name_scope('deep'):
                    deep1 = self.one_deep_level(
                        inputs, 'deep_cross1_{}'.format(i),
                        hs, activation, sparse)
                    deep2 = self.one_deep_level(
                        inputs, 'deep_cross2_{}'.format(i),
                        hs, activation, sparse)
                    inputs = deep1 + deep2 + self.one_cross_level(
                        deep1, deep2, '{}'.format(i), False, sparse)
            return inputs

    def mvm_net(self, feature_list):
        with tf.device('/gpu:0'):
            """
            shape: Batch x Features x factor_size
            """
            embs = tf.stack(feature_list, 1)
            num_features = int(embs.shape.dims[1])
            bias = tf.get_variable("padding_bias",
                                   (num_features, self.flags.factor_size))
            all_order = tf.add(embs, bias)
            mvm = all_order[:, 0, :]  # B x 1 x factor_size
            for i in range(1, num_features):
                mvm = tf.multiply(mvm, all_order[:, i, :])
            mvm = tf.reshape(mvm, shape=[-1, self.flags.factor_size])
            return mvm

    @classmethod
    def compute_emb_size(self, voc_size):
        return int(6 * (voc_size ** 0.25))

    @classmethod
    def print_emb_info(cls, feature_name, voc_size, emb_size):
        tf.logging.warn(" voc_size{:8} emb_size{:4} feature_name {}".format(
                        voc_size, emb_size, feature_name))

    def build_img_embedding(self):
        """
        init() is function and need to call before training
        img_embedding is a tensor for tf.nn.embedding_lookup()
            after lookup, should be reshaped to (-1, 180, 240, 3) as images
        """
        imgs = np.load(self.flags.img_npz)['img']
        img_embedding = tf.Variable(tf.constant(tf.uint8(0), shape=imgs.shape),
                                    trainable=False, name='img_embedding')
        img_embedding_placeholder = tf.placeholder(tf.uint8, imgs.shape)
        img_embedding_init = img_embedding.assign(img_embedding_placeholder)

        def init(session):
            session.run(img_embedding_init,
                        feed_dict={img_embedding_placeholder: imgs})
        return init, img_embedding

    def build_network(self, features):
        """
        must defined in subclass
        """
        raise NotImplementedError("build_network: not implemented!")

    def build_cost_summary(self):
        tf.summary.scalar('cost/stream_loss', self.costs['stream_loss'])
        tf.summary.scalar('cost/loss', self.costs['loss'])
        tf.summary.scalar('cost/roc', self.costs['roc'])
        tf.summary.scalar('cost/pr', self.costs['pr'])
        tf.summary.scalar('cost/calibration', self.costs['calibration'])
