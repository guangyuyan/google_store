#!/usr/bin/env python3
import pandas as pd
import csv

df = pd.read_csv('ids_sorted_1120.csv', sep=',')
df_sorted = df.sort_values(by=['dt'], ascending=False)
df_sorted.to_csv('sorted_1120.csv')
