#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

import numpy as np
import pandas as pd
from pandas import Series
import matplotlib.pyplot as plt

plt.switch_backend('agg')

cols = ['interval', 'calibration', 'positive_ratio', 'bucket_size']
df = pd.DataFrame(columns=cols)

def plot_calibration_buckets(preds, labels):
    data = sorted(zip(preds, labels), key=lambda x: x[0])
    bucket_width = int(len(data)/100) + 1
    begin = 0
    interval = 0
    positives = 0
    ctr_score = 0
    global df
    df.drop(df.index,inplace=True)
    while begin < len(data):
        end = begin + bucket_width
        ctr_score = np.sum(data[begin:end], axis=0)[0]
        positives = np.sum(data[begin:end], axis=0)[1]
        begin = end
        interval +=1
        calibration = ctr_score/positives
        positive_ratio = positives/bucket_width
        df = df.append(pd.DataFrame({'interval':[interval], 'calibration':[calibration], 'positive_ratio':[positive_ratio], 'bucket_size':[bucket_width]}), ignore_index=True)
def main():
    for num in range(12, 24):
        print(num)
#        predictions = '/home/wllu/cb/prj_vivo_dxl_fhl/deep_cross/summaries/outputs/new_all_feature_lr_0.0002_ns_rate_0.2_build_graph_test_'+str(num)+'.csv'
        predictions = '/home/wllu/cb/prj_vivo_dxl_fhl/deep_cross/summaries/outputs/cpc_yunnao_5-2018-11-12_test_'+str(num)+'.csv'
        with open(predictions) as f:
            labels = []
            preds = []
            for line in f:
                #modify pred and label index depends on real data
                pred = line.split()[1].strip('\n')
                label = line.split()[0].strip('\n')
                preds.append(float(pred))
                labels.append(float(label))
        plot_calibration_buckets(preds, labels)
        f.close()
        global df
        df.plot(x='interval', y='positive_ratio', kind='bar')
        plt.title(u'positive_ratio')
        plt.savefig('our_1112/'+str(num)+'_positive_ratio.png')
        df.plot(x='interval', y='calibration',kind='bar')
        plt.title(u'calibration')
        plt.savefig('our_1112/'+str(num)+'_calibration.png')
        df.to_csv('our_1112/'+str(num)+'.csv', index=False)
if __name__ == "__main__":
    main()
