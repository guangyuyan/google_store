# coding: utf-8

from sklearn.linear_model import LinearRegression
import csv
import numpy as np
import pandas as pd
import math

df_all_toutiao = pd.DataFrame()
for i in range(24):
    print('process toutiao data: ', i)
    df_toutiao = pd.read_csv('/Users/yanguangyu/Desktop/lr/toutiao_1112/'+str(i)+'.csv', header=None, sep=',')
    df_all_toutiao = pd.concat([df_all_toutiao, df_toutiao[:][1:]])

df_all_toutiao = df_all_toutiao.astype(float)
df_average_score_toutiao = df_all_toutiao[1][1:]*df_all_toutiao[2][1:].as_matrix()
toutiao = np.log(np.array(df_average_score_toutiao))

df_all_our = pd.DataFrame()
for i in range(24):
    print('process our data: ', i)
    df = pd.read_csv('/Users/yanguangyu/Desktop/lr/our_1112/'+str(i)+'.csv', header=None, sep=',')
    df_all_our = pd.concat([df_all_our, df[:][1:]])

df_all_our = df_all_our.astype(float)
df_average_score_our = df_all_our[1][1:]*df_all_our[2][1:].as_matrix()
our = np.log(np.array(df_average_score_our))

print('remove nan and reahspe')
np.where(np.isnan(our))
our = np.delete(our, [99, 299], axis=0).reshape(-1, 1)
toutiao = np.delete(toutiao, [99, 299], axis=0).reshape(-1, 1)

print('start train')
reg = LinearRegression(fit_intercept=True, normalize=False, copy_X=False, n_jobs=None).fit(our, toutiao)

print('score: ', reg.score(our, toutiao))
print('intercept: ', reg.intercept_)
print('coef: ', reg.coef_)
print('output_transform_scale: ', math.exp(reg.intercept_))
print('output_transform_exponent: ', reg.coef_)
