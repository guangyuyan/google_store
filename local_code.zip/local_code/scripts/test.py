#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

import random
import tensorflow as tf
from datetime import datetime, timedelta
import sys
import os
import shutil

FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_string("split_data_dir", '/home/wllu/data/cpc_v1_online_8/split_online_data/', "dir for splited and shuffled train/valid data")
tf.app.flags.DEFINE_string("split_data_train_cfg", '/home/wllu/data/cfg/split_data_train/', "splited and shuffled train data cfg file")
tf.app.flags.DEFINE_string("split_data_valid_cfg", '/home/wllu/data/cfg/split_data_valid/', "splited and shuffled valid data cfg file")
tf.app.flags.DEFINE_string("base_dir", '/home/wllu/data/cpc_v1_online_8/tfrecords/', "raw tfrecords file dir")
tf.app.flags.DEFINE_float("train_split_rate", 0.9, "split rate for train data")

def main(self):
    date_now = datetime.now().strftime('%Y-%m-%d')
    hour_now = datetime.now().strftime('%H')

    base_cfg = (datetime.now() - timedelta(hours=1)).strftime('%Y-%m-%d') + '_' \
               + (datetime.now() - timedelta(hours=1)).strftime('%H')
    pre_base_cfg = (datetime.now() - timedelta(hours=2)).strftime('%Y-%m-%d') + '_' \
               + (datetime.now() - timedelta(hours=2)).strftime('%H')
    data_dir = datetime.now().strftime('%Y-%m-%d') + '/' + \
               (datetime.now() - timedelta(hours=1)).strftime('%H')
    print('base_cfg: ', base_cfg)
    print('pre_base_cfg: ', pre_base_cfg)
    print('data_dir: ', data_dir)

if __name__ == "__main__":
    tf.app.run(main)
