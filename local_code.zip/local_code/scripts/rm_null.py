#!/usr/bin/env python3
import sys
for i in range(24):
    raw_data = str(i).txt
    clear_data = str(i)
    f = open(raw_data, 'r')
    lines = f.readlines()
    with open(clear_data, 'a') as f_clear:
        for line in lines:
            data1 = line.split()[0]
            print(data1)
            if data1 != 'null':
                f_clear.write(line)
f.close()
f_clear.close()
