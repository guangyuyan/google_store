#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

import random
import tensorflow as tf

rate = 0.9
#src = '/home/wllu/data/cfg/train_9d_1112'
src = 'tmp'

def main(argv):
    f = open(src, 'r')
    count = 1
    line_num = f.readlines()
    for tf_file in line_num:
        tf_file_split = tf_file.split('/')
        train_data = '/home/wllu/data/cpc_v1_online_8/split_online_data/train_1112/'+tf_file_split[-3]+'_'+tf_file_split[-2]+'_'+tf_file_split[-1]
        valid_data = '/home/wllu/data/cpc_v1_online_8/split_online_data/valid_1112/'+tf_file_split[-3]+'_'+tf_file_split[-2]+'_'+tf_file_split[-1]
        train_data = train_data.strip('\n')
        valid_data = valid_data.strip('\n')
        f0 = tf.python_io.TFRecordWriter(train_data)
        f1 = tf.python_io.TFRecordWriter(valid_data)
        tf_file = tf_file.strip('\n')
        for r in tf.python_io.tf_record_iterator(tf_file):
            rand = random.random()
            if rand < rate:
                f0.write(r)
            else:
                f1.write(r)
        count_str = str(count)
        print('processing file: '+ count_str +'/' + str(len(line_num)))
        print(train_data)
        print(valid_data)
        count = count + 1

if __name__ == "__main__":
    tf.app.run(main)
