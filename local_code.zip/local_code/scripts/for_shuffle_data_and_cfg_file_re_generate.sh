#!/usr/bin/bash

for((i=11;i<13;i++));  
do   
python split_tfrecord_and_generate_cfg_hourly.py $i 
done 
