import os
#data_cfg=open('/home/wllu/cb/prj_vivo_dxl_cosineFeatures33/cfg/valid_lgb_1077', 'a')
#for n in ['01', '02', '03', '04', '05', '06', '07', '08', '09']:
'''
data_cfg=open('../cfg/train_9d_1112', 'a')
for n in range(10, 13):
    path="/home/wllu/data/cpc_v1_online_8/tfrecords/2018-11-"+str(n)
    for dirpath,dirnames,filenames in os.walk(path):
        for file in filenames:
            fullpath=os.path.join(dirpath,file)
            data_cfg.write(fullpath+'\n')
data_cfg.close()
'''
#data_cfg=open('/home/wllu/data/cfg/split_data_valid/2018-11-19_09', 'w')
data_cfg = open('/home/wllu/data/cfg/split_data_valid/2018-11-21_19', 'a')
#path="/home/wllu/data/cpc_v1_online_8/split_online_data/valid_1112/"
path = '/home/wllu/data/cpc_v1_online_8/split_online_data/valid_1112/'
for dirpath,dirnames,filenames in os.walk(path):
    for file in filenames:
        fullpath=os.path.join(dirpath,file)
        data_cfg.write(fullpath+'\n')
data_cfg.close()
