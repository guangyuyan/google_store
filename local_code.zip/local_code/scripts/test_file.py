import os

fullpath = '/home/wllu/data/scripts/log'
#if os.path.isfile(fullpath) == False:
#    print(fullpath)
if fullpath.find("og"):
   print(fullpath)

