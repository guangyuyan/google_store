#!/usr/bin/env python

import numpy as np
from sklearn.metrics import log_loss
import pandas as pd
import math

df_result = pd.DataFrame(columns = ['logloss', 'positive_ratio', 'base_loss', 'norm_loss'])
for num in range(24):
    print('start to calculate loss: ', num)
    df_score_label = pd.read_csv('/home/wllu/data/yunnao_feed_20181112/score_label_feed_20181112/'+str(num), header=None, sep='\t')
    np_ctr = df_score_label[0][:].astype(float).as_matrix()
    np_label = df_score_label[1][:].astype(float).as_matrix()
    logloss = log_loss(np_label, np_ctr, eps=1e-15, normalize=True, sample_weight=None, labels=None)
    positive_ratio = np.sum(np_label)/np_label.shape[0]
    base = -positive_ratio*math.log(max(positive_ratio,1e-18)) - (1-positive_ratio)*math.log(max((1-positive_ratio),1e-18))
    norm_loss = logloss/base
    df_result = df_result.append(pd.DataFrame({'logloss':[logloss],'positive_ratio':[positive_ratio],'base_loss':[base], 'norm_loss':[norm_loss]}),ignore_index=True)

df_result.to_csv('toutiao_loss.csv', header=True, index=True)
