Build
===
```
gradle -Pjvm=<jvm-version> build
```
* jvm-version: `7` or `8`, default `8`

Output
===
* `tensorflow-client` is located in `tensorflow_client/build/libs`
* `model-client` is located in `model_client/build/libs`
* `perf-test` is located in `perf_test/build/libs`
