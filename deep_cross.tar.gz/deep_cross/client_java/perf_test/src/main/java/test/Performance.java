/*
 * Performance.java
 * Copyright (C) 2018 CloudBrain <tangkh@>
 *
 * Distributed under terms of the CloudBrain license.
 */

package test;

import com.cloudbrain.tensorflow.serving.client.BlockingClient;
import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Performance {
  private int categoricalShape;
  private int numericalShape;
  final private static String HOST = "localhost";
  final private static int PORT = 9000;

  private MetricRegistry metrics = new MetricRegistry();
  private List<long[]> categorical = new ArrayList<>();
  private List<float[]> numerical = new ArrayList<>();
  private int concurrency;

  public Performance(int concurrency, int categoricalShape, int numericalShape) {
    this.concurrency = concurrency;
    this.categoricalShape = categoricalShape;
    this.numericalShape = numericalShape;
  }

  public void test() throws InterruptedException {
    for (int i = 0; i < 800; i++) {
      long[] cate = new long[categoricalShape];
      float[] nume = new float[numericalShape];
      for (int j = 0; j < categoricalShape; j++)
        cate[j] = (int)(Math.random()+0.5);
      for (int j = 0; j < numericalShape; j++)
        nume[j] = (float)Math.random();
      categorical.add(cate);
      numerical.add(nume);
    }
    ConsoleReporter reporter = ConsoleReporter.forRegistry(metrics).build();
    reporter.start(1, TimeUnit.SECONDS);
    Timer timer = metrics.timer(MetricRegistry.name(Performance.class, "concurrency=" + concurrency));
    runJob(concurrency, timer);
  }

  private void runJob(int concurrency, final Timer timer) throws InterruptedException {
    List<Thread> threads = new ArrayList<>();
    for (int i = 0; i < concurrency; i++) {
      Thread runner = new Thread(new Runnable() {
        @Override
        public void run() {
          BlockingClient client = new BlockingClient(HOST, PORT);
          for (int count = 500; count > 0; count--) {
            try (Timer.Context ctx = timer.time()) {
              client.predict(categorical, numerical, "v1");
            } catch (Exception ex) {
              System.out.println(ex.getMessage());
            }
          }
        }
      });
      threads.add(runner);
    }
    for (Thread runner: threads) {
      runner.start();
    }
    for (Thread runner: threads) {
      runner.join();
    }
  }

  public static void main(String[] args) throws InterruptedException {
    int categoricalShape = Integer.parseInt(args[0]);
    int numericalShape = Integer.parseInt(args[1]);
    int concurrency = Integer.parseInt(args[2]);
    Performance test = new Performance(concurrency, categoricalShape, numericalShape);
    test.test();
  }
}
