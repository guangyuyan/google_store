package com.cloudbrain.tensorflow.serving.client;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import tensorflow.serving.Predict;
import tensorflow.serving.PredictionServiceGrpc;

import javax.annotation.Nullable;
import java.util.List;
import java.util.concurrent.Callable;

public class AsyncClient extends BaseClient {

  public interface Callback {
    void onSuccess(List<Float> r);
    void onFailure(Throwable t);
  }

  private PredictionServiceGrpc.PredictionServiceFutureStub stub;

  public AsyncClient(String host, int port) {
    ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();
    stub = PredictionServiceGrpc.newFutureStub(channel);
  }

  public void predict(List<long[]> categorical, List<float[]> continuous, String modelName,
                      final Callback callback) {
    Predict.PredictRequest request = buildRequest(continuous, categorical, modelName);
    ListenableFuture<Predict.PredictResponse> futureResponse = stub.predict(request);
    Futures.addCallback(futureResponse, new FutureCallback<Predict.PredictResponse>() {
      @Override
      public void onSuccess(@Nullable Predict.PredictResponse predictResponse) {
        List<Float> predictions = predictResponse.getOutputsOrThrow("predictions").getFloatValList();
        if (callback != null) callback.onSuccess(predictions);
      }

      @Override
      public void onFailure(Throwable throwable) {
        if (callback != null) callback.onFailure(throwable);
      }
    });
  }
}
