package com.cloudbrain.tensorflow.serving.client;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import tensorflow.serving.Predict;
import tensorflow.serving.PredictionServiceGrpc;

import javax.annotation.Nullable;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;


public class FutureClient extends BaseClient {
  private PredictionServiceGrpc.PredictionServiceFutureStub stub;

  public FutureClient(String host, int port) {
    ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();
    stub = PredictionServiceGrpc.newFutureStub(channel);
  }

  public CompletionStage<List<Float>> predict(List<long[]> categorical, List<float[]> continuous, String modelName) {
    CompletableFuture<List<Float>> future = new CompletableFuture<List<Float>>();
    Predict.PredictRequest request = buildRequest(continuous, categorical, modelName);
    ListenableFuture<Predict.PredictResponse> futureResponse = stub.predict(request);
    Futures.addCallback(futureResponse, new FutureCallback<Predict.PredictResponse>() {
      @Override
      public void onSuccess(@Nullable Predict.PredictResponse predictResponse) {
        List<Float> predictions = predictResponse.getOutputsOrThrow("predictions").getFloatValList();
        future.complete(predictions);
      }

      @Override
      public void onFailure(Throwable throwable) {
        future.completeExceptionally(throwable);
      }
    });
    return future;
  }
}
