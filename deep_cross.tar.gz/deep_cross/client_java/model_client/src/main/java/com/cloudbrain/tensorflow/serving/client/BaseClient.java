package com.cloudbrain.tensorflow.serving.client;

import org.tensorflow.framework.DataType;
import org.tensorflow.framework.TensorProto;
import org.tensorflow.framework.TensorShapeProto;
import tensorflow.serving.Model;
import tensorflow.serving.Predict;

import java.util.List;

public abstract class BaseClient {

    TensorProto buildDense(List<float[]> data) {
        TensorProto.Builder builder = TensorProto.newBuilder();
        builder.setDtype(DataType.DT_FLOAT);
        int[] shape = {data.size(), data.get(0).length};
        builder.setTensorShape(buildShape(shape));
        for (float[] val: data) {
          for (float v: val) {
            builder.addFloatVal(v);
          }
        }
        return builder.build();
    }

    TensorProto buildSparse(List<long[]> data) {
        TensorProto.Builder builder = TensorProto.newBuilder();
        builder.setDtype(DataType.DT_INT64);
        int[] shape = {data.size(), data.get(0).length};
        builder.setTensorShape(buildShape(shape));
        for (long[] val: data) {
          for (long v: val) {
            builder.addInt64Val(v);
          }
        }
        return builder.build();
    }

     Predict.PredictRequest buildRequest(List<float[]> continuous, List<long[]> categorical, String modelName) {
        Predict.PredictRequest.Builder requestBuilder = Predict.PredictRequest.newBuilder();
        TensorProto dense = buildDense(continuous);
        TensorProto sparse = buildSparse(categorical);
        Model.ModelSpec modelSpec = buildModel(modelName);
        requestBuilder.setModelSpec(modelSpec);
        requestBuilder.putInputs("continuous", dense).putInputs("categorical", sparse);
        return requestBuilder.build();
    }

    TensorShapeProto buildShape(int[] shape) {
        TensorShapeProto.Builder builder = TensorShapeProto.newBuilder();
        builder.addDim(TensorShapeProto.Dim.newBuilder().setSize(shape[0]).build());
        builder.addDim(TensorShapeProto.Dim.newBuilder().setSize(shape[1]).build());
        return builder.build();
    }

    Model.ModelSpec buildModel(String modelName) {
        Model.ModelSpec.Builder builder = Model.ModelSpec.newBuilder();
        builder.setSignatureName("serving_default");
        builder.setName(modelName);
        return builder.build();
    }
}

