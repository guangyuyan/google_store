package com.cloudbrain.tensorflow.serving.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import tensorflow.serving.Predict;
import tensorflow.serving.PredictionServiceGrpc;

import java.util.List;

public class BlockingClient extends BaseClient {
  private PredictionServiceGrpc.PredictionServiceBlockingStub stub;

  public BlockingClient(String host, int port) {
    ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();
    stub = PredictionServiceGrpc.newBlockingStub(channel);
  }

  public List<Float> predict(List<long[]> categorical, List<float[]> continuous, String modelName) {
    Predict.PredictRequest request = buildRequest(continuous, categorical, modelName);
    Predict.PredictResponse response = stub.predict(request);
    return response.getOutputsOrThrow("predictions").getFloatValList();
  }
}
