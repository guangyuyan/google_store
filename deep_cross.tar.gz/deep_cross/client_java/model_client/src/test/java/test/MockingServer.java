/*
 * MockingServer.java
 * Copyright (C) 2018 CloudBrain <chenp@>
 *
 * Distributed under terms of the CloudBrain license.
 */
package test;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import org.tensorflow.framework.TensorProto;
import tensorflow.serving.Predict;
import tensorflow.serving.PredictionServiceGrpc;

import java.util.ArrayList;
import java.util.List;


public class MockingServer {
  private Server mock;

  public MockingServer(final int port, final int size) {
    mock = ServerBuilder.forPort(port).addService(
        new PredictionServiceGrpc.PredictionServiceImplBase() {
          @Override
          public void predict(Predict.PredictRequest req,
                              StreamObserver<Predict.PredictResponse> obs) {
            List<Float> predicts = new ArrayList<>();
            for (int i = 0; i < size; ++i) {
              predicts.add((float)Math.random());
            }
            TensorProto result
                = TensorProto.newBuilder()
                             .addAllFloatVal(predicts)
                             .build();
            Predict.PredictResponse rsp
                = Predict.PredictResponse.newBuilder()
                                         .putOutputs("predictions", result)
                                         .build();
            obs.onNext(rsp);
            obs.onCompleted();
          }
        }).build();
  }

  public MockingServer start() throws Exception {
    mock.start();
    return this;
  }

  public MockingServer stop() throws Exception {
    mock.shutdown();
    mock.awaitTermination();
    return this;
  }
}
