package test;

import org.junit.Before;
import org.junit.After;
import java.util.ArrayList;
import java.util.List;


public class TestClient {
  final protected static String HOST = "localhost";
  final protected static int PORT = 9000;

  private MockingServer mock;

  protected int sampleSize;
  protected List<long[]> sparse = new ArrayList<>();
  protected List<float[]> dense = new ArrayList<>();

  @Before
  public void setUp() throws Exception {
    sampleSize = (int) (Math.random() * 500 + 500);
    float[] continuous = new float[1071];
    long[] categorical = new long[55];
    for (int cont = 0; cont < sampleSize; cont++) {
      sparse.add(categorical);
      dense.add(continuous);
    }
    mock = new MockingServer(PORT, sampleSize).start();
  }

  @After
  public void tearDown() throws Exception {
    sparse.clear();
    dense.clear();
    mock.stop();
  }
}
