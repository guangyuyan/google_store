package test;

import com.cloudbrain.tensorflow.serving.client.BlockingClient;

import java.util.List;
import org.junit.Test;
import org.junit.Assert;

public class TestBlockingClient extends TestClient {
  @Test
  public void testBlocking() throws Exception {
    List<Float> result = new BlockingClient(HOST, PORT)
                            .predict(sparse, dense, "v1");
    Assert.assertEquals(result.size(), sampleSize);
  }
}
