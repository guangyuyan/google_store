package test;

import com.cloudbrain.tensorflow.serving.client.AsyncClient;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import org.junit.Test;
import org.junit.Assert;


public class TestAsyncClient extends TestClient {
  @Test
  public void testAsync() throws Exception {
    final ArrayBlockingQueue<List<Float>> queue = new ArrayBlockingQueue<>(1);
    new AsyncClient(HOST, PORT)
       .predict(sparse, dense, "v1", new AsyncClient.Callback() {
            @Override
            public void onSuccess(List<Float> r) {
              queue.add(r);
            }
            @Override
            public void onFailure(Throwable t) {
              throw new RuntimeException(t);
            }
          });
    List<Float> result = queue.take();
    Assert.assertEquals(result.size(), sampleSize);
  }
}
