package test;

import com.cloudbrain.tensorflow.serving.client.FutureClient;

import java.util.List;
import org.junit.Test;
import org.junit.Assert;


public class TestFutureClient extends TestClient {
  @Test
  public void testFuture() throws Exception {
    List<Float> result = new FutureClient(HOST, PORT)
                            .predict(sparse, dense, "v1")
                            .toCompletableFuture()
                            .get();
    Assert.assertEquals(result.size(), sampleSize);
  }
}
