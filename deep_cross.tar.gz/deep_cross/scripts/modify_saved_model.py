#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright © 2018 CloudBrain <xyyu@>
#
# Distributed under terms of the CloudBrain license.

"""
change saved model's model_outputs signature
"""

import tensorflow as tf

tf.app.flags.DEFINE_string('input_dir', "run/oppo/ocpc/outputs/v1_test/20180927104004", 'input save_model directory')
tf.app.flags.DEFINE_string('export_dir', "./new_model/1", 'output save_model directory')
tf.app.flags.DEFINE_string('remove_label', 'predict_click', 'The output label to remove')

def save_model(session, signature_def_map, export_path):
        builder = tf.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            session, [tf.saved_model.tag_constants.SERVING],
            signature_def_map=signature_def_map,
            clear_devices=True)
        builder.save()


def remove_label_from_output_signature(input_dir, export_dir, remove_label):
    with tf.Session(graph=tf.Graph()) as sess:
        meta_graph_def = tf.saved_model.loader.load(
            sess, [tf.saved_model.tag_constants.SERVING], input_dir)
        signature_def_map = meta_graph_def.signature_def
        for key in signature_def_map.keys():
            signature_def_map[key].outputs.pop(remove_label)
        save_model(sess, signature_def_map, export_dir)

def main(unused=None):
    flags = tf.app.flags.FLAGS
    remove_label_from_output_signature(flags.input_dir,
                                       flags.export_dir,
                                       flags.remove_label)


if __name__ == "__main__":
    tf.app.run(main)
