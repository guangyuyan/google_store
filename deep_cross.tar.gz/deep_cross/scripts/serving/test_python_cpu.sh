#! /bin/bash -x
#
# cpuprofiletest.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#
#
# Only run under tensorflow serving directory
#
#listOfCpu="1 1-2 1-4 1-8 1-16"
SERVERCPU="2-9,22-29"
CLIENTCPU="0,1,20,21"
#CONCUR="1 2 4 8"
CONCUR="8"
MODEL_PATH=${HOME}/src/model/latest_6_14
MODEL_NAMES=(v1_mkl_d512_256_c3 v1_mkl_d512_256_c3_freeze_optimize)
DATA_PATH=${HOME}/src/data/new
MODEL_NUM=`expr ${#MODEL_NAMES[@]} - 1`
CURRENT_PATH=`pwd`
CPU_RECORD=${CURRENT_PATH}"/cpu_record.txt"
RESULT=${CURRENT_PATH}"/result.txt"

taskset -c 10 python record_cpu.py ${SERVERCPU} ${CLIENTCPU} >> ${CPU_RECORD} &
for model_index in `seq 0 ${MODEL_NUM}`
do
  ENV="OMP_WAIT_POLICY=PASSIVE KMP_AFFINITY=granularity=fine,verbose,compact,1,0"
  FLAGS="--port=9000 --model_name=model_v1 --model_base_path=${MODEL_PATH}/${MODEL_NAMES[${model_index}]} "
  env ${ENV} taskset -c ${SERVERCPU} bazel-bin/tensorflow_serving/model_servers/tensorflow_model_server ${FLAGS} &

  pushd ~/src/deep_cross/vivo
  echo -e "ModelName\tConcur\tQPS\tMaxTime\tAverageTime\tMinTime\t99%MaxTime\t 90%MaxTime" >> ${RESULT}
  for concur in ${CONCUR}
  do
    echo -e -n "${MODEL_NAMES[${model_index}]}\t$concur\t" >> ${RESULT}
    echo -e "Start of Model Name: ${MODEL_NAMES[${model_index}]}, Concur: $concur" >> ${CPU_RECORD}
    taskset -c ${CLIENTCPU} python ~/src/deep_cross/vivo/model_client.py --server=localhost:9000 --work_dir=${DATA_PATH} --concurrency=$concur >> ${RESULT}
    echo "End of Model Name: ${MODEL_NAMES[${model_index}]}, Concur: ${concur}" >> ${CPU_RECORD}
  done
  popd
  killall tensorflow_model_server
  echo "killall tensorflow_model_server"
done

killall python
