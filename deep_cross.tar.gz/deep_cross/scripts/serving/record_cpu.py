#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Sum Cpu usage
"""

import psutil
import sys

def record_cpu_usage(server_cpus, client_cpus):

    server_cpu_list = parse_cpu(server_cpus)
    client_cpu_list = parse_cpu(client_cpus)
    server_record = {}
    client_record = {}
    for i in range(10000):
        cpus = psutil.cpu_percent(interval=10, percpu=True)
        server_record['Total Server'] = 0
        server_record['Max Server'] = 0
        server_record['Min Server'] = 200
        for scpu in server_cpu_list:
            server_record['Total Server'] += cpus[scpu]
            server_record['Max Server'] = max(server_record['Max Server'],
                                              cpus[scpu])
            server_record['Min Server'] = min(server_record['Min Server'],
                                              cpus[scpu])
        client_record['Max Client'] = 0
        for ccpu in client_cpu_list:
            client_record['Max Client'] = max(client_record['Max Client'],
                                              cpus[ccpu])
        for key in server_record:
            print('%s: %0.2f\t' %(key, server_record[key])),
        for key in client_record:
            print('%s: %0.2f\t'%(key, client_record[key]))
        sys.stdout.flush()


def parse_cpu(cpu_string):
    cpu_str_list = cpu_string.split(',')
    cpu_list = []
    for cpu_str in cpu_str_list:
        cpu_str = cpu_str.split('-')
        if(len(cpu_str)>1):
            cpu_list += list(range(int(cpu_str[0]), int(cpu_str[1])+1))
        else:
            cpu_list.append(int(cpu_str[0]))
    return cpu_list

if __name__ == "__main__":
    record_cpu_usage(sys.argv[1], sys.argv[2])
