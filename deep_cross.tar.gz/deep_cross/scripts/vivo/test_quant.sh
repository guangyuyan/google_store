#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v7
mkdir -p summaries

CUDA_VISIBLE_DEVICES=0 python -m module.vivo.predictor \
  --model $model_ver \
  --deep_layers 512,256 --cross_layers 3 \
  --prebatch 256 --batch_size 4 \
  --train_data /ssd/users/xjfan/vivo/newsfeed_0620/train.txt \
  --valid_data /ssd/users/xjfan/vivo/newsfeed_0620/test.txt \
  --quantize=True \
  --summaries_dir ./summaries/$1_test \
  --model_dir outputs --model_prefix ${model_ver}_$1_best
