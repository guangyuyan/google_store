#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# For train model from graph file

model_ver=v1
base_dir=./run/vivo
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/vivo/train_lite.sh  ${summaries_dir}

python3 -m module.vivo.trainer_lite \
  --input_graph ${base_dir}/graph.meta \
  --model_name ${model_ver}_$1 \
  --model_path ${outputs_dir} \
  --learning_rate 0.0001 --epochs 10 \
  --data_per_valid 2097152 --patient_valid_passes 2 \
  --train_data /ssd/users/xjfan/vivo/newsfeed_0622/train.txt \
  --valid_data /ssd/users/xjfan/vivo/newsfeed_0622/valid.txt \
  --prebatch 256 --batch_size 16 \
  --parallel_parse 8 \
  --prefetch_buffer 512 \
  --shuffle_buffer 512 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:2} \
  2>&1 | tee ${summaries_dir}/$1.log

