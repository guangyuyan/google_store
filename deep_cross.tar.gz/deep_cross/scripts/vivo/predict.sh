#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
outputs_dir=./run/vivo/outputs

python3 -m module.vivo.predictor \
  --valid_data /ssd/users/xjfan/vivo/newsfeed_0622/valid.txt \
  --prebatch 256 --batch_size 4 \
  --model_dir ${outputs_dir} \
  --model_prefix $1 \
  --input_graph ${outputs_dir}/$1.meta \
  ${@:2}
