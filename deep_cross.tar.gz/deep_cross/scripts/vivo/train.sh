#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
base_dir=./run/vivo
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/vivo/train.sh ${summaries_dir}

python -m module.vivo.trainer \
  --model ${model_ver} \
  --model_name ${model_ver}_$1 \
  --deep_layers 256 \
  --cross_layers 4 \
  --learning_rate 0.00005 \
  --epochs 10 \
  --data_per_valid 5000000 \
  --patient_valid_passes 10 \
  --train_data /ssd/users/xjfan/vivo/newsfeed_0622/train.txt \
  --valid_data /ssd/users/xjfan/vivo/newsfeed_0622/valid.txt \
  --prebatch 256 \
  --batch_size 4 \
  --parallel_parse 8 \
  --parallel_reads_per_file 8 \
  --prefetch_buffer 512 \
  --shuffle_buffer 512 \
  --model_path ${outputs_dir} \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:2} \
  2>&1 | tee ${summaries_dir}/$1.log

