#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v7
summaries=./run/vivo/summaries
outputs_dir=./run/vivo/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/vivo/train.sh ${summaries_dir}

SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"

CUDA_VISIBLE_DEVICES=$2 python -m module.vivo.trainer \
  --model $model_ver --model_name outputs/${model_ver}_$1 \
  --deep_layers 512,256 --cross_layers 3 \
  --learning_rate 0.00005 --epochs 200 \
  --data_per_valid 300000 --patient_valid_passes 2 \
  --prebatch 256 --batch_size 4 \
  --train_data ${SCRIPTPATH}/quant_data.txt \
  --valid_data ${SCRIPTPATH}/quant_data.txt \
  --quantize=True --quant_delay=50 \
  --model_path ${outputs_dir} --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} ${@:3} \
  2>&1 | tee ${summaries_dir}/$1.log

cp $0 $summaries_dir
