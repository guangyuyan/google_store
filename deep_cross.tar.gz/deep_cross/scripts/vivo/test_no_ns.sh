#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
mkdir -p summaries

CUDA_VISIBLE_DEVICES=0 python -m module.vivo.predictor \
--model $model_ver \
--deep_layers 256 --cross_layers 4 \
--ns_rate=0.2 \
--valid_data /home/tangkh/src/train \
--train_data /home/tangkh/src/valid \
--prebatch 256 --batch_size 4 \
--summaries_dir ./summaries/$1_test \
--model_dir ./outputs/ --model_prefix ${model_ver}_$1_best
