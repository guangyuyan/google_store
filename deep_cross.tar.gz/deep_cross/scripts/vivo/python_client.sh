#! /bin/sh -x
#
# cpuprofiletest.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#
#
# Only run under tensorflow serving directory
#
#listOfCpu="1 1-2 1-4 1-8 1-16"
listOfCpu="32"
concurNum="1 2 4 8"
MODEL_PATH=${HOME}/src/model/vivo_models/v4
DATA_PATH=${HOME}/src/data/new
for cpu in $listOfCpu
do
  ENV="OMP_WAIT_POLICY=PASSIVE KMP_AFFINITY=granularity=fine,verbose,compact,1,0"
  FLAGS="--port=9000 --model_name=model_v1 --model_base_path=${MODEL_PATH} "
  env ${ENV} bazel-bin/tensorflow_serving/model_servers/tensorflow_model_server ${FLAGS} &

  echo "Concur\tQPS\tMaxT\tAverageT\tMinT\t99%MaxT\t 90%MaxT" >> result.txt
  for concur in $concurNum
  do
    echo -n "$concur\t" >> result.txt
    python -m module.vivo.model_client --server=localhost:9000 --work_dir ${DATA_PATH} --concurrency=$concur >> result.txt
  done
  killall tensorflow_model_server
  echo "killall tensorflow_model_server"
done
