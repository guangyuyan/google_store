#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
summaries=./run/vivo/summaries
outputs_dir=./run/vivo/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/vivo/train.sh ${summaries_dir}

CUDA_VISIBLE_DEVICES=$2 python -m module.vivo.trainer \
  --model ${model_ver} --model_name ${model_ver}_$1 \
  --deep_layers 256 --cross_layers 4 \
  --learning_rate 0.00005 --epochs 10 \
  --data_per_valid 5000000  --patient_valid_passes 5 \
  --train_data /home/tangkh/src/train \
  --valid_data /home/tangkh/src/valid \
  --prebatch 256 --batch_size 4 \
  --hot_checkpoint = ${outputs_dir}/test_v1_best \
  --hot_mode=emb_only \
  --model_path ${outputs_dir} --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  2>&1 | tee ${summaries_dir}/$1.log

