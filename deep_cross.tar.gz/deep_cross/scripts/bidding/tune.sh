#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
t_stamp="$(date "+%Y%m%d_%H%M%S")"
model_name=${model_ver}_tune
summaries_dir=./run/bidding/summaries/${model_ver}_${1}_${t_stamp}/meta
outputs_dir=./run/bidding/outputs/${model_name}_${t_stamp}/meta
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/bidding/train.sh ${summaries_dir}

INPUT_DIR=/ssd/users/${USER}/data/bidding/14_0

python3 -m module.bidding.auto_tuner \
  --model ${model_ver} \
  --model_name ${model_name} \
  --model_path ${outputs_dir} \
  --deep_layers 512,256 --cross_layers 3 \
  --learning_rate 0.0001 --epochs 10 \
  --data_per_valid 2097152 --patient_valid_passes 3 \
  --train_data ${INPUT_DIR}/bidding_train_train.tf \
  --valid_data ${INPUT_DIR}/bidding_train_valid.tf \
  --voc_dir ${INPUT_DIR}/voc_size.txt \
  --prebatch 256 --batch_size 16 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:1} \
  2>&1 | tee ${summaries_dir}/tune.txt

