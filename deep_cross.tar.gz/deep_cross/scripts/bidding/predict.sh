#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=$1
outputs_dir=$2
mkdir -p ${outputs_dir}
model_prefix=${model_ver}_best

python3 -m module.bidding.predictor \
  --gzip \
  --prebatch 256 \
  --batch_size 16 \
  --model_dir ${outputs_dir} \
  --model_prefix ${model_prefix} \
  --input_graph ${outputs_dir}/${model_prefix}.meta \
  --predictions ${outputs_dir}/predictions.txt \
  ${@:3} \
  2>&1 | tee ${outputs_dir}/${1}_predict_log.txt
