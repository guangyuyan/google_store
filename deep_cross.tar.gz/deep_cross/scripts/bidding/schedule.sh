#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=$1
summaries_dir=$2
outputs_dir=$3
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/bidding/train.sh ${summaries_dir}

lr_schedule_mode=2
learning_rate=1e-6
lr_schedule_max=1
stop_steps=3000

python3 -m module.bidding.trainer \
  --gzip \
  --model ${model_ver} \
  --model_name ${model_ver} \
  --model_path ${outputs_dir} \
  --deep_layers 512,256 \
  --cross_layers 3 \
  --epochs 10 \
  --data_per_valid 2097152 \
  --patient_valid_passes 2 \
  --prebatch 256 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  --lr_schedule_mode ${lr_schedule_mode} \
  --learning_rate ${learning_rate} \
  --lr_schedule_max ${lr_schedule_max} \
  --stop_steps ${stop_steps} \
  --lr_schedule_update_step 1 \
  --lr_schedule_print_step 100 \
  ${@:4} \
  2>&1 | tee ${summaries_dir}/${model_ver}_train_log.txt
