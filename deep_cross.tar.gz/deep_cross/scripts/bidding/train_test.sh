#! /bin/bash -x
#
# mytest.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

MODEL_VER=${1:-'v1'}
TRAIN_DAY=${2:-14}
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=run/bidding/summaries/${MODEL_VER}_${t_stamp}
outputs_dir=run/bidding/outputs/${MODEL_VER}_${t_stamp}

INPUT_DIR=data/bidding
MAX_EPOCH=30
BATCH_SIZE=32
SHUFFLE_BUF=2048

for i in {0..15}
do
  for DELAY in '--with_conv_delay' ''
  do
    for EVENT in '--with_event_feature' ''
    do
      for X in '--separated_x' ''
      do
        for WEIBULL in '--weibull_conv_delay' ''
        do
          NAME_SCHEDULE=${TRAIN_DAY}_${i}${DELAY}${EVENT}${X}${WEIBULL}
          ./scripts/bidding/schedule.sh $MODEL_VER ${summaries_dir}_$NAME_SCHEDULE \
           ${outputs_dir}_$NAME_SCHEDULE \
           ${DELAY} ${EVENT} ${X} ${WEIBULL} \
           --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/train_split.list \
           --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/valid.list \
           --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt \
           --shuffle_buffer ${SHUFFLE_BUF} \
           --batch_size ${BATCH_SIZE} 
          for LRMODE in -1,-1 1,1 1,2 1,3 2,1 2,2 2,3; do 
            IFS=',' read MODE_COST MODE_BEST <<< "${LRMODE}"
            if [ $MODE_COST == -1 ]
            then
              LR=1e-4
            else
              LR=$(python3 ./scripts/parse_summary.py \
              --in_path ${summaries_dir}_$NAME_SCHEDULE/train \
              --mode_cost ${MODE_COST} \
              --mode_best ${MODE_BEST} 2>&1)
            fi
            echo 'Best LR Found' ${LR}
            NAME_RUN=${TRAIN_DAY}_${i}${DELAY}${EVENT}${X}${WEIBULL}'--mode-cost'${MODE_COST}'--mode-best'${MODE_BEST}'--lr'${LR}
            ./scripts/bidding/train.sh $MODEL_VER ${summaries_dir}_$NAME_RUN \
              ${outputs_dir}_$NAME_RUN \
              ${DELAY} ${EVENT} ${X} ${WEIBULL} \
              --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/train_split.list \
              --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/valid.list \
              --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt \
              --learning_rate ${LR} \
              --shuffle_buffer ${SHUFFLE_BUF} \
              --batch_size ${BATCH_SIZE} \
              --epochs ${MAX_EPOCH}
            ./scripts/bidding/predict.sh $MODEL_VER ${outputs_dir}_$NAME_RUN \
              ${EVENT} \
              --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/test.list
            python3 -m module.base.plot_cvr_calibration \
              -p ${outputs_dir}_$NAME_RUN/predictions.txt \
              -o ${outputs_dir}_$NAME_RUN/cvr_clibration.png
          done
        done
      done
    done
  done
done

