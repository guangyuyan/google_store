#! /bin/bash -x
#
# predict_test.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#
# ./scripts/bidding/predict_test.sh //For predict with train_day=14, ctcvr
# ./scripts/bidding/predict_test.sh 7_ //For predict with train_day=7 ctcvr
# ./scripts/bidding/predict_test.sh '' click_ //Fo predict with train_day=14 cvr on click true only

TRAIN_DAY=${1:-14}
INPUT_DIR=/ssd/users/${USER}/data/bidding

echo 'For Shorter Real bidding_test, without Delay: '

for i in {0..15}
do
  ./scripts/bidding/predict.sh v1_no_delay_${TRAIN_DAY}_${i}_best \
    --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/shorter_real_bidding_test.tf \
    --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/shorter_real_bidding_test.tf \
    --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt
done

echo 'For Shorter Real bidding_test, with Delay: '

for i in {0..15}
do
  ./scripts/bidding/predict.sh v1_with_delay_${TRAIN_DAY}_${i}_best \
    --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/shorter_real_bidding_test.tf \
    --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/shorter_real_bidding_test.tf \
    --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt
done

echo 'For real bidding_test, without Delay: '
for i in {0..15}
do
  ./scripts/bidding/predict.sh v1_no_delay_${TRAIN_DAY}_${i}_best \
    --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/real_bidding_test.tf \
    --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/real_bidding_test.tf \
    --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt
done

echo 'For real bidding_test, with Delay: '

for i in {0..15}
do
  ./scripts/bidding/predict.sh v1_with_delay_${TRAIN_DAY}_${i}_best \
    --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/real_bidding_test.tf \
    --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/real_bidding_test.tf \
    --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt
done
