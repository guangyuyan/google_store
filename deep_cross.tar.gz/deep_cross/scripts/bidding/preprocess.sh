#! /bin/bash
#
# preprocess.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

TRAIN_DAY=${1:-14}
OUTPUT_DIR=data/bidding
INPUT_DIR=/ssd/users/${USER}/data/bidding

# the data will be split into multiple copies for shuffling. Total number of files for splitting is NUM_TRAIN_FILES+NUM_VALID_FILES
NUM_TRAIN_FILES=9
NUM_VALID_FILES=1

mkdir -p $OUTPUT_DIR

python3 -m module.bidding.delay_preprocess --prebatch 256 --valid_pct 0 \
  --output_dir ${OUTPUT_DIR} --train_day $TRAIN_DAY --with_event_feature \
  --input_dir ${INPUT_DIR} \
  --gzip
  # --num_datasets 1 \
  # --data_check --voc_dir ${OUTPUT_DIR}/${TRAIN_DAY}_0/voc_size.txt \

for i in {0..15}
do
  python3 ./scripts/split_tfrecord.py --src ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/bidding_train.tf \
    --gzip \
    --dst ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/bidding_train_split.tf \
    --dst_list ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/split.list \
    --copies $((NUM_TRAIN_FILES+NUM_VALID_FILES))

  #generate train.list and test.list from split.list
  head -n ${NUM_TRAIN_FILES} ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/split.list > ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/train.list
  tail -n ${NUM_VALID_FILES} ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/split.list > ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/valid.list  
  echo ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/real_bidding_test.tf > ${OUTPUT_DIR}/${TRAIN_DAY}_${i}/test.list
done
