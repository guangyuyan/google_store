#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# for export model to graph def

model_ver=v1
base_dir=./run/bidding
mkdir -p ${base_dir}

python3 -m module.bidding.build_graph \
  --with_conv_delay \
  --model ${model_ver} \
  --voc_dir /ssd/users/xyyu/data/bidding/14_0/voc_size.txt \
  --deep_layers 512,256 --cross_layers 3 \
  --learning_rate 0.0001 --epochs 10 \
  --prebatch 256 --batch_size 16 \
  --export_graph ${base_dir}/graph.meta \
  ${@:2}
