#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <ydfeng@>
#
# Distributed under terms of the CloudBrain license.

"""

"""
import argparse
from copy import copy
import pandas as pd
from multiprocessing import Pool, cpu_count


def apply_parallel(func, keys, cpu_rate=1.0):
    p = Pool(int(cpu_count()*cpu_rate))
    p.map(func, keys)
    p.close()
    p.join()


def join_ts_by_key(key, ts_field, prefix, df, save_dir):
    cols = copy(key)
    cols.append(ts_field)

    df_tmp = df.loc[:, cols]
    df_tmp.loc[:, ts_field] = df_tmp.loc[:, ts_field] .astype('str')
    df_tmp = df_tmp.groupby(key, as_index=False).agg(','.join)

    if len(key) > 1:
        df_tmp['key'] = \
            df_tmp[key[0]].astype(str) + "X" + df_tmp[key[1]].astype(str)
    else:
        df_tmp['key'] = df_tmp[key[0]]

    df_tmp = df_tmp.loc[:, ["key", ts_field]]
    save_path = '%s/%s_%s.csv' % (save_dir, prefix, '_'.join(key))
    df_tmp.to_csv(save_path, header=None, sep='\t', index=False)
    print('Complete:%s, [%s]' % (key, ts_field))


def make_ts(args):
    join_ts_by_key(*args)


def init_keys():
    cats = ['cat1', 'cat2', 'cat4', 'cat5', 'cat6', 'cat8', 'cat9']
    keys = []
    for cat in cats:
        for cat2 in cats:
            if int(cat[-1]) < int(cat2[-1]):
                keys.append([cat, cat2])
        keys.append([cat])
        keys.append(['campaign', cat])
    keys.append(['campaign'])
    return keys


def load_file(args):
    chunks = pd.read_csv(
        args.data_file, sep='\t', compression='gzip',
        chunksize=args.chunksize,
        usecols=[
            'timestamp', 'campaign', 'conversion', 'click',
            'conversion_timestamp',
            'cat1', 'cat2', 'cat4', 'cat5', 'cat6', 'cat8', 'cat9'])

    df = pd.concat(
        [c.apply(pd.to_numeric, downcast='unsigned') for c in chunks])
    return df


def main(args):
    df = load_file(args)
    click_df = df.loc[df.click == 1]
    conv_df = df.loc[df.conversion == 1]
    keys = init_keys()

    # imp ts, return all timestamp
    imp_args = [(k, 'timestamp', 'imp', df, args.output) for k in keys]

    # conv ts, if conversion == 1 return conversion_timestamp
    conv_args = \
        [(k, 'conversion_timestamp', 'conv', conv_df, args.output) for k in keys]

    # all click ts,  return timestamp, if click == 1
    clk_args = [(k, 'timestamp', 'click', click_df, args.output) for k in keys]

    apply_parallel(make_ts, imp_args, 0.5)
    apply_parallel(make_ts, conv_args, 0.5)
    apply_parallel(make_ts, clk_args, 0.5)


if __name__ == "__main__":
    data_file = \
        "/var/sftp/users/ydfeng/criteo/criteo_attribution_dataset.tsv.gz"

    parser = argparse.ArgumentParser(description='make ts files')
    parser.add_argument(
        '-d', '--data_file', required=False, type=str, default=data_file)
    parser.add_argument(
        '-s', '--chunksize', required=False, type=int, default=500000)
    parser.add_argument(
        '-o', '--output', required=False, type=str,
        default="/var/sftp/users/ydfeng/criteo/data")

    args = parser.parse_args()
    main(args)
