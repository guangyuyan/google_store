#! /bin/bash -x
#
# re_train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
TRAIN_DAY=${1:-14}
INPUT_DIR=/ssd/users/${USER}/data/bidding
outputs_dir=./run/bidding/outputs

./scripts/bidding/train.sh with_delay_${TRAIN_DAY}_0 --with_conv_delay \
  --train_data ${INPUT_DIR}/${TRAIN_DAY}_0/bidding_train_train.tf \
  --valid_data ${INPUT_DIR}/${TRAIN_DAY}_0/bidding_train_valid.tf \
  --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_0/voc_size.txt \
  --pretrain_voc_dir ${INPUT_DIR}/voc_size.txt \
  --emb_dir ${INPUT_DIR}/emb_size.txt \
  --output_emb_ckpt ${INPUT_DIR}/${TRAIN_DAY}_0/emb_ckpt.npy \
  --hot_mode pretrain

for i in {1..1}
do
  j=$((i-1))
  ./scripts/bidding/train.sh with_delay_${TRAIN_DAY}_${i} --with_conv_delay \
    --train_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/bidding_train_train.tf \
    --valid_data ${INPUT_DIR}/${TRAIN_DAY}_${i}/bidding_train_valid.tf \
    --voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${i}/voc_size.txt \
    --pretrain_voc_dir ${INPUT_DIR}/${TRAIN_DAY}_${j}/voc_size.txt \
    --emb_dir ${INPUT_DIR}/emb_size.txt \
    --input_emb_ckpt ${INPUT_DIR}/${TRAIN_DAY}_${j}/emb_ckpt.npy \
    --output_emb_ckpt ${INPUT_DIR}/${TRAIN_DAY}_${i}/emb_ckpt.npy \
    --hot_checkpoint ${outputs_dir}/${model_ver}_with_delay_${TRAIN_DAY}_${j}_best \
    --hot_mode pretrain
done



