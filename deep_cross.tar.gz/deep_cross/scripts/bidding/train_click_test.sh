#! /bin/bash -x
#
# mytest.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

for i in {0..15}
do
  ./scripts/bidding/train.sh no_delay_click_$1${i} \
    --train_data /ssd/users/xyyu/data/bidding/$1${i}/bidding_train.tf \
    --valid_data /ssd/users/xyyu/data/bidding/$1${i}/bidding_valid.tf \
    --voc_dir /ssd/users/xyyu/data/bidding/$1${i}/voc_size.txt \
    --cvr_on_click_only
  ./scripts/bidding/train.sh with_delay_click_$1${i} --with_conv_delay \
    --train_data /ssd/users/xyyu/data/bidding/$1${i}/bidding_train.tf \
    --valid_data /ssd/users/xyyu/data/bidding/$1${i}/bidding_valid.tf \
    --voc_dir /ssd/users/xyyu/data/bidding/$1${i}/voc_size.txt \
    --cvr_on_click_only
done

