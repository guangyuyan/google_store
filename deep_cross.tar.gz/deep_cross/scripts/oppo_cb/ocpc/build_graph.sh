#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# for export model to graph def

model_ver=v1
base_dir=./run/oppo/ocpc
mkdir -p ${base_dir}

python3 -m module.oppo.ocpc.build_graph \
  --with_conv_delay True \
  --weibull_conv_delay True \
  --model ${model_ver} \
  --deep_layers 512,256 \
  --cross_layers 3 \
  --learning_rate 0.0001 \
  --feature_schema_file /ssd/users/xjfan/oppo/schema_20180904.csv \
  --export_graph ${base_dir}/graph.meta \
  ${@:2}
