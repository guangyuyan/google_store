#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <xyang@>
#
# Distributed under terms of the CloudBrain license.
#


model_ver=v1
summaries_dir=./run/oppo/ocpc/summaries
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries_dir/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}

CUDA_VISIBLE_DEVICES=2 python3 -m module.oppo.ocpc.data_reader \
  --model ${model_ver} \
  --model_name ${model_ver}_$1 \
  --epochs 1 \
  --feature_schema_file /ssd/users/xjfan/oppo/schema_20180904.csv \
  --valid_data /ssd/users/xjfan/oppo/valid.txt \
  --prebatch 256 \
  --batch_size 4 \
  --data_stats_file ${summaries_dir}/data_stats.txt \
  2>&1 | tee ${summaries_dir}/$1.log

