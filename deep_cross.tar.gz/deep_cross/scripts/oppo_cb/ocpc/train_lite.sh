#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# For train model from graph file

model_ver=v1
base_dir=./run/oppo/ocpc
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/oppo/ocpc/train_lite.sh  ${summaries_dir}

CUDA_VISIBLE_DEVICES=0 python3 -m module.oppo.ocpc.trainer_lite \
  --input_graph ${base_dir}/graph.meta \
  --model_name ${model_ver}_$1 \
  --model_path ${outputs_dir} \
  --epochs 10 \
  --data_per_valid 300000 \
  --patient_valid_passes 5 \
  --train_data /ssd/users/xjfan/oppo/train.txt \
  --valid_data /ssd/users/xjfan/oppo/valid.txt \
  --feature_schema_file /ssd/users/xjfan/oppo/schema_20180904.csv \
  --prebatch 256 \
  --batch_size 4 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:2} \
  2>&1 | tee ${summaries_dir}/$1.log
