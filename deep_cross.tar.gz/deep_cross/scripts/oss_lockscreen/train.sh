#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
base_dir=./run/oss_lockscreen
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/oss_lockscreen/train.sh ${summaries_dir}

CUDA_VISIBLE_DEVICES=0 python3 -m module.oss_lockscreen.trainer \
  --gzip \
  --model ${model_ver} \
  --model_name ${model_ver}_$1 \
  --model_path ${outputs_dir} \
  --deep_layers 512,256 --cross_layers 3 \
  --learning_rate 0.0001 --epochs 1 \
  --data_per_valid 300000 --patient_valid_passes 10 \
  --train_data /ssd/users/xyyu/data/oss_lockscreen/train.txt \
  --valid_data /ssd/users/xyyu/data/oss_lockscreen/valid.txt \
  --voc_dir /ssd/users/xyyu/data/oss_lockscreen/vocabulary_summary.txt \
  --prebatch 256 --batch_size 4 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  2>&1 | tee ${summaries_dir}/$1.log
