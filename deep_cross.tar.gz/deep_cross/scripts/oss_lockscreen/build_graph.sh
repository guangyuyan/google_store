#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# for export model to graph def

model_ver=v1
base_dir=./run/oss_lockscreen
mkdir -p ${base_dir}

python3 -m module.oss_lockscreen.build_graph \
  --gzip \
  --model ${model_ver} \
  --voc_dir /ssd/users/xyyu/data/oss_lockscreen/vocabulary_summary.txt \
  --deep_layers 512,256 --cross_layers 3 \
  --learning_rate 0.0001 --epochs 10 \
  --prebatch 256 --batch_size 16 \
  --export_graph ${base_dir}/graph.meta \
  ${@:2}
