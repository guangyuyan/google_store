#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# For train model from graph file

model_ver=v1
base_dir=./run/oss_lockscreen
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/oss_lockscreen/train_lite.sh  ${summaries_dir}

python3 -m module.oss_lockscreen.trainer_lite \
  --gzip \
  --input_graph ${base_dir}/graph.meta \
  --model_name ${model_ver}_$1 \
  --model_path ${outputs_dir} \
  --epochs 10 \
  --data_per_valid 2097152 --patient_valid_passes 2 \
  --train_data /ssd/users/xyyu/data/oss_lockscreen/train.txt \
  --valid_data /ssd/users/xyyu/data/oss_lockscreen/valid.txt \
  --prebatch 256 --batch_size 4 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:2} \
  2>&1 | tee ${summaries_dir}/$1.log

