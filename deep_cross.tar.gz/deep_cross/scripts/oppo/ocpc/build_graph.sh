#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# for export model to graph def
set -o pipefail -e
model_ver=v1

CUDA_VISIBLE_DEVICES=0 python3 -m module.oppo.ocpc.build_graph \
  --with_conv_delay \
  --weibull_conv_delay \
  --model ${model_ver} \
  --deep_layers 512,512 \
  --cross_layers 3 \
  --learning_rate 0.0001 \
  --cvr_signature_only \
  "$@" \
