#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

# For train model from graph file
set -o pipefail -e
online_ver=${1?param 1 should be online version}
model_name=${2?param 2 should be model name}
model_ver=v1
base_dir=./run/oppo/ocpc/${online_ver}
summaries=${base_dir}/summaries
outputs_dir=${base_dir}/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${model_name}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/oppo/ocpc/train_lite.sh  ${summaries_dir}

CUDA_VISIBLE_DEVICES=0 python3 -m module.oppo.ocpc.trainer_lite \
  --model_name ${model_ver}_${model_name} \
  --model_path ${outputs_dir} \
  --epochs 5 \
  --data_per_valid 3000000 \
  --patient_valid_passes 6 \
  --prebatch 256 \
  --batch_size 16 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:3} \
  2>&1 | tee ${summaries_dir}/${model_name}.log \

