#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <xyang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=$1
summaries_dir=$2
outputs_dir=$3
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/oppo/ocpc/train.sh ${summaries_dir}

CUDA_VISIBLE_DEVICES=0 python3 -m module.oppo.ocpc.trainer \
  --model ${model_ver} \
  --model_name ${model_ver} \
  --model_path ${outputs_dir} \
  --deep_layers 512,256 \
  --cross_layers 3 \
  --learning_rate 0.0001 \
  --epochs 10 \
  --data_per_valid 300000 \
  --patient_valid_passes 5 \
  --prebatch 256 \
  --batch_size 4 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:4} \
  2>&1 | tee ${summaries_dir}/${model_ver}_train_log.txt

