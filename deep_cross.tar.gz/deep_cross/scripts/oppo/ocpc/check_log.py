import os
import sys
import argparse

if not os.path.exists('Daily_Check'):
    os.mkdir('Daily_Check')
parser = argparse.ArgumentParser(description='Check Daily Log')
parser.add_argument('-t', "--date", help='Current Date', required=True)
parser.add_argument('-w', "--where", choices=['gpu', 'server'], help='Choose where to run this script', required=True)
args = parser.parse_args()
date_time = args.date

homepath = ''
if args.where == 'gpu':
    homepath = '/home/devops'
logpath = homepath + '/gpudata/training/deep_cross/run/oppo/ocpc/tf0p3_graph1p0/summaries/'
logdir = os.listdir(logpath)
logname = [x for x in logdir if date_time in x][0]
logname_total = logpath + logname + '/tf0p3_graph1p0_' + date_time + '.log'
if not os.path.exists('Daily_Check/' + date_time):
    os.mkdir('Daily_Check/' + date_time)
daily_check_dir = 'Daily_Check/' + date_time
with open(homepath + '/gpudata/tfrecord/v0.3/{0}/schema.csv'.format(str(int(date_time) - 1)), 'r') as f:
    c = f.read()
with open(daily_check_dir + '/schema_{0}.csv'.format(str(int(date_time) - 1)), 'w') as f:
    f.write(c)


def check(last_train_loss, last_train_norm_loss, final_best_valid_cvr_roc, final_best_valid_cvr_calibration):
    LAST_TRAIN_LOSS_UPPER_THRESHOLD=0.3
    LAST_TRAIN_NORM_LOSS_UPPER_THRESHOLD=1.05
    LAST_TRAIN_NORM_LOSS_LOWER_THRESHOLD=0.75
    FINAL_BEST_VALID_CVR_ROC_LOWER_THRESHOLD=0.82
    FINAL_BEST_VALID_CVR_CALIBRATION_UPPER_THRESHOLD=1.2
    FINAL_BEST_VALID_CVR_CALIBRATION_LOWER_THRESHOLD=0.9
    
    
    
    print('###############################\ncheck last_train_loss\nlast_train_loss should be < %.1f' % LAST_TRAIN_LOSS_UPPER_THRESHOLD)
    if (float(last_train_loss) < LAST_TRAIN_LOSS_UPPER_THRESHOLD):
        print('last_train_loss: ' + last_train_loss)
    else:
        print('last_train_loss error: ' + last_train_loss)

    print(
        '###############################\ncheck last_train_norm_loss\nlast_train_norm_loss should be > %.1f and < %.1f' %(LAST_TRAIN_NORM_LOSS_LOWER_THRESHOLD,LAST_TRAIN_NORM_LOSS_UPPER_THRESHOLD))
    if ((float(last_train_norm_loss) < LAST_TRAIN_NORM_LOSS_UPPER_THRESHOLD) and (float(last_train_norm_loss) > LAST_TRAIN_NORM_LOSS_LOWER_THRESHOLD)):
        print('last_train_norm_loss: ' + last_train_norm_loss)
    else:
        print('last_train_norm_loss error: ' + last_train_norm_loss)

    print('###############################\ncheck last_train_loss\nfinal_best_valid_cvr_roc should be > %.1f'%FINAL_BEST_VALID_CVR_ROC_LOWER_THRESHOLD)
    if (float(final_best_valid_cvr_roc) > FINAL_BEST_VALID_CVR_ROC_LOWER_THRESHOLD):
        print('final_best_valid_cvr_roc : ' + final_best_valid_cvr_roc)
    else:
        print('final_best_valid_cvr_roc error: ' + final_best_valid_cvr_roc)

    print(
        '###############################\ncheck final_best_valid_cvr_calibration\nfinal_best_valid_cvr_calibration should be > %.1f and < %.1f'%(FINAL_BEST_VALID_CVR_CALIBRATION_LOWER_THRESHOLD,FINAL_BEST_VALID_CVR_CALIBRATION_UPPER_THRESHOLD))
    if (((float(final_best_valid_cvr_calibration) < FINAL_BEST_VALID_CVR_CALIBRATION_UPPER_THRESHOLD)) and (FINAL_BEST_VALID_CVR_CALIBRATION_LOWER_THRESHOLD < float(final_best_valid_cvr_calibration))):
        print('final_best_valid_cvr_calibration : ' + final_best_valid_cvr_calibration)
    else:
        print('final_best_valid_cvr_calibration error: ' + final_best_valid_cvr_calibration)


with open(logname_total, 'r') as f:
    c = f.readlines()

if 'Save final checkpoint' in c[-1]:
    with open(daily_check_dir + '/tf0p3_graph1p0_' + date_time + '.log', 'w') as f:
        f.write(''.join(c))
    last_train = [x for x in c if 'Train' in x][-1].split(' ')
    final_best_valid = ''.join([x for x in c if 'Final' in x]).split(' ')
    for item in last_train:
        if item.startswith('loss'):
            last_train_loss = item.strip().split('=')[1]
        if item.startswith('norm_loss'):
            last_train_norm_loss = item.strip().split('=')[1]

    for item in final_best_valid:
        if item.startswith('cvr_roc'):
            final_best_valid_cvr_roc = item.strip().split('=')[1]
        if item.startswith('cvr_calibration'):
            final_best_valid_cvr_calibration = item.strip().split('=')[1]

    check(last_train_loss, last_train_norm_loss, final_best_valid_cvr_roc, final_best_valid_cvr_calibration)
    os.system('sz '+daily_check_dir+'/*')
else:
    print('Error : No final flag. There may be some errors in training steps or the model is still training')
