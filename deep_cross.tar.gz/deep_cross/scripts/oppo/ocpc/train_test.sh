#! /bin/bash -x
#
# mytest.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

MODEL_VER=${1:-'v1'}
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=run/oppo/ocpc/summaries/${MODEL_VER}_${t_stamp}
outputs_dir=run/oppo/ocpc/outputs/${MODEL_VER}_${t_stamp}

INPUT_DIR=/home/devops/gpudata/tfrecord/v0.3/{date} #NEED CHANGE

for DELAY in '--with_conv_delay' ''
do
  for X in '--separated_x' ''
  do
    for WEIBULL in '--weibull_conv_delay' ''
    do
      NAME=${DELAY}${X}${WEIBULL}
      ./scripts/oppo_cb/ocpc/train.sh $MODEL_VER ${summaries_dir}_$NAME \
        ${outputs_dir}_$NAME \
        ${DELAY} ${X} ${WEIBULL} \
        --feature_schema_file ${INPUT_DIR}/schema.csv \
        --train_data ${INPUT_DIR}/train.txt \
        --valid_data ${INPUT_DIR}/valid.txt
      ./scripts/oppo_cb/ocpc/predict.sh $MODEL_VER ${outputs_dir}_$NAME \
        --feature_schema_file ${INPUT_DIR}/schema.csv \
        --valid_data ${INPUT_DIR}/valid.txt
      python3 -m module.base.plot_cvr_calibration \
        -p ${outputs_dir}_$NAME/predictions.txt \
        -o ${outputs_dir}_$NAME/cvr_clibration.png
    done
  done
done

