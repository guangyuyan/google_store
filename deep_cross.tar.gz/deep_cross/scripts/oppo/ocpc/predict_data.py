'''
 python predict_data.py -t {date} -m {training/local/online} -w {gpu/server}
 
 e.g
  python predict_data.py -t 20181011 -m training -w gpu
'''
import os 
import argparse


parser = argparse.ArgumentParser(description='Predict Data')
parser.add_argument('-t',"--date",help='Current Date',required = True)
parser.add_argument('-w',"--where",choices=['gpu','server'],help='Choose where to run this script',required = True)
parser.add_argument('-m',"--mode",choices=['online','local','training'],help='Choose what data to use',required = True)
args = parser.parse_args()


date_time=args.date

model_ver='v1'
outputs_dir=os.path.join('./run/oppo/ocpc/outputs/',date_time)
if not os.path.exists(outputs_dir):
    os.mkdir(outputs_dir)
base_dir='./run/oppo/ocpc'
summaries=base_dir+'/summaries/testlog'

if args.where=='gpu':
    home_path='/home/devops'
else:
    home_path=''

if args.mode=='training':
    
    tfrecord_dir=home_path+'/gpudata/tfrecord/v0.3/'+str(int(date_time)-1)
    valid_data_path=os.path.join(tfrecord_dir,'valid.txt')
    feature_schema_file_path=os.path.join(tfrecord_dir,'schema.csv')
    predictions_path=os.path.join(outputs_dir,'predictions.txt')
    model_date='tf0p3_graph1p0_'+date_time
    
    training_output=home_path+'/gpudata/training/deep_cross/run/oppo/ocpc/tf0p3_graph1p0/outputs'
    training_graph_output=home_path+'/gpudata/training/graph/v1p0'
    
    model_list=[item for item in os.listdir(training_output) if (date_time in item and '.' in item)]
    model_prefix=[item for item in model_list if 'index' in item][0].split('.')[0]
    print('copying data file')
    for model in model_list:
        os.system('cp '+os.path.join(training_output,model)+' '+outputs_dir)
    os.system('cp ' +os.path.join(training_graph_output,model_date+'_graph.meta')+' '+outputs_dir)
    graph_path=os.path.join(outputs_dir,model_date+'_graph.meta')

cmd='python3 -m module.oppo.ocpc.predictor ' \
  '--valid_data '+valid_data_path+' '+ \
  '--feature_schema_file '+feature_schema_file_path+' '+ \
  '--predictions '+predictions_path+' '+ \
  '--prebatch 256'+' '+ \
  '--batch_size 8' +' '+ \
  '--model_dir '+outputs_dir+' '+ \
  '--model_prefix '+model_prefix+' '+ \
  '--input_graph '+graph_path
  
print (cmd)
os.system(cmd)



