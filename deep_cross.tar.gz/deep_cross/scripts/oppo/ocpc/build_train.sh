#!/bin/bash

date_time=$1
graph_name=$2
model_name=$3
datadir=/home/devops/gpudata/tfrecord/v0.3/${date_time}/

sh scripts/oppo/ocpc/build_graph.sh \
--feature_schema_file ${datadir}schema.csv \
--export_graph run/oppo/ocpc/graph_${graph_name}.meta 


sh scripts/oppo/ocpc/train_lite.sh ${model_name} \
--feature_schema_file ${datadir}schema.csv \
--train_data ${datadir}train.txt \
--valid_data ${datadir}valid.txt \
--input_graph run/oppo/ocpc/graph_${graph_name}.meta