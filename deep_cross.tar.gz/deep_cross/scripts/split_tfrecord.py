#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
split tfrecord into two files
"""

import math
import random
import tensorflow as tf

tf.app.flags.DEFINE_string("src", "", "input tfrecord file")
tf.app.flags.DEFINE_string("dst", "", "file name of output tfrecord")  # output file will be dst.*
tf.app.flags.DEFINE_string("dst_list", "", "file name of output tfrecord list")  # output file list contains all file name
tf.app.flags.DEFINE_float('rate', 0.9, 'data rate of dst0/dst1')   
tf.app.flags.DEFINE_bool('gzip', False, 'tfrecord file is gzip format or not')
tf.app.flags.DEFINE_integer('copies', 2, 'number of copies to split')  # if copies > 2, use equal split, if copies == 2, use the rate to split 

def main(argv):
    flags = tf.app.flags.FLAGS
    if tf.flags.FLAGS.gzip:
        options = tf.python_io.TFRecordOptions(
            tf.python_io.TFRecordCompressionType.GZIP)
    else:
        options = tf.python_io.TFRecordOptions(
            tf.python_io.TFRecordCompressionType.NONE)

    fout = []
    for i in range(flags.copies):
        fout.append(tf.python_io.TFRecordWriter('{}.{}'.format(flags.dst, i), options))

    for r in tf.python_io.tf_record_iterator(flags.src, options):
        rand = random.random()
        if flags.copies == 2:  # backward compatible
            if rand < flags.rate:
                fout[0].write(r)
            else:
                fout[1].write(r)
        elif flags.copies > 2:
            fn = math.floor(rand * float(flags.copies))
            fout[fn].write(r)
        else:
            tf.logging.warn('Wrong number of copies {}'.format(flags.copies))

    for f in fout:
        f.close()

    # dump out a list if dst_list is specified
    if flags.dst_list != '':
        with open(flags.dst_list, 'w') as flist:
            for i in range(flags.copies):       
                flist.write('{}.{}\n'.format(flags.dst, i))

if __name__ == "__main__":
    tf.app.run(main)
