#! /bin/bash
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v8
summaries=./run/kaggle/summaries
outputs_dir=./run/kaggle/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}
cp -f ./scripts/kaggle/train.sh  ${summaries_dir}

python3 -m module.kaggle.trainer \
  --gzip \
  --model ${model_ver} \
  --model_name ${model_ver}_$1 \
  --model_path ${outputs_dir} \
  --train_data /ssd/users/xyyu/data/kaggle/train.txt \
  --valid_data /ssd/users/xyyu/data/kaggle/valid.txt \
  --learning_rate 0.00001 \
  --epochs 10 \
  --data_per_valid 2097152 --patient_valid_passes 2 \
  --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  ${@:2} \
  2>&1 | tee ${summaries_dir}/$1.log

