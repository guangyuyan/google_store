#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#

model_ver=v1
summaries=./run/gionee_game_recom/summaries
outputs_dir=./run/gionee_game_recom/outputs
t_stamp="$(date "+%Y%m%d_%H%M%S")"
summaries_dir=$summaries/${model_ver}_${1}_${t_stamp}
mkdir -p ${summaries_dir}
mkdir -p ${outputs_dir}

CUDA_VISIBLE_DEVICES=$2 python3 -m module.gionee_game_recom.trainer \
  --gzip \
  --model ${model_ver} --model_name ${model_ver}_$1 \
  --deep_layers 256 --cross_layers 4 \
  --learning_rate 0.0004 --epochs 10 \
  --data_per_valid 5000000  --patient_valid_passes 5 \
  --train_data /home/pengzx/src/train.txt \
  --valid_data /home/pengzx/src/valid.txt \
  --prebatch 256 --batch_size 32 \
  --model_path ${outputs_dir} --checkpoint_path ${outputs_dir} \
  --summaries_dir ${summaries_dir} \
  2>&1 | tee ${summaries_dir}/$1.log

cp -f ./scripts/gionee_game_recom/train.sh ${summaries_dir}/
