#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <hohaxu@>
#

import operator
import os
import tensorflow as tf
from collections import deque

tf.app.flags.DEFINE_string("out_path", "./summary.txt", "output path for dumping out summary as txt file")
tf.app.flags.DEFINE_string("in_path", "", "summary file,  in the format of ./run/bidding/summaries/<folder_name>/meta/train/")
tf.app.flags.DEFINE_integer("mode_cost", 2, "mode for calculate the cost")
tf.app.flags.DEFINE_integer("mode_best", 2, "mode for finding best lr")
tf.app.flags.DEFINE_boolean("verbose", False, "")

''' 
0 for no filter; 
1 for only find best lr for steps <= step w/ lowest target; 
2 for find best LR within TH of lowest target 
3 for find best LR within TH of lowest target && steps <= step w/ lowest target_lowest
'''
MODE_BEST_DEFAULT = 2

'''
0 for lowest target
1 for lowest (negative with largest magnitude) first order diff
2 for lowest first order derivative
'''
MODE_COST_DEFAULT = 2 

LOSS_TH_FOR_FIND_BEST_LR = 0.1

VERBOSE = False
DUMP_TXT = False
PLOT_X = 'learning_rate_1'
PLOT_Y = 'cost/stream_loss'
SMOOTH_WINDOW_Y = 0    # smooth window for original y
SMOOTH_WINDOW_COST = 30    # smooth window for the cost calculated

class MovingAvg(object):
	def __init__(self, w):
		self.moving_sum = 0; 
		self.fifo = deque()
		self.smooth_window = w
		self.cnt = 0

	def next(self, x):
		if self.cnt < self.smooth_window:  # accumulate sum from 0 to smooth_window - 1
			self.moving_sum += x
			self.fifo.append(x)
		else:
			x_pop = self.fifo.popleft()
			self.fifo.append(x)				
			self.moving_sum += x - x_pop  # update moving sum difference starts from smooth_window
		
		self.cnt += 1
		x_smoothed = self.moving_sum / (self.smooth_window * 1.0)

		# the returned x_smoothed will be incorrect when cnt < smooth_window
		return x_smoothed


def event_gen(in_path, verbose=False):

	cnt = 0; 
	x_column = -1; y_column = -1
	avg = MovingAvg(SMOOTH_WINDOW_Y)

	for e in tf.train.summary_iterator(in_path):

		if len(e.summary.value) == 0:
			continue

		if cnt == 0 and verbose:
			for i, v in enumerate(e.summary.value):
				tf.logging.warn('  {} {}'.format(i, v.tag))

		x = None
		y = None
		for i, v in enumerate(e.summary.value):		
			if v.tag == PLOT_X:
				x = float(v.simple_value)
			if v.tag == PLOT_Y:
				y = float(v.simple_value)

		if x is None or y is None:
			continue

		# generate y_smooth 
		y_smooth = avg.next(y) if SMOOTH_WINDOW_Y > 0 else 0

		cnt += 1	

		# only generate data after y_smooth has been generated
		if cnt >= SMOOTH_WINDOW_Y:		
			yield (x, y, y_smooth)


def find_range(in_path, verbose=False):

	'''
	find the lowest point with the largest index
	'''

	target_column = 1 if SMOOTH_WINDOW_Y == 0 else 2
	data_gen = event_gen(in_path)
	index, minimal = min([(x[0], x[1][target_column]) for x in enumerate(data_gen)], key=lambda x:(x[1], -x[0]))

	if verbose:
		tf.logging.warn('Lowest target is {} at {} step'.format(minimal, index))

	return minimal, index


def find_best(in_path, target_lowest, idx_lowest, MODE_COST, MODE_BEST, TH, verbose=False):

	x_best = None; x_min=1e9; x_max=1e-9
	cost_best = 1e9; idx_best=0
	target_previous = None

	avg = MovingAvg(SMOOTH_WINDOW_COST)

	for i, record in enumerate(event_gen(in_path)):
		x, y, y_smooth = record[0], record[1], record[2]
		target = y_smooth if SMOOTH_WINDOW_Y > 0 else y

		if x < x_min:
			x_min = record[0]
		if x > x_max:
			x_max = record[0]			

		# skip the first one as derivative cannot be calculated
		if i == 0: 
			target_previous = target
			continue

		# calculate cost
		if MODE_COST == 0:
			cost = target 				
		elif MODE_COST == 1:
			cost = target - target_previous
		elif MODE_COST == 2:
			cost = (target - target_previous) / target_previous	

		# generate cost_smoothed, replace cost if SMOOTH_WINDOW_COST is set
		if SMOOTH_WINDOW_COST > 0:
			cost = avg.next(cost)

		# find best cost, only after the SMOOTH_WINDOW_COST
		if i >= SMOOTH_WINDOW_COST and cost < cost_best:

			filtered = False
			if MODE_BEST == 1 and i > idx_lowest:
				filtered = True
			elif MODE_BEST == 2 and (target - target_lowest) / target_lowest > TH:
				filtered = True
			elif MODE_BEST == 3 and ( i > idx_lowest or (target - target_lowest) / target_lowest > TH ):
				filtered = True

			if not filtered:
				cost_best = cost
				idx_best = i
				x_best = x

		target_previous = target

	if verbose:
		if x_best is not None:
			tf.logging.warn('Total step {} with X ranging from {} to {}'.format(i, x_min, x_max))
			tf.logging.warn('Best X found {} in step {}'.format(x_best, idx_best))
			tf.logging.warn('Best cost is {}'.format(cost_best))
		else:
			tf.logging.error('Cannot find best X')

	return cost_best, x_best, idx_best


def dump_txt(in_path, out_path):
	with open(out_path, 'w') as f:
		for i, record in enumerate(event_gen(in_path, True)):
			x, y, y_smooth = record[0], record[1], record[2]
			f.write('{} {} {}\n'.format(x, y, y_smooth))		


def main(argv):

	VERBOSE=tf.app.flags.FLAGS.verbose

	cost_best_all = 1e9
	x_best_all = 0
	for path, _, files in os.walk(tf.app.flags.FLAGS.in_path):

		for fcnt, filename in enumerate(files):

			if not filename.endswith('tensorflow-gpu'):
				continue
			filename_full = path + '/' + filename

			if VERBOSE:
				tf.logging.warn('Parsing {}'.format(filename_full))

			if DUMP_TXT:
				dump_txt(filename_full, tf.app.flags.FLAGS.out_path)

			target_lowest, idx_lowest = find_range(filename_full, verbose=VERBOSE)

			cost_best, x_best, idx_best = find_best(filename_full, target_lowest, idx_lowest, MODE_COST=tf.app.flags.FLAGS.mode_cost, MODE_BEST=tf.app.flags.FLAGS.mode_best, TH=LOSS_TH_FOR_FIND_BEST_LR, verbose=VERBOSE)

			if cost_best < cost_best_all:
				cost_best_all = cost_best
				x_best_all = x_best

	return x_best_all

if __name__ == "__main__":
	tf.app.run(main)	
