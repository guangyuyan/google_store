#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <yaxin@>
#

import tensorflow as tf

tf.app.flags.DEFINE_string("src", "", "")
tf.app.flags.DEFINE_string("dst", "", "")
tf.app.flags.DEFINE_integer("times", 10, "")
tf.app.flags.DEFINE_bool("gzip", False, "write gzip tfrecord")


def main(argv):
    flags = tf.app.flags.FLAGS
    if flags.gzip:
        options = tf.python_io.TFRecordOptions(
                    tf.python_io.TFRecordCompressionType.GZIP)
    else:
        options = None

    with tf.python_io.TFRecordWriter(flags.dst, options=options) as w:
        for r in tf.python_io.tf_record_iterator(flags.src):
            for _ in range(flags.times):
                w.write(r)


if __name__ == "__main__":
    tf.app.run(main)
