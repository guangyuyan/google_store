#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
dxl without log1p (for tflite purpose)
"""

from .model_v1 import DeepCrossModel

import tensorflow as tf


class DeepCrossQuantModel(DeepCrossModel):
    def build_single_embedding(self, ids, layer_name, voc_size, emb_size,
                               dropout=0):
        with tf.name_scope('embedding'):
            out = super(DeepCrossQuantModel, self).build_single_embedding(
                ids, layer_name, voc_size, emb_size, dropout=dropout)
            return tf.cast(tf.cast(
                               (out - tf.minimum(out)) /
                               (out - tf.maximum(out)) * 255, tf.uint8),
                           tf.float32) / 255

    def build_dense_layer(self, fv):
        """
        assume fv are mostly within [0, 1]
        """
        return tf.cast(tf.cast(tf.minimum(tf.maximum(fv, 0), 1) * 255,
                               tf.uint8), tf.float32) / 255
