#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
V1:
    cross: BN(log(dense)) + embedding
    deep: BN(log(dense)) + embedding
"""


import tensorflow as tf

from .model_v0 import BaseVivoDXLModel
from .summary import CATEGORY_FEATURES, NUMERICAL_FEATURES


class DeepCrossModel(BaseVivoDXLModel):
    def __init__(self, flags):
        super(DeepCrossModel, self).__init__(flags)

    def build_features(self, features, embedding_suffix=''):
        """
        VIVO categorical feature id starts from -1 (as missing)
        """
        with tf.device('/cpu:0'):
            ev_list = [
                self.build_single_embedding(
                    features[key],
                    layer_name=key + embedding_suffix,
                    voc_size=self.voc_emb_size[key][0],
                    emb_size=self.voc_emb_size[key][1]) for key in CATEGORY_FEATURES]

            fv_list = [self.build_dense_layer(features[key]) for key in NUMERICAL_FEATURES]
            if self.flags.summary_mode == 'all':
                for fv in fv_list:
                    tf.summary.histogram(fv.name, fv)
            inputs = self.concat(fv_list + ev_list)
            input_dim = 0
            for k in inputs:
                tf.logging.warn(k)
                input_dim += int(k.get_shape()[-1])
            tf.logging.warn('total input dim: {}'.format(input_dim))
        return inputs

    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            return tf.concat([deep_out, cross_out], -1)

    # def build_embedding_layer(self, ids):
    #     with tf.device('/cpu:0'):
    #         ev_list = list()
    #         for begin, key in enumerate(CATEGORY_FEATURES):
    #             one_id = ids[:, begin]
    #             ev = self.build_single_embedding(
    #                     one_id,
    #                     key,
    #                     self.voc_emb_size[key][0],
    #                     self.voc_emb_size[key][1])
    #             ev_list.append(ev)
    #     return ev_list
    #
    # def build_mvm_net(self, features):
    #     fv = features[CONTINUOUS_FEATURE_NAME]
    #     fv = self.build_dense_layer(fv)
    #     ids = features[CATEGORICAL_FEATURE_NAME]
    #     # TODO(byzhang): activation
    #     fv = tf.layers.dense(fv, self.flags.factor_size)
    #     with tf.device('/cpu:0'):
    #         ev_list = list()
    #         for begin, key in enumerate(CATEGORY_FEATURES):
    #             ev_list.append(
    #                 self.single_embedding(
    #                     ids[:, begin],
    #                     layer_name=key,
    #                     voc_size=self.voc_emb_size[key][0],
    #                     emb_size=self.flags.factor_size,
    #                     initial_range=None,
    #                     name_scope='mvm_embedding'))
    #     feature_list = [fv] + ev_list
    #     return self.mvm_net(feature_list)

    def build_dense_layer(self, fv):
        return self.BN(tf.log1p(fv))

    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)

    def build_cross(self, raw_inputs, num_layers=3):
        return self.cross_net(raw_inputs, num_layers,
                              use_bias=self.flags.cross_bias,
                              sparse=self.flags.sparse_cross)
