#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Given the saved model path, optimize and freeze graph and transform back to saved model
"""

import tensorflow as tf
from ..base.model_dxl import PREDICT_NODE_NAME
from .model_v0 import CATEGORICAL_FEATURE_NAME, CONTINUOUS_FEATURE_NAME, OUTPUT_NAME
from tensorflow.python.framework import dtypes
from tensorflow.python.saved_model import signature_constants
from tensorflow.python.saved_model import tag_constants
from tensorflow.python.tools import freeze_graph
from tensorflow.python.tools import optimize_for_inference_lib
from tensorflow.python.tools import saved_model_utils


tf.app.flags.DEFINE_string("input_dir","","the directory of input saved model")
tf.app.flags.DEFINE_string("output_dir" ,"./optimiz_freeze/1", "the directory of output saved model")

def freeze_optimize_saved_model(input_dir, output_dir):
    input_graph_def = saved_model_utils.get_meta_graph_def(
        input_dir, tf.saved_model.tag_constants.SERVING).graph_def
    optGraphDef = optimize_for_inference_lib.optimize_for_inference(
            input_graph_def,
            [CATEGORICAL_FEATURE_NAME, CONTINUOUS_FEATURE_NAME],
            [PREDICT_NODE_NAME],
            [dtypes.int64.as_datatype_enum, dtypes.float32.as_datatype_enum])
    freeze_graph_def = freeze_graph.freeze_graph_with_def_protos(
        input_graph_def, None, "", PREDICT_NODE_NAME,
        "save/restore_all", "save/Const:0", "", True,
        "", "", "", "",
        input_saved_model_dir=input_dir,
        saved_model_tags=[tf.saved_model.tag_constants.SERVING])
    freeze_graph_to_saved_model(freeze_graph_def, output_dir)

def freeze_graph_to_saved_model(graph_def, export_dir):

    builder = tf.saved_model.builder.SavedModelBuilder(export_dir)

    sigs = {}
    with tf.Session(graph=tf.Graph()) as sess:
        tf.import_graph_def(graph_def, name="")
        graph = tf.get_default_graph()
        cate = graph.get_tensor_by_name(CATEGORICAL_FEATURE_NAME+":0")
        cont = graph.get_tensor_by_name(CONTINUOUS_FEATURE_NAME+":0")
        out = graph.get_tensor_by_name(PREDICT_NODE_NAME+":0")
        sigs[tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY] = \
            tf.saved_model.signature_def_utils.predict_signature_def(
                {CONTINUOUS_FEATURE_NAME: cont, CATEGORICAL_FEATURE_NAME: cate}, {OUTPUT_NAME: out})

        builder.add_meta_graph_and_variables(sess,
                                            [tag_constants.SERVING],
                                            signature_def_map=sigs)
    builder.save()


if __name__ == "__main__":
    freeze_optimize_saved_model(tf.app.flags.FLAGS.input_dir,
                                tf.app.flags.FLAGS.output_dir)

