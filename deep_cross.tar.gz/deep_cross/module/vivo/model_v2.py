#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
based on v1 without CTR features
"""

import tensorflow as tf

from .model_v1 import DeepCrossModel


class ModelWithoutOnlineFeature(DeepCrossModel):
    def build_features(self, features):
        ev = self.build_embedding_layer(features['categorical'])
        fv = features['continuous']
        fv = fv[:, OFFLINE_FEATURE_RANGE[0]:OFFLINE_FEATURE_RANGE[1]]
        fv = self.build_dense_layer(fv)
        inputs = self.concat([fv]+ev)
        input_dim = 0
        for k in inputs:
            tf.logging.warn(k)
            input_dim += int(k.get_shape()[-1])
        tf.logging.warn('total input dim: {}'.format(input_dim))
        return inputs
