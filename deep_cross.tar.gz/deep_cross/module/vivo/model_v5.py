#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
single fc network without CTR features
"""


from .model_v2 import ModelWithoutOnlineFeature
from .model_v4 import SingleDeepModel


class LessSingleDeepModel(ModelWithoutOnlineFeature, SingleDeepModel):
    pass
