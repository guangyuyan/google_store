#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
single fc network with full features
"""
import tensorflow as tf

from .model_v1 import DeepCrossModel


class SingleDeepModel(DeepCrossModel):
    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            return tf.concat(deep_out, -1)
