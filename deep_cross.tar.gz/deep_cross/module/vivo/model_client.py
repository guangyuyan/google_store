#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Client to use rpc conneting the Sever to send features and get labels back
CUDA_VISIBLE_DEVICE=0 python3 -m module.vivo.model_client --server=localhost:9000 --work_dir=/ssd/users/xjfan/vivo/newsfeed_0622/train.txt --server_model_name=model_v1 --num_tests=1

"""

from .model_v0 import BaseVivoDXLModel
from ..base.client_utils import client_test


if __name__ == '__main__':
    client_test(BaseVivoDXLModel)
