#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
delta trainer
"""


import sys
import time
from .build_model import build_model
import tensorflow as tf
# import threading


def main(unused=None, flags=None):
    if flags:
        tf.app.flags.FLAGS(flags, known_only=True)
    flags = tf.app.flags.FLAGS

    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    model = build_model(flags)
    model.build()

    with tf.Session(config=sess_config) as session:
        model.train(session)
    return model.best_checkpoint


def runner(argv=None):
    if not argv:
        argv = [
            sys.argv[0],
            '--model=v1',
            '--model_name=outputs/v1.5',
            '--train_data=train',
            '--valid_data=valid',
            '--learning_rate=0.0001',
            '--lr_decay_step=30000',
            '--epochs=2',
            '--data_per_valid=400000',
            '--patient_valid_passes=3',
            '--prebatch=256',
            '--batch_size=8',
            '--deep_layers=512,256',
            '--cross_layers=2',
            '--hot_mode=all',
            '--model_path=./outputs{}'.format(time.strftime('%y%m%d%H%M')),
            '--summaries_dir=./summaries/{}'.format(time.strftime('%y%m%d%H%M')),
                ]
    return main(base_checkpoint, last_checkpoint, flags=argv)
