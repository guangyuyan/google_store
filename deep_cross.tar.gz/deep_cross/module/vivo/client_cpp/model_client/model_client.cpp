/*
 * model_client.cpp
 * Copyright (C) 2018- CloudBrain <byzhang@>

 Bazel build and run from WORKSPACE directory:
build: bazel build -c opt --define=grpc_no_ares=true //model_client:model_client_cc
run: OMP_NUM_THREADS=4 bazel-bin//model_client/model_client_cc --batch_size=1

*/

#include <algorithm>
#include <assert.h>
#include <chrono>
#include <sstream>  //std::stringstream

#include "grpc++/create_channel.h"
#include "grpc++/security/credentials.h"
#include "google/protobuf/map.h"
#include "tensorflow/cc/saved_model/signature_constants.h"
#include "tensorflow/core/example/example.pb.h"
#include "tensorflow/core/framework/tensor.h"
#include "tensorflow/core/framework/types.pb.h"
#include "tensorflow/core/lib/core/errors.h"
#include "tensorflow/core/lib/core/status.h"
#include "tensorflow/core/lib/io/compression.h"
#include "tensorflow/core/lib/io/record_reader.h"
#include "tensorflow/core/util/command_line_flags.h"
#include "tensorflow_serving/apis/prediction_service.grpc.pb.h"

#define PREBATCH 256
#define DENSEFEATURES 6406
#define SPARSEFEATURES 62

int omp_get_num_threads();
int omp_get_thread_num();

using grpc::Channel;
using grpc::ClientContext;
//Refer to https://github.com/grpc/grpc/blob/34e8e0a6400d8b529125a3b83ec1facf71acf99b/include/grpcpp/impl/codegen/client_context.h
//for the deadline of Client Call Predict

using tensorflow::serving::PredictRequest;
using tensorflow::serving::PredictResponse;
using tensorflow::serving::PredictionService;

typedef google::protobuf::Map<tensorflow::string, tensorflow::TensorProto> ProtoMap;
typedef google::protobuf::Map<std::string, tensorflow::Feature> FeatureMap;

class MyRecordReader {
 public:
  MyRecordReader() : reader_(nullptr), offset_(0), tensor_size_(0){}

  void insertSingleToProto(float data, tensorflow::TensorProto &proto){
    proto.add_float_val(data);
  }
  void insertSingleToProto(google::protobuf::int64 data, tensorflow::TensorProto &proto){
    proto.add_int64_val(data);
  }
  template<typename T>
  void insertFeatureToProto(const T& featurelist,
      tensorflow::TensorProto &proto){
    int size = featurelist.value_size();
    for(int i = 0; i < size; ++i){
      insertSingleToProto(featurelist.value(i), proto);
    }
  }
  void recordsToTensorProto(std::vector<tensorflow::Example> &records){
    int record_num = records.size();
    tensorflow::TensorProto cont_proto;
    tensorflow::TensorProto cate_proto;
    cont_proto.set_dtype(tensorflow::DataType::DT_FLOAT);
    cate_proto.set_dtype(tensorflow::DataType::DT_INT64);
    for(int  i = 0; i < record_num; ++i){
      const FeatureMap& features = records[i].mutable_features()->feature();
      assert(features.size()==3);
      insertFeatureToProto<tensorflow::FloatList>(features.at("numerical").float_list(), cont_proto);
      insertFeatureToProto<tensorflow::Int64List>(features.at("categorical").int64_list(), cate_proto);
    }
    cont_proto.mutable_tensor_shape()->add_dim()->set_size(
        PREBATCH*record_num);
    cont_proto.mutable_tensor_shape()->add_dim()->set_size(DENSEFEATURES);
    cate_proto.mutable_tensor_shape()->add_dim()->set_size(
        PREBATCH*record_num);
    cate_proto.mutable_tensor_shape()->add_dim()->set_size(SPARSEFEATURES);
    cont_protos_.push_back(std::move(cont_proto));
    cate_protos_.push_back(std::move(cate_proto));
    ++tensor_size_;
  }
  void initializeFileReader(const tensorflow::string &file_name, int buf_size){
    TF_CHECK_OK(tensorflow::Env::Default()->NewRandomAccessFile(
          file_name, &input_file_));
    tensorflow::io::RecordReaderOptions options =
      tensorflow::io::RecordReaderOptions::CreateRecordReaderOptions(
        tensorflow::io::compression::kNone);
    options.zlib_options.input_buffer_size = buf_size;
    reader_.reset(new tensorflow::io::RecordReader(input_file_.get(), options));
    offset_ = 0;
  }
 int loadFromFile(const tensorflow::string &file_name, int buf_size,
     tensorflow::int64 batch_size, tensorflow::int64 num_tests){
    std::cerr<<"Loading from file with batch_size = "<<batch_size<<std::endl;
    initializeFileReader(file_name, buf_size);
    tensorflow::string stringrecord;
    for(int i=0; i<num_tests; ++i){
      std::vector<tensorflow::Example> records;
      for(int record_num = 0; record_num < batch_size; ++record_num){
        tensorflow::Status s = reader_->ReadRecord(&offset_, &stringrecord);
        if(!s.ok()){
          std::cerr<<"File End! Padding with used data!"<<std::endl;
          /*cont_protos_.resize(num_tests);
          cate_protos_.resize(num_tests);
          while(i < num_tests){
            if(i+i <= num_tests){
              std::copy_n(cont_protos_.begin(), i, cont_protos_.begin()+i);
              std::copy_n(cate_protos_.begin(), i, cate_protos_.begin()+i);
              i += i;
            }else{
              std::copy_n(cont_protos_.begin(), num_tests-i, cont_protos_.begin()+i);
              std::copy_n(cate_protos_.begin(), num_tests-i, cate_protos_.begin()+i);
              i = num_tests;
            }
          }
          tensor_size_ = num_tests;*/
          return tensor_size_;
        }
        tensorflow::Example record;
        record.ParseFromString(stringrecord);
        records.push_back(std::move(record));
      }
      recordsToTensorProto(records);
    }
    return tensor_size_;
  }
  bool getTensorProtofromReader(ProtoMap& inputs, int i) {
    if(i < 0 ) return false;
    i = i%tensor_size_;
    inputs["continuous"] = cont_protos_[i];
    inputs["categorical"] = cate_protos_[i];
    return true;
  }

 private:
  std::unique_ptr<tensorflow::RandomAccessFile> input_file_;
  std::unique_ptr<tensorflow::io::RecordReader> reader_;
  tensorflow::uint64 offset_;
  int tensor_size_;
  std::vector<tensorflow::TensorProto> cont_protos_;
  std::vector<tensorflow::TensorProto> cate_protos_;
};

class ServingClient {
 public:
  ServingClient(std::shared_ptr<Channel> channel)
    : stub_(PredictionService::NewStub(channel)), total_prepare_time_(0.0){}

  void insertTime(const double& time, const double& ptime){
    time_mutex_.lock();
    time_cost_.push_back(time);
    total_prepare_time_ += ptime;
    time_mutex_.unlock();
  }
  void sortTime(){
    sort(time_cost_.begin(), time_cost_.end());
  }
  double getAverageTimeCost(){
    double total = 0.0;
    for(auto t : time_cost_){
      total += t;
    }
    return total/time_cost_.size();
  }
  double getThe90MaxTime(){
    return time_cost_[int(time_cost_.size()*0.9)];
  }
  double getThe99MaxTime(){
    return time_cost_[int(time_cost_.size()*0.99)];
  }
  double getMaxTime(){
    return time_cost_.back();
  }
  double getMinTime(){
    return time_cost_.front();
  }
  double getAvePrepareTime(){
    return total_prepare_time_/time_cost_.size();
  }
  double getPrepareTime(){
    return total_prepare_time_;
  }
  void callPredict(const tensorflow::string& model_name,
                  const tensorflow::string& model_signature_name,
                  MyRecordReader &reader, bool print, int i){
    std::chrono::high_resolution_clock::time_point pstart =
      std::chrono::high_resolution_clock::now();
    PredictRequest request;
    PredictResponse response;
    ClientContext context;
    bool nempty = reader.getTensorProtofromReader(*request.mutable_inputs(), i);
    if(!nempty){
      std::cerr<<"No More Tensor Proto in RecordReader!\n";
      return;
    }
    request.mutable_model_spec()->set_name(model_name);
    request.mutable_model_spec()->set_signature_name(
      model_signature_name);
    //std::string serialize = "";
    //request.SerializeToString(&serialize);
    //std::cout<<"Size of serialized String: "<<serialize.length()<<std::endl;
    std::chrono::high_resolution_clock::time_point pend =
      std::chrono::high_resolution_clock::now();
    double pduration = std::chrono::duration_cast
      <std::chrono::microseconds>(pend-pstart).count()/1000.0;

    std::chrono::high_resolution_clock::time_point start =
      std::chrono::high_resolution_clock::now();
    grpc::Status status = stub_->Predict(&context, request, &response);
    std::chrono::high_resolution_clock::time_point end =
      std::chrono::high_resolution_clock::now();
    double duration = std::chrono::duration_cast
      <std::chrono::microseconds>(end-start).count()/1000.0;
    insertTime(duration, pduration);
    if(status.ok()) {
      ProtoMap& outputs = *response.mutable_outputs();
      for(auto iter = outputs.begin(); iter!=outputs.end(); ++iter) {
        tensorflow::TensorProto& result_tensor_proto = iter->second;
        tensorflow::Tensor tensor;
        if(print){
        if(tensor.FromProto(result_tensor_proto)) {
          std::cout<<"The result tensor is: "
                   << tensor.SummarizeValue(tensor.NumElements()) << std::endl;
        } else {
          std::cout<<"The result tensor convert failed\n";
        }
        }
      }
    } else {
      std::cerr<<"gRPC failed, return code: " << status.error_code() <<": "
               << status.error_message() << std::endl;
    }
  }
 private:
  std::unique_ptr<PredictionService::Stub> stub_;
  std::vector<double> time_cost_;
  double total_prepare_time_;
  std::mutex time_mutex_;
};

int main(int argc, char **argv) {
  tensorflow::int64 batch_size = 4;
  tensorflow::int64 num_tests = 2000;
  tensorflow::string file_name = "/home/xyyu/src/data/vivo_data";
  tensorflow::string server_port = "localhost:9000";
  tensorflow::string model_name = "model_v1";
  tensorflow::string model_signature_name = tensorflow::kDefaultServingSignatureDefKey;
  std::vector<tensorflow::Flag> flag_list = {
    tensorflow::Flag("batch_size", &batch_size, "The batch size for predictor"),
    tensorflow::Flag("num_tests", &num_tests, "The num of predict request"),
    tensorflow::Flag("file_name", &file_name, "name of input file"),
    tensorflow::Flag("server_port", &server_port, "IP and port of server"),
    tensorflow::Flag("model_name", &model_name, "name of model"),
    tensorflow::Flag("model_signature_name", &model_signature_name,
    "name of model signature")
  };
  tensorflow::string usage = tensorflow::Flags::Usage(argv[0], flag_list);
  const bool parse_result = tensorflow::Flags::Parse(&argc, argv, flag_list);
  if (!parse_result) {
    std::cout << usage;
    return -1;
  }

  int num_threads;
  #pragma omp parallel
  {
    num_threads = omp_get_num_threads();
  }

  ServingClient guide(
    grpc::CreateChannel(server_port, grpc::InsecureChannelCredentials()));

  MyRecordReader reader;//buf_size!=0, sequentialRead, buf_size=0, randomRead
  int size = reader.loadFromFile(file_name, 1<<30, batch_size, num_tests);
  std::cerr<<"Loading size: "<<size<<std::endl;

  std::chrono::high_resolution_clock::time_point start =
      std::chrono::high_resolution_clock::now();
  #pragma omp parallel for
  for(int i = 0; i < num_tests; ++i){
    guide.callPredict(model_name, model_signature_name, reader, false, i);
  }
  std::chrono::high_resolution_clock::time_point end =
      std::chrono::high_resolution_clock::now();
  double duration = std::chrono::duration_cast
      <std::chrono::microseconds>(end-start).count()/1000.0;
  //std::cout<<"Total Prepare time: "<<guide.getPrepareTime()<<"ms, ";
  //std::cout<<"The Average Prepare Time: "<<guide.getAvePrepareTime()<<"ms"<<std::endl;
  std::cout<<num_tests*1000/duration<<"\t";
  guide.sortTime();
  std::cout<<guide.getMaxTime()<<"\t";
  std::cout<<guide.getAverageTimeCost()<<"\t";
  std::cout<<guide.getMinTime()<<"\t";
  std::cout<<guide.getThe99MaxTime()<<"\t";
  std::cout<<guide.getThe90MaxTime()<<std::endl;
  return 0;
}
