#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
name and vocabulary size of sparse size
"""

import os
import csv


CATEGORY_FEATURES = dict()
NUMERICAL_FEATURES = dict()
VOC_SIZE = dict()


with open(os.path.join(os.path.dirname(__file__),
                       'data/feature_list.csv')) as f:
    feature_list = list(csv.reader(f))

CATEGORY_FEATURES = {item[0]: int(item[3]) for item in feature_list if item[1] == 'Int'}
NUMERICAL_FEATURES = {item[0]: int(item[3]) for item in feature_list if item[1] == 'Double'}
VOC_SIZE = {item[0]: int(item[2]) for item in feature_list if item[1] == 'Int'}
