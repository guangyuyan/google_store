#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build model
"""


from . import model_v1
from . import model_v2
from . import model_v3
from . import model_v4
from . import model_v5
from . import model_v6
from . import model_v7
from . import model_v8
from . import model_v9
from . import model_v10
from . import model_v11
from . import model_v12

import tensorflow as tf


def build_model(flags):
    if flags.model == 'v1':
        model = model_v1.DeepCrossModel(flags)
    elif flags.model == 'v2':
        model = model_v2.ModelWithoutOnlineFeature(flags)
    elif flags.model == 'v3':
        model = model_v3.LinearModel(flags)
    elif flags.model == 'v4':
        model = model_v4.SingleDeepModel(flags)
    elif flags.model == 'v5':
        model = model_v5.LessSingleDeepModel(flags)
    elif flags.model == 'v6':
        model = model_v6.FCLessFeatureModel(flags)
    elif flags.model == 'v7':
        model = model_v7.DeepCrossQuantModel(flags)
    elif flags.model == 'v8':
        model = model_v8.DeepCrossNoBNModel(flags)
    elif flags.model == 'v9':
        model = model_v9.SelfAttentiveDeepCrossModel(flags)
    elif flags.model == 'v10':
        model = model_v10.TestActivationModel(flags)
    elif flags.model == 'v11':
        model = model_v11.DeepCrossMvmModel(flags)
    elif flags.model == 'v12':
        model = model_v12.DeepCrossMvmModel(flags)
    return model
