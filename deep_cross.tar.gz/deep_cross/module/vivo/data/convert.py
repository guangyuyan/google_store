#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
transfer data from hive to tfrecord
"""
from feature_map import feature_map
from collections import defaultdict
import tensorflow as tf
import pyspark
import random
import argparse


tf_writer = None
batch_size = 256


def _int64_feature(value):
    return tf.train.Feature(
        int64_list=tf.train.Int64List(value=value))


def _bytes_feature(value):
    return tf.train.Feature(
        bytes_list=tf.train.BytesList(value=value))


def _float_feature(value):
    return tf.train.Feature(
        float_list=tf.train.FloatList(value=value))


def handle_partition(partition, prebatch, out_file):
    global tf_writer, batch_size
    batch_size = prebatch
    options = tf.python_io.TFRecordOptions(
                tf.python_io.TFRecordCompressionType.GZIP)
    tf_writer = tf.python_io.TFRecordWriter(out_file, options=options)
    partition = partition.filter(neg_sample)
    partition.foreachPartition(handle_batch)
    tf_writer.close()


def handle_batch(batch):
    global tf_writer, batch_size
    for count, row in enumerate(batch, start=1):
        row = handle_row(row)
        prebatch = defaultdict(list)
        for k, v in row.iteritems():
            prebatch[k].extend(v)
        if count % batch_size == 0:
            batch = dict()
            batch['sparse'] = _int64_feature(prebatch['sparse'])
            batch['dense'] = _float_feature(prebatch['dense'])
            batch['ads'] = _float_feature(prebatch['ads'])
            batch['user'] = _float_feature(prebatch['user'])
            batch['image'] = _float_feature(prebatch['image'])
            batch['text'] = _float_feature(prebatch['text'])
            batch['label'] = _int64_feature([1 if i == 1 else 0 for i in prebatch['label']])
            to_TFRecord(tf_writer, batch)
                f.writelines(prebatch)
            prebatch = defaultdict(list)


def handle_row(row):
    def handle_item(item):
        # item is a vecotr
        if type(item) == unicode and '#' in item:
            if ':' in item:
                if ',' in item:
                    return handle_dense(item)
                else:
                    return handle_ont_hot(item)
            return handle_dense(item)
        return item
    mapped_row = defaultdict(list)
    for key in feature_map:
        for col_name in feature_map[key]:
            item = handle_item(row[col_name])
            if isinstance(item, list):
                mapped_row[key].extend(item)
            else:
                mapped_row[key].append(item)
    return mapped_row


def neg_sample(row):
    return row['pctr_online_features_test.clicked'] == 1 or random.random() < 0.2


def handle_ont_hot(instr):
    size, kv = instr.split('#')
    idx, val = kv.split(':')
    return int(idx)


def handle_dense(instr):
    shape, kv = instr.split('#')
    if ',' in kv:
        kv = [item.split(':') for item in kv.split(',')]
        kv = {int(k): float(v) for k, v in kv}
        dense = [kv[idx] if idx in kv else 0 for idx in range(int(shape))]
    else:
        dense = [0] * int(shape)
    return dense

def to_TFRecord(tf_writer, batch):
    example = tf.train.Example(features=tf.train.Features(feature=batch))
    tf_writer.write(example.SerializeToString())
    tf_writer.write(example.SerializeToString())


def from_csv(infile, outfile, prebatch):
    sc = pyspark.SparkContext(appName='Test', master='local')
    spark = pyspark.sql.SparkSession(sc)
    df = spark.read.option('header', 'true').option('inferSchema', 'true').csv(infile)
    handle_partition(df.rdd, prebatch, outfile)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--in_file', type=str, required=True)
    parser.add_argument('-o', '--out_file', type=str, required=True)
    parser.add_argument('-s', '--prebatch', type=int, default=256)
    args = parser.parse_args()
    from_csv(args.in_file, args.out_file, args.prebatch)
