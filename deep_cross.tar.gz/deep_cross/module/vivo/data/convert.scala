# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.expressions.GenericRow
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}

import scala.collection.mutable.ListBuffer
import scala.util.Random

object convert {

  def main(args: Array[String]): Unit = {
    args(0) match {
      case "spark" =>
        val Array(_, where, prebatch, ratio, outPath, isMake) = args
        val hc = SparkSession.builder().appName("generateTfrecord").enableHiveSupport().getOrCreate()
        val df = hc.sql(s"select * from feedads.pctr_online_features $where")
        handlePartition(df.rdd, hc, prebatch.toInt, ratio.toFloat, outPath, isMake.toBoolean)
      case "test" =>
        val Array(_, inCsv, prebatch, ratio, outPath) = args
        fromCsv(inCsv, outPath, prebatch.toInt, ratio.toFloat)
    }
  }

  def fromCsv(infile: String, outfile: String, prebatch: Int, ratio: Float): Unit = {
    val spark: SparkSession = SparkSession.builder
      .master("local").appName("test").getOrCreate()
    val df: DataFrame = spark.read.option("header", "true").option("inferSchema", "true").csv(infile)
    handlePartition(df.rdd, spark, prebatch, ratio, outfile, false)
  }


  def handlePartition(partition: RDD[Row], spark: SparkSession, prebatch: Int, ratio: Float,
                      outFile: String, isMake: Boolean): Unit = {
    val negSample = partition.filter(negativeSampling(_, new Random(), ratio))
    val partitionSize = negSample.count() / prebatch
    val repartRdd = negSample.repartition((partitionSize/1000+1).toInt)
    val featureMap = spark.read.json("featureMap.json").first()
    val mapedRow = repartRdd.map[Array[List[Any]]](handleRow(_, featureMap))
    if(isMake) makeDescribe(mapedRow, outFile, spark, featureMap)
    val rdd: RDD[Row] = mapedRow.mapPartitions[Row](handleBatch(_, prebatch))
    toTfrecord(rdd, spark, outFile)
  }

  def makeDescribe(value: RDD[Array[List[Any]]], str: String, hc: SparkSession, featureMap: Row) = {
    val sparse = value.map[Row](array => new GenericRow(array(0).toArray[Any]))
    val dense = value.map[Row](array => new GenericRow(array(1).toArray[Any]))
    val sparsSchema = StructType(featureMap.getAs[Seq[String]]("sparse").map(str => StructField(str, IntegerType)))
    val denseSchema = StructType(featureMap.getAs[Seq[String]]("dense").map(str => StructField(str, DoubleType)))
    val sparseDf = hc.createDataFrame(sparse, sparsSchema)
    sparseDf.describe().write.mode(SaveMode.Overwrite).option("header", "true").csv(str + "_sparse.csv")
    val denseDf = hc.createDataFrame(dense, denseSchema)
    denseDf.describe().write.mode(SaveMode.Overwrite).option("header", "true").csv(str + "_dense.csv")
  }

  def handleBatch(batch: Iterator[Array[List[Any]]], batchSize: Int): Iterator[Row] = {
    val groupedBatch = batch.sliding(batchSize, batchSize)
    val retVal = new ListBuffer[Row]()
    for (eachBatch <- groupedBatch) {
      var count = 1
      val ret = eachBatch(0)
      for(tmp <- eachBatch) {
        if(count > 1) {
          for (idx <- 0 until tmp.length) {
            ret.update(idx, ret(idx) ::: tmp(idx))
          }
        }
        if(count==batchSize) retVal += new GenericRow(ret.toArray[Any])
        count += 1
      }
    }
    retVal.iterator
  }

  def handleRow(row: Row, featureMap: Row): Array[List[Any]] = {
    val sparse = ListBuffer[Int]()
    for (colName: String <- featureMap.getAs[List[String]]("sparse"))
      sparse += str2onehot(row.getAs[String](colName))

    val dense = ListBuffer[Double]()
    for (colName: String <- featureMap.getAs[List[String]]("dense"))
      dense += row.getAs[Double](colName)

    val content = ListBuffer[Double]()
    for (colName: String <- featureMap.getAs[List[String]]("content"))
      content.appendAll(str2Vector(row.getAs[String](colName)))

    val ctrs = ListBuffer[Double]()
    for (colName: String <- featureMap.getAs[List[String]]("ctrs"))
      ctrs.appendAll(str2Vector(row.getAs[String](colName)))

    val ads = ListBuffer[Double]()
    for (colName: String <- featureMap.getAs[List[String]]("ads"))
      ads.appendAll(str2Vector(row.getAs[String](colName)))

    val user = ListBuffer[Double]()
    for (colName: String <- featureMap.getAs[List[String]]("user"))
      user.appendAll(str2Vector(row.getAs[String](colName)))

    val label = ListBuffer[Int]()
    for (colName: String <- featureMap.getAs[List[String]]("label"))
      label += row.getAs[Double](colName).toInt

    Array[List[Any]](sparse.result(),
      dense.result(),
      content.result(),
      ctrs.result(),
      ads.result(),
      user.result(),
      label.result())
  }

  def str2onehot(str: String): Int = {
    val Array(_, valueStr) = str.split("#", 2)
    val Array(value, _) = valueStr.split(":", 2)
    value.toInt
  }

  def str2Vector(str: String): Array[Double] = {
    val Array(size, valueStr) = str.split("#", 2)
    if (valueStr != null && valueStr.trim != "") {
      Vectors.sparse(size.toInt, valueStr.split(",").map(_.split(":"))
        .map(arr => (arr(0).toInt, arr(1).toDouble))).toArray
    } else {
      Vectors.sparse(size.toInt, Seq.empty[(Int, Double)]).toArray
    }
  }

  def negativeSampling(row: Row, r: Random, ratio: Float): Boolean = {
    return row.getAs[Double]("clicked") == 1.0 || r.nextFloat() < ratio
  }

  def toTfrecord(rdd: RDD[Row], spark: SparkSession, outPath: String): Unit = {
    val schema = StructType(List(StructField("sparse", ArrayType(IntegerType, true)),
      StructField("dense", ArrayType(DoubleType, true)),
      StructField("content", ArrayType(DoubleType, true)),
      StructField("ctrs", ArrayType(DoubleType, true)),
      StructField("ads", ArrayType(DoubleType, true)),
      StructField("user", ArrayType(DoubleType, true)),
      StructField("label", ArrayType(IntegerType, true))
    ))
    val df: DataFrame = spark.createDataFrame(rdd, schema)
    df.write.mode(SaveMode.Overwrite).format("tfrecords").option("compression", "gzip")
      .option("recordType", "Example").save(outPath)
  }
}
