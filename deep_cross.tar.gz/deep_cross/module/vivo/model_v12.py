#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
mvm net include
"""

from .model_v8 import DeepCrossNoBNModel
import tensorflow as tf


class DeepMvmModel(DeepCrossNoBNModel):
    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            mvm_out = self.build_mvm_net(features)
            return tf.concat([deep_out,  mvm_out], -1)
