#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
single fc network
no cross
no CTR features
no user hist features
"""

import tensorflow as tf
from .model_v4 import SingleDeepModel


class FCLessFeatureModel(SingleDeepModel):
    def build_features(self, features):
        ev = self.build_embedding_layer(features['categorical'])
        fv = features['continuous']
        fv = self.build_dense_layer(fv)
        inputs = self.concat([fv]+ev)
        input_dim = 0
        for k in inputs:
            tf.logging.warn(k)
            input_dim += int(k.get_shape()[-1])
        tf.logging.warn('total input dim: {}'.format(input_dim))
        return inputs
