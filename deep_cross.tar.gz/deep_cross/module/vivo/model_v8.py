#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
deep & cross
without BN
"""

from .model_v1 import DeepCrossModel
import tensorflow as tf


class DeepCrossNoBNModel(DeepCrossModel):
    def build_dense_layer(self, fv):
        return tf.log1p(fv)
