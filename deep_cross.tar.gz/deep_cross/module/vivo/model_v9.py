#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
deep & cross
without BN
"""

from .model_v8 import DeepCrossNoBNModel
import tensorflow as tf


class SelfAttentiveDeepCrossModel(DeepCrossNoBNModel):
    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        return self.self_attentive_deep_net(
            raw_inputs, hidden, activation,
            concat_last_deep=self.flags.concat_last_deep,
            sparse=False)
