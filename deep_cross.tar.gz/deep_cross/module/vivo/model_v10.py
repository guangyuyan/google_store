#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
model with different activation function
"""

from .model_v8 import DeepCrossNoBNModel
import tensorflow as tf

def alt_swish(x):
    beta = tf.Variable(initial_value=1.0, trainable=True, name='swish-beta')
    return x * tf.nn.sigmoid(beta*x)


class TestActivationModel(DeepCrossNoBNModel):
    def build_deep(self, raw_inputs, hidden=None, activation=alt_swish):
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)
