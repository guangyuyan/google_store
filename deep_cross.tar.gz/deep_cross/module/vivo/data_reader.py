#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.


import tensorflow as tf
from ..base.data_reader import data_reader
from .build_model import build_model


def main(argv):
    data_reader(build_model)


if __name__ == "__main__":
    tf.app.run(main)
