#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""

"""
import os
import sys
import tensorflow as tf
from ..base.model_dxl import PREDICT_NODE_NAME
from .model_v0 import CATEGORICAL_FEATURE_NAME, CONTINUOUS_FEATURE_NAME, OUTPUT_NAME
from tensorflow.python.saved_model import signature_constants
from tensorflow.python.saved_model import tag_constants

tf.app.flags.DEFINE_string("input_file", "v4.1.frozen.pb", "name of frozen graph def")
tf.app.flags.DEFINE_string("export_dir", "./saved", "saved model output directory")

def freeze_graph_to_saved_model(graph_pb_file, export_dir):

    builder = tf.saved_model.builder.SavedModelBuilder(export_dir)

    with tf.gfile.GFile(graph_pb_file, "rb") as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())

    sigs = {}
    with tf.Session(graph=tf.Graph()) as sess:
        tf.import_graph_def(graph_def, name="")
        graph = tf.get_default_graph()
        cate = graph.get_tensor_by_name(CATEGORICAL_FEATURE_NAME+":0")
        cont = graph.get_tensor_by_name(CONTINUOUS_FEATURE_NAME+":0")
        # Sigmoid defined according to build_predictions in model_dxl.py
        out = graph.get_tensor_by_name(PREDICT_NODE_NAME+"/Sigmoid:0")
        sigs[tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY] = \
            tf.saved_model.signature_def_utils.predict_signature_def(
                {CONTINUOUS_FEATURE_NAME: cont, CATEGORICAL_FEATURE_NAME: cate}, {OUTPUT_NAME: out})

        builder.add_meta_graph_and_variables(sess,
                                            [tag_constants.SERVING],
                                            signature_def_map=sigs)
    builder.save()

if __name__ =="__main__":
    freeze_graph_to_saved_model(tf.app.flags.FLAGS.input_file, tf.app.flags.FLAGS.export_dir)
