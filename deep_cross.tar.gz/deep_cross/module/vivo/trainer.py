#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
build and train model
"""


import sys
import time
from .build_model import build_model
from ..base.trainer import train
from ..base.build_graph_utils import graph_add_collection
import tensorflow as tf


def main(unused=None, flags=None):
    if flags:
        tf.app.flags.FLAGS(flags, known_only=True)
    flags = tf.app.flags.FLAGS
    tf.logging.warn(tf.app.flags.FLAGS.input_graph)

    model = build_model(flags)
    model.build()

    if flags.quantize:
        tf.contrib.quantize.experimental_create_training_graph(
            quant_delay=flags.quant_delay,
            freeze_bn_delay=flags.quant_delay
        )
    graph_add_collection(model)
    train(model)


def runner(argv=None):
    if not argv:
        argv = [
                sys.argv[0],
                '--model=v1',
                '--model_name=outputs/v1.0',
                '--train_data=train',
                '--valid_data=valid',
                '--learning_rate=0.0001',
                '--epochs=10',
                '--data_per_valid=4000000',
                '--patient_valid_passes=3',
                '--prebatch=256',
                '--batch_size=4',
                '--deep_layers=512,256',
                '--cross_layers=2',
                '--model_path=./outputs',
                '--summaries_dir=./summaries/{}'.format(
                    time.strftime('%y%m%d%H%M')),
                ]
    best_loss = main(flags=argv)
    return best_loss


if __name__ == "__main__":
    tf.app.run(main)
