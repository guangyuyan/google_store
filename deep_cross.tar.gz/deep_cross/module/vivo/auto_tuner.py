#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
auto tuner for hyperparameter searching
"""

import tensorflow as tf
from hyperopt import STATUS_OK
from hyperopt import hp
import hyperopt as hopt
import copy
from .build_model import build_model


class Config:
    spaces = [
        {'learning_rate': hp.choice("x_learning_rate", [0.00005, 0.0001]),
         'deep_layers': hp.choice("x_deep_layers", ['512,256', '512,512']),
         'cross_layers': hp.choice("x_cross_layers", [2, 3]),
         'HOPT_ITERATION': 20}
    ]

    constants = [
        '--model=v1',
        '--model_name=test',
        '--model_path=./run/vivo/outputs',
        '--checkpoint_path=./run/vivo/outputs',
        '--data_per_valid=300000',
        '--epochs=100',
        '--patient_valid_passes=5',
        '--batch_size=4',
        '--prebatch=256',
        '--summaries_dir=./run/vivo/summaries/',
        '--train_data=/ssd/users/xjfan/vivo/newsfeed_0622/train.txt',
        '--valid_data=/ssd/users/xjfan/vivo/newsfeed_0622/valid.txt',
    ]


def cost(space):
    tf.reset_default_graph()
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    tf.app.flags.FLAGS(Config.constants, known_only=True)
    flags = tf.app.flags.FLAGS
    flags.deep_layers = space['deep_layers']
    flags.cross_layers = space['cross_layers']
    flags.learning_rate = space['learning_rate']
    tf.logging.warn('--AutoTuner-- Current space setting {0}'.format(space))

    model = build_model(flags)
    model.build()
    with tf.Session(config=sess_config) as session:
        session.run([tf.global_variables_initializer(),
                     tf.local_variables_initializer(),
                     tf.tables_initializer(),
                     model.initializer()])
        loss = model.train(session)
    return {'loss': float(loss), 'status': STATUS_OK}


best_last_stage = {}
for i, space in enumerate(Config.spaces):
    current_space = copy.deepcopy(best_last_stage)
    for s in space:
        current_space[s] = space[s]
    try:
        hopt_iteration = current_space['HOPT_ITERATION']
        current_space.pop('HOPT_ITERATION', None)
    except:
        tf.logging.error('--AutoTuner-- Please config {0} in'
                         'each space defination.'.format('HOPT_ITERATION'))
        raise

    tf.logging.warn('--AutoTuner-- Round {0} Config Space {1}'
                    .format(i, current_space))
    rt = hopt.fmin(fn=cost,
                   space=current_space,
                   algo=hopt.tpe.suggest,
                   max_evals=hopt_iteration)
    best_value = hopt.space_eval(space, rt)
    for s in best_value:
        best_last_stage[s] = best_value[s]
    tf.logging.warn('--AutoTuner-- Best cost found {0} in round {1}'
                    .format(best_last_stage, i))
