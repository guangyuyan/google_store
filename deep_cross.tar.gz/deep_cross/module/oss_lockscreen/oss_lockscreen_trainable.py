#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
"""

from .feature_store import USER_FEATURE, IDS_FEATURE, TEXT_IDS_FEATURE
from ..base.base_trainable import BaseTrainable
import tensorflow as tf

DENSE_FLOAT_SIZE = 8 + 256
DENSE_INT_SIZE = 12 + 12
VAR_LEN_CATEGORY = ['pids'] + TEXT_IDS_FEATURE
FIX_LEN_CATEGORY = USER_FEATURE + IDS_FEATURE


class LockscreenTrainable(BaseTrainable, object):

    def __init__(self, flags):
        super(LockscreenTrainable, self).__init__(flags)

    @classmethod
    def parser(cls, record):
        prebatch = tf.flags.FLAGS.prebatch
        map_features = {}
        map_features['label'] = tf.FixedLenFeature([prebatch], tf.int64)
        map_features['dense_float'] = tf.FixedLenFeature(
                [prebatch * DENSE_FLOAT_SIZE],
                tf.float32)
        map_features['dense_int'] = tf.FixedLenFeature(
                [prebatch * DENSE_INT_SIZE],
                tf.int64)
        for feature in FIX_LEN_CATEGORY:
            map_features[feature] = tf.FixedLenFeature([prebatch], tf.int64)
        for feature in VAR_LEN_CATEGORY:
            map_features[feature] = tf.VarLenFeature(tf.int64)

        data_sample = tf.parse_single_example(record, features=map_features)
        return data_sample
