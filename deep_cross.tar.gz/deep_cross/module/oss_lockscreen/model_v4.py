#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
"""


import tensorflow as tf
from .model_v1 import LockscreenDXLModel
from .model_v0 import FIX_LEN_CATEGORY


class DXLMvmModel(LockscreenDXLModel):

    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            mvm_out = self.build_mvm_net(features)
            return tf.concat([deep_out, cross_out, mvm_out], -1)

    def build_mvm_net(self, features):
        fv_int = tf.cast(features['dense_int'], dtype=tf.float32)
        fv_int, int_ids = self.log_int(fv_int)
        fv = tf.concat([fv_int, features['dense_float']], -1)
        fv = self.build_dense_layer(fv)
        fv = tf.layers.dense(fv, self.flags.factor_size)

        with tf.device('/cpu:0'):
            ev_list = []
            for key in FIX_LEN_CATEGORY:
                if key == 'img_id':
                    continue
                ev_list.append(
                    self.single_embedding(
                        features[key],
                        layer_name=key,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.flags.factor_size,
                        initial_range=None,
                        name_scope='mvm_embedding'))
        feature_list = [fv] + ev_list
        return self.mvm_net(feature_list)
