#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Preprocess oss data
- build vocabulary for fields
- save vocabulary size
- use vocabulary to map feature to ids
- filter invalid data
- negative down sampling
- remove flipped data
"""

import argparse
import datetime
import gzip
import random
import os
import time

from .feature_store import FeatureStore


def filter_log(in_path, out_path, feature_store, user_img_clicked):
    with gzip.open(in_path, 'rb') as fin, gzip.open(out_path, 'wb') as fout:
        header = fin.readline()
        fout.write(header)
        header_list = header.strip().split('\t')
        uid_idx = header_list.index('uid')
        img_id_idx = header_list.index('img_id')
        img_use_id_idx = header_list.index('img_use_id')
        event_id_idx = header_list.index('event_id')
        for line in fin:
            content = line.strip().split('\t')
            uid = content[uid_idx]
            img_id = content[img_id_idx]
            img_use_id = content[img_use_id_idx]
            event_id = content[event_id_idx]
            user_img = '{}_{}'.format(uid, img_use_id)
            # negative sampling
            if event_id != '11' and random.randint(1, 100) > 20:
                continue
            # filter flip data
            if event_id != '11' and user_img in user_img_clicked:
                continue
            # filter invalid data
            if (not feature_store.get_user_feature(uid) or
                    not feature_store.get_image_vector(img_id) or
                    not feature_store.get_text_feature(img_use_id)):
                continue
            if event_id == '11':
                user_img_clicked.add(user_img)
            fout.write(line)


def cal_dates(start, end):
    start_date = datetime.datetime.strptime(start, "%Y%m%d")
    end_date = datetime.datetime.strptime(end, "%Y%m%d")
    date_list = [start_date + datetime.timedelta(days=x)
                 for x in range(0, (end_date - start_date).days+1)]
    date_list = [x.date().strftime('%Y%m%d') for x in date_list]
    return date_list


def filter_dates(args, feature_store):
    start = time.time()
    user_img_clicked = set()
    date_list = cal_dates(args.start_date, args.end_date)
    for date in date_list:
        in_path = os.path.join(
            args.oss_path, 'daily', date, 'ads_cb_alg_log',
            'ads_cb_alg_log.'+date+'.'+args.user_group+'.gz')
        out_dir = os.path.join(
            args.oss_path, 'daily', date, 'ads_cb_alg_log_sampled')
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        out_path = os.path.join(
            out_dir, 'ads_cb_alg_log_sampled.'+date+'.'+args.user_group+'.gz')
        filter_log(in_path, out_path, feature_store, user_img_clicked)
        end = time.time()
        print("{} secs, {} saved.".format(int(end - start), out_path))


def main(args):
    feature_store = FeatureStore(args)

    if args.build_voc:
        print("Building vocabulary.")
        feature_store.build_feature_voc()
        print("Vocabulary built.")

    print("Processing log.")
    feature_store.load_feature_store()
    filter_dates(args, feature_store)
    print("Done.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--oss_path', type=str, required=True)
    parser.add_argument('-s', '--start_date', type=str, required=True)
    parser.add_argument('-e', '--end_date', type=str, required=True)
    parser.add_argument('-u', '--user_group', type=str, default='0')
    parser.add_argument('--build_voc', action="store_true", default=False)
    main(parser.parse_args())
