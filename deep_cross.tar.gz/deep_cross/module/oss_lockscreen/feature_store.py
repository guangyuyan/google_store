#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Non-log type features
"""

import os
import numpy as np

IDS_FEATURE = ['img_id', 'dynamic_type', 'type_id', 'detail_type',
               'packagename', 'appname', 'img_recommend'
               #  'tag_id_p', 'tag_id_pp'
               ]
TEXT_IDS_FEATURE = ['img_title', 'img_content', 'url_detail_title',
                    'source_title', 'tag_id_c']
USER_FEATURE = ['model', 'resolution', 'version', 'language']


class FeatureStore:

    """Non-log type features
    - text_feature
    - image_feature
    - ads_cb_alg_user
    """

    def __init__(self, args):
        self.ids_features = None
        self.text_features = None
        self.image_vectors = None
        self.user_features = None
        self.oss_path = args.oss_path
        self.text_path = os.path.join(args.oss_path, 'text_feature')
        self.image_path = os.path.join(args.oss_path, 'image_feature')
        self.user_path = os.path.join(
            args.oss_path,
            'ads_cb_alg_user',
            'ads_cb_alg_user.' + args.user_group)
        self.text_ids_path = os.path.join(args.oss_path, 'text_feature_ids')
        self.user_ids_path = os.path.join(
            args.oss_path,
            'ads_cb_alg_user',
            'ads_cb_alg_user_ids.' + args.user_group)
        self.set_header()

    def set_header(self):
        with open(self.text_path) as fin:
            self.text_header = fin.readline().strip().split('\t')
        with open(self.image_path) as fin:
            self.image_header = fin.readline().strip().split('\t')
        with open(self.user_path) as fin:
            self.user_header = fin.readline().strip().split('\t')
        self.ids_index = [self.text_header.index(i) for i in IDS_FEATURE]
        self.text_ids_index = [self.text_header.index(i)
                               for i in TEXT_IDS_FEATURE]
        self.user_ids_index = [self.user_header.index(i) for i in USER_FEATURE]

    def set_text_features(self):
        ids_features = {}
        text_features = {}
        with open(self.text_ids_path) as fin:
            next(fin)
            for line in fin:
                ids_feature = {}
                text_feature = {}
                content = line.strip().split('\t')
                img_use_id = content[1]
                for i in self.ids_index:
                    ids_feature[self.text_header[i]] = [int(content[i])]
                for i in self.text_ids_index:
                    text_feature[self.text_header[i]] = [
                        int(x) for x in content[i].split('|')]
                ids_features[img_use_id] = ids_feature
                text_features[img_use_id] = text_feature
        self.ids_features = ids_features
        self.text_features = text_features

    def set_image_vectors(self):
        image_vectors = {}
        with open(self.image_path) as fin:
            next(fin)
            for line in fin:
                img_id, img_vec = line.strip().split('\t')
                img_vec = img_vec.split('|')
                image_vectors[img_id] = [float(i) for i in img_vec]
        self.image_vectors = image_vectors

    def set_user_features(self):
        user_features = {}
        with open(self.user_ids_path) as fin:
            next(fin)
            for line in fin:
                user_feature = {}
                content = line.strip().split('\t')
                uid = content[0]
                for i in self.user_ids_index:
                    user_feature[self.user_header[i]] = [int(content[i])]
                user_features[uid] = user_feature
        self.user_features = user_features

    def get_text_feature(self, img_use_id):
        if img_use_id in self.text_features:
            return self.text_features[img_use_id]
        else:
            return False

    def get_ids_feature(self, img_use_id):
        if img_use_id in self.ids_features:
            return self.ids_features[img_use_id]
        else:
            return False

    def get_image_vector(self, img_id):
        if img_id in self.image_vectors:
            return self.image_vectors[img_id]
        else:
            return False

    def get_user_feature(self, uid):
        if uid in self.user_features:
            return self.user_features[uid]
        else:
            return False

    def build_vocabulary(self):
        voc = {}
        voc_cnt = {}
        for key in IDS_FEATURE + TEXT_IDS_FEATURE + USER_FEATURE:
            if key == 'img_id':
                voc[key] = {}
                voc_cnt[key] = -1
                continue
            voc[key] = {'': 0}
            voc_cnt[key] = 0
        with open(self.text_path) as fin:
            next(fin)
            for line in fin:
                content = line.strip().split('\t')
                for i in self.ids_index:
                    k = self.text_header[i]
                    if content[i] not in voc[k]:
                        voc_cnt[k] += 1
                        voc[k][content[i]] = voc_cnt[k]
                for i in self.text_ids_index:
                    k = self.text_header[i]
                    words = content[i].split('|')
                    for w in words:
                        if w not in voc[k]:
                            voc_cnt[k] += 1
                            voc[k][w] = voc_cnt[k]
        with open(self.user_path) as fin:
            next(fin)
            for line in fin:
                content = line.strip().split('\t')
                for i in self.user_ids_index:
                    k = self.user_header[i]
                    if content[i] not in voc[k]:
                        voc_cnt[k] += 1
                        voc[k][content[i]] = voc_cnt[k]
        # TODO(xjfan): fix for APP id vocabulary
        voc_cnt['pids'] = 100000
        self.voc = voc
        self.voc_cnt = voc_cnt

    def save_vocabulary(self):
        with open(os.path.join(self.oss_path,
                               'vocabulary.txt'), 'w') as fout:
            for key in self.voc:
                for value in self.voc[key]:
                    fout.write('{}\t{}\t{}\n'.format(key, value,
                                                     self.voc[key][value]))
        with open(os.path.join(self.oss_path,
                               'vocabulary_summary.txt'), 'w') as fout:
            for key in self.voc_cnt:
                fout.write('{}\t{}\n'.format(key, self.voc_cnt[key] + 1))

    def read_vocabulary(self):
        self.voc = {}
        voc_path = os.path.join(self.oss_path, 'vocabulary.txt')
        print("Loading vocabulary from {}".format(voc_path))
        with open(voc_path, 'r') as fin:
            for line in fin:
                key, value, cnt = line.strip().split('\t')
                if key not in self.voc:
                    self.voc[key] = {}
                else:
                    self.voc[key][value] = cnt

    def convert_ids(self):
        with open(self.text_path, 'r') as fin,\
                open(self.text_ids_path, 'w') as fout:
            fout.write(fin.readline())
            for line in fin:
                content = line.strip().split('\t')
                new_c = list(content)
                for i in self.ids_index:
                    k = self.text_header[i]
                    new_c[i] = str(self.voc[k][content[i]])
                for i in self.text_ids_index:
                    k = self.text_header[i]
                    new_c[i] = '|'.join([str(self.voc[k][x])
                                         for x in content[i].split('|')])
                fout.write('\t'.join(new_c))
                fout.write('\n')
        with open(self.user_path, 'r') as fin,\
                open(self.user_ids_path, 'w') as fout:
            fout.write(fin.readline())
            for line in fin:
                content = line.strip().split('\t')
                new_c = list(content)
                for i in self.user_ids_index:
                    k = self.user_header[i]
                    new_c[i] = str(self.voc[k][content[i]])
                fout.write('\t'.join(new_c))
                fout.write('\n')

    def convert_iv_npz(self):
        iv_list = []
        with open(self.image_path) as fin:
            next(fin)
            for line in fin:
                iv = line.strip().split('\t')[1].split('|')
                iv_list.append(iv)
        np_iv = np.array(iv_list, dtype=float)
        np.savez_compressed(self.image_path + ".npz", iv=np_iv)

    def load_feature_store(self):
        self.set_text_features()
        self.set_image_vectors()
        self.set_user_features()

    def build_feature_voc(self):
        self.build_vocabulary()
        self.save_vocabulary()
        self.convert_ids()
        self.convert_iv_npz()
