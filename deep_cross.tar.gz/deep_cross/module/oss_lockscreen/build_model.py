#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build model
"""


from . import model_v1
from . import model_v2
from . import model_v3
from . import model_v4

import tensorflow as tf


def build_model(flags):
    if flags.model == 'v1':
        model = model_v1.LockscreenDXLModel(flags)
    elif flags.model == 'v2':
        model = model_v2.LinearModel(flags)
    elif flags.model == 'v3':
        model = model_v3.DXLImageVectorModel(flags)
    elif flags.model == 'v4':
        model = model_v4.DXLMvmModel(flags)
    else:
        raise ValueError('--model {} was not found.'.format(flags.model))
    return model
