#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Client to use rpc conneting the Sever to send features and get labels back
CUDA_VISIBLE_DEVICE=0 python3 -m module.oss_lockscreen.model_client --server=localhost:9000 --work_dir=/ssd/users/xyyu/data/oss_lockscreen/valid.txt --server_model_name=model_v1 --num_tests=1 --voc_dir=/ssd/users/xjfan/oss_lockscreen/vocabulary_summary.txt

"""

from .model_v0 import BaseLockscreenDXLModel
from ..base.client_utils import client_test


if __name__ == '__main__':
    BaseLockscreenDXLModel.voc_emb_size = BaseLockscreenDXLModel.load_voc_summary()
    client_test(BaseLockscreenDXLModel)
