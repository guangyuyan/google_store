#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Log features and data sample
"""

import gzip
import os

from datetime import datetime, timedelta


def minus_two_days(d):
    date = datetime.strptime(d, '%Y%m%d')
    return (date - timedelta(days=2)).strftime('%Y%m%d')


class Sample:

    """Log(daily) features
    - ads_cb_alg_log
    - ads_cb_alg_img_summary
    - ads_cb_alg_user_summary
    - ads_cb_alg_applist_full
    - ads_cb_alg_click_action
    """

    def __init__(self, feature_store):
        self.img_summary = None
        self.user_summary = None
        self.user_app_list = None
        self.feature_store = feature_store
        self.log_path = None

    def _concat_summary(self, summary_dict, key, event, counts):
        counts = [int(float(x)) if x != '' else 0 for x in counts]
        if key not in summary_dict:
            summary_dict[key] = [0] * 12
        if event == '11':
            summary_dict[key][0:4] = counts
        elif event == '21':
            summary_dict[key][4:8] = counts
        elif event == '22':
            summary_dict[key][8:12] = counts

    def _cal_click_rate(self, summary):
        click_rates = {}
        for key in summary:
            click_rates[key] = []
            for i in range(4):
                click_rates[key].append(
                    (summary[key][i] + 1.0) /
                    (summary[key][i + 4] + summary[key][i + 8] + 7))
        return click_rates

    def set_log_path(self, log_path):
        self.log_path = log_path

    def set_img_summary(self, img_summary_path):
        img_summary = {}
        with gzip.open(img_summary_path, 'rb') as fin:
            next(fin)
            for line in fin:
                content = line.strip().split('\t')
                img_use_id = content[1]
                event = content[2]
                counts = content[3:7]
                self._concat_summary(img_summary, img_use_id, event, counts)
        self.img_summary = img_summary
        self.img_rates = self._cal_click_rate(img_summary)

    def set_user_summary(self, user_summary_path):
        user_summary = {}
        with gzip.open(user_summary_path, 'rb') as fin:
            next(fin)
            for line in fin:
                content = line.strip().split('\t')
                uid = content[0]
                event = content[1]
                counts = content[2:6]
                self._concat_summary(user_summary, uid, event, counts)
        self.user_summary = user_summary
        self.user_rates = self._cal_click_rate(user_summary)

    def set_user_app_list(self, app_list_path):
        user_app_list = {}
        with gzip.open(app_list_path, 'rb') as fin:
            next(fin)
            for line in fin:
                uid, app_list = line.strip().split('\t')
                user_app_list[uid] = [int(x) for x in app_list.split('|')]
        self.user_app_list = user_app_list

    def _check_label(self, text):
        if text == '11':
            return 1
        else:
            return 0

    def _combine_sample(self, data_line):
        uid, img_id, img_use_id, event_id, event_cnt = data_line
        data_sample = {}
        data_sample['label'] = [self._check_label(event_id)]
        data_sample['ids'] = {}
        data_sample['ids'].update(self.feature_store.get_user_feature(uid))
        data_sample['ids'].update(
            self.feature_store.get_ids_feature(img_use_id))
        data_sample['dense_int'] = []
        data_sample['dense_int'].extend(self.get_img_summary(img_use_id))
        data_sample['dense_int'].extend(self.get_user_summary(uid))
        data_sample['dense_float'] = []
        data_sample['dense_float'].extend(self.get_img_rate(img_use_id))
        data_sample['dense_float'].extend(self.get_user_rate(uid))
        if not self.skip_image:
            data_sample['dense_float'].extend(
                self.feature_store.get_image_vector(img_id))
        data_sample['var_ids'] = {}
        data_sample['var_ids'].update(
            self.feature_store.get_text_feature(img_use_id))
        data_sample['var_ids']['pids'] = self.get_user_app_list(uid)
        return data_sample

    def get_sample(self):
        with gzip.open(self.log_path, 'rb') as fin:
            next(fin)
            for line in fin:
                data_line = line.strip().split('\t')
                data_sample = self._combine_sample(data_line)
                yield data_sample

    def get_img_summary(self, img_use_id):
        if img_use_id in self.img_summary:
            return self.img_summary[img_use_id]
        else:
            return [0] * 12

    def get_user_summary(self, uid):
        if uid in self.user_summary:
            return self.user_summary[uid]
        else:
            return [0] * 12

    def get_img_rate(self, img_use_id):
        if img_use_id in self.img_rates:
            return self.img_rates[img_use_id]
        else:
            return [0.0] * 4

    def get_user_rate(self, uid):
        if uid in self.user_rates:
            return self.user_rates[uid]
        else:
            return [0.0] * 4

    def get_user_app_list(self, uid):
        if uid in self.user_app_list:
            return self.user_app_list[uid]
        else:
            return [0]

    def load_sample_lib(self, args, sample_date):
        sample_date_minus_two = minus_two_days(sample_date)
        date_path = os.path.join(args.oss_path, 'daily', sample_date)
        date_path_minus_two = os.path.join(args.oss_path, 'daily',
                                           sample_date_minus_two)
        log_path = os.path.join(
            date_path, 'ads_cb_alg_log_sampled',
            'ads_cb_alg_log_sampled.'+sample_date+'.'+args.user_group+'.gz')
        self.skip_image = args.skip_image
        self.set_log_path(log_path)
        self.set_user_app_list(os.path.join(
            date_path_minus_two, 'ads_cb_alg_applist_full',
            'ads_cb_alg_applist_full.'+sample_date_minus_two+'.'+args.user_group+'.gz'))
        self.set_img_summary(os.path.join(
            date_path_minus_two, 'ads_cb_alg_img_summary.gz'))
        self.set_user_summary(os.path.join(
            date_path_minus_two, 'ads_cb_alg_user_summary',
            'ads_cb_alg_user_summary.'+sample_date_minus_two+'.'+args.user_group+'.gz'))
