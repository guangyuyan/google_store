#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base DXL with lockstream data
"""

from ..base.model_dxl import BaseDXLModel
from .oss_lockscreen_trainable import LockscreenTrainable
from .oss_lockscreen_trainable import DENSE_FLOAT_SIZE, DENSE_INT_SIZE
from .oss_lockscreen_trainable import VAR_LEN_CATEGORY, FIX_LEN_CATEGORY
import tensorflow as tf

OUTPUT_NAME = "predictions"


class BaseLockscreenDXLModel(BaseDXLModel, LockscreenTrainable, object):
    voc_emb_size = None

    def __init__(self, flags):
        BaseDXLModel.__init__(self, flags)
        LockscreenTrainable.__init__(self, flags)
        BaseLockscreenDXLModel.voc_emb_size = self.load_voc_summary()
        self.model_inputs = {}
        self.model_outputs = {}

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_file,  batch_size,
                          epochs, shuffle=True):
        return LockscreenTrainable.tfrecord_pipeline(tfrecord_file, batch_size,
                                                     epochs, shuffle)

    @classmethod
    def load_voc_summary(cls):
        # set default vocabulary and embedding size
        voc_emb_size = {key: [100000, 100] for key in VAR_LEN_CATEGORY}
        with open(tf.flags.FLAGS.voc_dir) as f:
            for line in f:
                content = line.strip().split('\t')
                key = content[0]
                voc_size = int(content[1])
                emb_size = cls.compute_emb_size(voc_size)
                voc_emb_size[key] = [voc_size, emb_size]
        for key, value in voc_emb_size.items():
            cls.print_emb_info(key, value[0], value[1])
        return voc_emb_size

    @classmethod
    def reshape_input(cls, features):
        labels = features.pop('label')
        labels = tf.reshape(labels, [-1, 1])
        features['dense_float'] = tf.reshape(features['dense_float'],
                                             [-1, DENSE_FLOAT_SIZE])
        features['dense_int'] = tf.reshape(features['dense_int'],
                                           [-1, DENSE_INT_SIZE])
        for key in FIX_LEN_CATEGORY:
            features[key] = tf.reshape(features[key], [-1, 1])
        for key in VAR_LEN_CATEGORY:
            features[key] = cls.reshape_sparse(
                features[key], cls.voc_emb_size[key][0])
        return features, labels

    @classmethod
    def reshape_sparse2(cls, feature, voc_size):
        with tf.device('/cpu:0'):
            new_indices = (feature.values // voc_size +
                           feature.indices[:, 0] * tf.flags.FLAGS.prebatch)
            new_feature = tf.SparseTensor(
                indices=tf.stack([new_indices, feature.values % voc_size],
                                 axis=1),
                values=feature.values % voc_size,
                dense_shape=[-1, voc_size])
            return new_feature

    @classmethod
    def reshape_sparse(cls, feature, voc_size):
        with tf.device('/cpu:0'):
            value = tf.cast(feature.values, tf.int64)
            idx = tf.stack([feature.indices[:, 0], value], axis=1)
            new_f = tf.SparseTensor(indices=idx,
                                    values=value,
                                    dense_shape=[tf.flags.FLAGS.batch_size,
                                                 tf.flags.FLAGS.prebatch * voc_size])
            new_reshape = tf.sparse_reshape(new_f, shape=[-1, voc_size])
            return tf.SparseTensor(indices=new_reshape.indices,
                                   values=new_reshape.indices[:, 1],
                                   dense_shape=new_reshape.dense_shape)

    def build(self):
        features, labels = self.build_input()
        self.reshape_sparse2dense(features)
        self.model_inputs = self.build_model_tensors_info(features)
        self.features = features
        self.reshape_dense2sparse(features)
        self.labels = [labels]
        v = self.build_network(features)
        with tf.device('/gpu:0'):
            preds = self.build_predictions(v)
            self.preds = [preds]
            if self.prediction_signature is None:
                self.model_outputs[OUTPUT_NAME] = \
                    tf.saved_model.utils.build_tensor_info(preds)
                self.set_prediction_signature(self.model_inputs,
                                              self.model_outputs)
            loss = self.build_loss(labels, preds)
            self.costs = self.build_eval_metric_ops(labels, preds, loss)
            self.build_cost_summary()
            self.train_op = self.build_train_op(loss)
