#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <xjfan@>
#
# Distributed under terms of the CloudBrain license.

"""
Join app list from ads_cb_alg_applist_full and ads_cb_alg_applist_delta
"""

import argparse
import time
import os
import gzip
import datetime


def read_full_list(path):
    full_list = {}
    with gzip.open(path, 'rb') as fin:
        next(fin)
        for line in fin:
            uid, app_list = line.strip().split('\t')
            app_list = set(app_list.split('|'))
            full_list[uid] = app_list
    return full_list


def add_one_day(full_list, path):
    with gzip.open(path, 'rb') as fin:
        next(fin)
        for line in fin:
            uid, app_list, status = line.strip().split('\t')
            app_list = set(app_list.split('|'))
            if uid not in full_list and status == '1':
                full_list[uid] = app_list
                continue
            if status == '1':
                full_list[uid].union(app_list)
            elif status == '-1':
                full_list[uid] = full_list[uid] - app_list


def write_format(full_list):
    output = []
    for uid in full_list:
        output.append('{}\t{}'.format(uid, '|'.join(full_list[uid])))
    output.sort()
    output.insert(0, 'uid\tpids')
    return output


def main(args):
    start = time.time()
    full_path = os.path.join(
        args.oss_path, 'daily', args.full_date,
        'ads_cb_alg_applist_full', 'ads_cb_alg_applist_full.' +
        args.full_date + '.' + args.user_group + '.gz')
    full_list = read_full_list(full_path)
    full_date = datetime.datetime.strptime(args.full_date, "%Y%m%d").date()
    end = time.time()
    print('{} done {:.2f} secs'.format(full_path, end-start))
    print('Full list has {} elements'.format(len(full_list.values())))

    for i in range(1, 7):
        join_date = full_date + datetime.timedelta(days=i)
        join_date = join_date.strftime('%Y%m%d')
        delta_path = os.path.join(
            args.oss_path, 'daily', join_date,
            'ads_cb_alg_applist_delta', 'ads_cb_alg_applist_delta.' +
            join_date + '.' + args.user_group + '.gz')
        try:
            add_one_day(full_list, delta_path)
        except:
            continue

        write_dir = os.path.join(
            args.oss_path, 'daily', join_date, 'ads_cb_alg_applist_full')
        if not os.path.exists(write_dir):
            os.makedirs(write_dir)
        write_path = os.path.join(
            write_dir, 'ads_cb_alg_applist_full.' + join_date +
            '.' + args.user_group + '.gz')
        output = write_format(full_list)
        with gzip.open(write_path, 'wb') as fout:
            fout.write('\n'.join(output))

        end = time.time()
        print('{} done {:.2f} secs'.format(delta_path, end-start))
        print('Joined list has {} elements'.format(len(full_list.values())))
    print('Joining ends.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--oss_path', type=str, required=True)
    parser.add_argument('-f', '--full_date', type=str, required=True)
    parser.add_argument('-u', '--user_group', type=str, default='0')
    main(parser.parse_args())
