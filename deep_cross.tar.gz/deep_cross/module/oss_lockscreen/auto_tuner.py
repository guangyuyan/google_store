#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
auto tuner for hyperparameter searching
"""

import tensorflow as tf
from hyperopt import STATUS_OK
from hyperopt import hp
import hyperopt as hopt
import copy
from .build_model import build_model
import time

search_cnt = 0


class Config:
    spaces = [
        {'learning_rate': hp.choice("x_learning_rate", [0.00005, 0.0001]),
         'deep_layers': hp.choice("x_deep_layers", ['512,512', '512,512,512', '512,512,512,512']),
         'cross_layers': hp.choice("x_cross_layers", [2, 3]),
         'model': hp.choice("x_model", ['v1', 'v4']),
         'keep_prob': hp.choice("x_keep_prob", [0.5, 0.8, 1.0]),
         'HOPT_ITERATION': 30}
    ]

    constants = [
        '--model_name=test',
        '--model_path=./run/oss_lockscreen/outputs',
        '--checkpoint_path=./run/oss_lockscreen/outputs',
        '--data_per_valid=2000000',
        '--epochs=2',
        '--patient_valid_passes=5',
        '--batch_size=4',
        '--prebatch=256',
        '--summaries_dir=./run/oss_lockscreen/summaries/',
        '--train_data=/ssd/users/xjfan/lockscreen/oss_tf6/train.txt',
        '--valid_data=/ssd/users/xjfan/lockscreen/oss_tf6/valid.txt',
        '--voc_dir=/ssd/users/xjfan/lockscreen/oss_tf6/vocabulary_summary.txt'
    ]


def cost(space):
    global search_cnt
    tf.reset_default_graph()
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    tf.app.flags.FLAGS(Config.constants, known_only=True)
    flags = tf.app.flags.FLAGS
    flags.deep_layers = space['deep_layers']
    flags.cross_layers = space['cross_layers']
    flags.learning_rate = space['learning_rate']
    flags.model = space['model']

    model = build_model(flags)
    model.build()
    with tf.Session(config=sess_config) as session:
        session.run([tf.global_variables_initializer(),
                     tf.local_variables_initializer(),
                     tf.tables_initializer(),
                     model.initializer()])
        loss = model.train(session)
    search_cnt += 1
    tf.logging.warn('--AutoTuner-- Search round {}, current space setting {}'
                    .format(search_cnt, space))
    tf.logging.warn('--AutoTuner-- {} Loss={}'
                    .format(time.strftime('%Y%m%d %H:%M:%S'), loss))
    return {'loss': float(loss), 'status': STATUS_OK}


def main():
    best_last_stage = {}
    for i, space in enumerate(Config.spaces):
        current_space = copy.deepcopy(best_last_stage)
        for s in space:
            current_space[s] = space[s]
        try:
            hopt_iteration = current_space['HOPT_ITERATION']
            current_space.pop('HOPT_ITERATION', None)
        except:
            tf.logging.error('--AutoTuner-- Please config {0} in'
                             'each space defination.'.format('HOPT_ITERATION'))
            raise

        tf.logging.warn('--AutoTuner-- Round {0} Config Space {1}'
                        .format(i, current_space))
        rt = hopt.fmin(fn=cost,
                       space=current_space,
                       algo=hopt.tpe.suggest,
                       max_evals=hopt_iteration)
        best_value = hopt.space_eval(space, rt)
        for s in best_value:
            best_last_stage[s] = best_value[s]
        tf.logging.warn('--AutoTuner-- Best cost found {0} in round {1}'
                        .format(best_last_stage, i))


if __name__ == '__main__':
    main()
