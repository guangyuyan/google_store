#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <xjfan@>
#
# Distributed under terms of the CloudBrain license.

"""
Convert oss data to tfrecord
"""

import argparse
import time
import tensorflow as tf
import os
import copy

from .sample import Sample
from .feature_store import FeatureStore
from .preprocess_oss import cal_dates


class SampleTF:
    def __init__(self, args, sample_date):
        self.options = tf.python_io.TFRecordOptions(
                    tf.python_io.TFRecordCompressionType.GZIP)
        self.out_path = os.path.join(
            args.out_path,
            'ads_cb_alg_log_sampled.'+sample_date+'.'+args.user_group+'.tf')
        self.writer = tf.python_io.TFRecordWriter(self.out_path,
                                                  options=self.options)
        self.batch_data = None
        self.voc_summary_path = os.path.join(args.oss_path,
                                             'vocabulary_summary.txt')
        self._load_voc_summary()
        self.save_raw = args.save_raw
        self.raw_writer = open('./temp.text', 'w')
        print("Converting log {} to tfrecord.".format(sample_date))
        if self.save_raw:
            print("Saving raw data too.")

    def _int64_feature(self, value):
        return tf.train.Feature(
            int64_list=tf.train.Int64List(value=value))

    def _float_feature(self, value):
        return tf.train.Feature(
            float_list=tf.train.FloatList(value=value))

    def _load_voc_summary(self):
        self.voc_summary = {}
        with open(self.voc_summary_path) as fin:
            for line in fin:
                key, size = line.strip().split('\t')
                self.voc_summary[key] = int(size)

    def write_tf_sample(self):
        tf_features = {}
        tf_features['label'] = self._int64_feature(self.batch_data['label'])
        tf_features['dense_int'] = self._int64_feature(
            self.batch_data['dense_int'])
        tf_features['dense_float'] = self._float_feature(
            self.batch_data['dense_float'])
        for key in self.batch_data['ids']:
            tf_features[key] = self._int64_feature(
                self.batch_data['ids'][key])
        for key in self.batch_data['var_ids']:
            tf_features[key] = self._int64_feature(
                self.batch_data['var_ids'][key])
        example = tf.train.Example(
            features=tf.train.Features(
                feature=tf_features
            ))
        self.writer.write(example.SerializeToString())
        if self.save_raw:
            self._write_raw_data(self.batch_data)
        self.batch_data = None

    def _print_size(self, data):
        print('label size {}'.format(len(data['label'])))
        print('dense_int size {}'.format(len(data['dense_int'])))
        print('dense_float size {}'.format(len(data['dense_float'])))
        for k in data['ids']:
            print('ids {} size {}'.format(k, len(data['ids'][k])))
        for k in data['var_ids']:
            print('var_ids {} size {}'.format(k, len(data['var_ids'][k])))

    def _concat_data(self, data):
        d_list = []
        d_list.extend(data['label'])
        for k in data['ids']:
            d_list.extend(data['ids'][k])
        d_list.extend(data['dense_int'])
        d_list.extend(data['dense_float'])
        for k in data['var_ids']:
            d_list.extend(data['var_ids'][k])
        d_list = [str(x) for x in d_list]
        return d_list

    def _write_raw_data(self, data):
        d_list = self._concat_data(data)
        self.raw_writer.write('\t'.join(d_list))
        self.raw_writer.write('\n')

    def add_prebatch(self, data, batch_index):
        if self.batch_data == None:
            self.batch_data = copy.deepcopy(data)
        else:
            for key in ['label', 'dense_int', 'dense_float']:
                self.batch_data[key].extend(data[key])
            for key in data['ids']:
                self.batch_data['ids'][key].extend(data['ids'][key])
            for key in data['var_ids']:
                # batch shift for tf var length ids feature
                shifted = [x + self.voc_summary[key] * batch_index
                           for x in data['var_ids'][key]]
                self.batch_data['var_ids'][key].extend(shifted)

    def close_writer(self):
        self.writer.close()
        self.raw_writer.close()


def main(args):

    start = time.time()
    feature_store = FeatureStore(args)
    feature_store.load_feature_store()
    end = time.time()
    print("{} seconds, finished loading feature lib.".format(int(end-start)))

    date_list = cal_dates(args.start_date, args.end_date)

    for sample_date in date_list:
        sample = Sample(feature_store)
        sample.load_sample_lib(args, sample_date)
        end = time.time()
        print("{} seconds, start converting logs {}.".format(
            int(end-start), sample_date))
        cnt = 0
        start_log = time.time()
        sample_tf = SampleTF(args, sample_date)
        for data in sample.get_sample():
            sample_tf.add_prebatch(data, cnt % args.prebatch)
            cnt += 1
            if cnt % args.prebatch == 0:
                sample_tf.write_tf_sample()
            if cnt % 100000 == 0:
                end = time.time()
                print("{} seconds, {} samples, {:.2f} qps".format(
                    int(end-start), cnt, cnt/(end-start_log)))
        sample_tf.close_writer()
        print("{} seconds, finish converting logs {}.".format(
            int(end-start), sample_date))
    print("Done.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--oss_path', type=str, required=True)
    parser.add_argument('-o', '--out_path', type=str, required=True)
    parser.add_argument('-s', '--start_date', type=str, required=True)
    parser.add_argument('-e', '--end_date', type=str, required=True)
    parser.add_argument('-p', '--prebatch', type=int, default=256)
    parser.add_argument('-u', '--user_group', type=str, default='0')
    parser.add_argument('--save_raw', action="store_true", default=False)
    parser.add_argument('--skip_image', action="store_true", default=False)
    main(parser.parse_args())
