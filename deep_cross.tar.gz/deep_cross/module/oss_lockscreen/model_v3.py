#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
image vector load through embedding_lookup
"""


import tensorflow as tf
import numpy as np
from .model_v1 import LockscreenDXLModel
from .model_v0 import VAR_LEN_CATEGORY, FIX_LEN_CATEGORY


class DXLImageVectorModel(LockscreenDXLModel):
    def __init__(self, flags):
        super(DXLImageVectorModel, self).__init__(flags)
        self.iv_emb_init, self.iv_embedding = self.build_iv_embedding()

    def build_features(self, features):
        with tf.device('/gpu:0'):
            ev_list = []
            for key in FIX_LEN_CATEGORY:
                if key == 'img_id':
                    continue
                ev_list.append(
                    self.build_single_embedding(
                        features[key],
                        layer_name=key,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))
            sparse_ev_list = []
            for key in VAR_LEN_CATEGORY:
                sparse_ev_list.append(
                    self.build_sparse_embedding(
                        features[key],
                        layer_name=key,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))
            fv_int = tf.cast(features['dense_int'], dtype=tf.float32)
            fv_int, int_ids = self.log_int(fv_int)

            iv = tf.reshape(tf.nn.embedding_lookup(
                self.iv_embedding, features['img_id']), [-1, 256])
            fv = tf.concat([fv_int, features['dense_float'], iv], -1)
            fv = self.build_dense_layer(fv)

            int_ev_list = []

            network_inputs = self.concat(
                [fv] + ev_list + sparse_ev_list + int_ev_list)
            input_dim = 0
            for key in network_inputs:
                tf.logging.warn(key)
                input_dim += int(key.get_shape()[-1])
            tf.logging.warn("Total input dim: {}".format(input_dim))
            return network_inputs

    def build_iv_embedding(self):
        """
        init() is function and need to call before training
        """
        ivs = np.load(self.flags.iv_npz)['iv']
        iv_embedding = tf.Variable(tf.constant(0.0, shape=ivs.shape),
                                   trainable=False, name='iv_embedding')
        iv_embedding_placeholder = tf.placeholder(tf.float32, ivs.shape)
        iv_embedding_init = iv_embedding.assign(iv_embedding_placeholder)

        def init(session):
            session.run(iv_embedding_init,
                        feed_dict={iv_embedding_placeholder: ivs})
        return init, iv_embedding
