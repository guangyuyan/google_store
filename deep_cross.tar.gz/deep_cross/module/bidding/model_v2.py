#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V2: https://d.cloudbrain.cc:10443/developers/deep_cross/wikis/0907
"""


import tensorflow as tf

# from .feature_store import FEATURES
from .model_v1 import BiddingCVRModel


class BiddingCVRModelMixtureHistory(BiddingCVRModel):
    def __init__(self, flags):
        super(BiddingCVRModelMixtureHistory, self).__init__(flags)

    def build_network(self, features, embedding_suffix=''):
        ctr, cvr = super(BiddingCVRModelMixtureHistory, self).build_network(
            features, embedding_suffix)
        if not self.flags.with_event_feature:
            return ctr, cvr
        with tf.device('/gpu:0'):
            return self.build_mixture_history(ctr, features['ctr_stats']), \
                self.build_mixture_history(cvr, features['cvr_stats'])

    def build_features(self, features, embedding_suffix=''):
        with tf.device('/gpu:0'):
            inputs = []
            for key in features:
                if key == 'dense':
                    inputs.append(self.build_dense_layer(features[key]))
                    continue
                if key in ('ctr_stats', 'cvr_stats'):
                    continue
                inputs.append(
                    self.build_single_embedding(
                        features[key],
                        layer_name=key + embedding_suffix,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))
            inputs = self.concat(inputs)
            input_dim = 0
            for k in inputs:
                tf.logging.warn(k)
                input_dim += int(k.get_shape()[-1])
            tf.logging.warn('total input dim: {}'.format(input_dim))
            return inputs

    def build_mixture_history(self, dense, history, epsilon=1e-7):
        dim = history.shape[1]
        weights = tf.layers.Dense(dim)(dense)
        history = tf.minimum(tf.maximum(history, epsilon), 1 - epsilon)
        historical_logits = tf.log(history / (1 - history))
        # It's row-wise innper product
        logit = tf.einsum('ij,ij->i', weights, historical_logits)
        return tf.expand_dims(logit, -1)
