#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
V1:
    cross: BN(log(dense)) + embedding
    deep: BN(log(dense)) + embedding
"""


import tensorflow as tf

from .feature_store import FEATURES, DENSE_FEATURES
from .model_v0 import BaseBiddingCVRModel


class BiddingCVRModel(BaseBiddingCVRModel):
    def __init__(self, flags):
        super(BiddingCVRModel, self).__init__(flags)

    def build_features(self, features, embedding_suffix=''):
        with tf.device('/gpu:0'):
            inputs = []
            for key in FEATURES:
                if key in DENSE_FEATURES:
                    inputs.append(self.build_dense_layer(features[key]))
                    continue
                inputs.append(
                    self.build_single_embedding(
                        features[key],
                        layer_name=key + embedding_suffix,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))
            inputs = self.concat(inputs)
            input_dim = 0
            for k in inputs:
                tf.logging.warn(k)
                input_dim += int(k.get_shape()[-1])
            tf.logging.warn('total input dim: {}'.format(input_dim))
            return inputs

    def build_dense_layer(self, fv):
        return fv / 1000000
