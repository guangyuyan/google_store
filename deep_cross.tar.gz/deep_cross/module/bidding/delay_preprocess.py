#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Preprocess csv file and create feature id list
"""

import bisect
import cProfile
import glob
import gzip
import math
import numpy as np
import os
import pstats
import re
import sys
from io import StringIO
import tensorflow as tf
from .feature_store import FEATURES, DICT_FEATURES, HASH_FEATURES, HASH_SIZE
from .feature_store import DENSE_FEATURES
from .model_v0 import BaseBiddingCVRModel

HOUR_IN_SECONDS = 3600
DAY_IN_SECONDS = 24 * HOUR_IN_SECONDS


tf.flags.DEFINE_bool('dry_run', False, 'Write outputs')
tf.flags.DEFINE_bool('data_check', False, 'Check the data format')
tf.flags.DEFINE_bool('profile', False, 'run profiler')
tf.flags.DEFINE_integer('num_datasets', 30, 'num of datasets to generate')
tf.flags.DEFINE_integer('stats_gap', HOUR_IN_SECONDS,
                        'Delay in seconds when computing stats, default: 1h')
tf.flags.DEFINE_integer('train_day', 14,
                        'number of days used as training data')
tf.flags.DEFINE_integer('valid_test_day', 1,
                        'number of days used as valid and test data')
tf.flags.DEFINE_float('valid_pct', 0.5,
                      'the valid data percentage in valid and test data')
tf.flags.DEFINE_string('input_dir', '/ssd/users/xyyu/data/bidding',
                       'working directory')
tf.flags.DEFINE_string('input_tsv', 'criteo_attribution_dataset.tsv.gz',
                       'input data file')
tf.flags.DEFINE_string('output_dir', '/ssd/users/xyyu/data/bidding',
                       'working directory')
tf.flags.DEFINE_string('train_tfrecord', 'bidding_train.tf',
                       'output tfrecord training file')
tf.flags.DEFINE_string('valid_tfrecord', 'bidding_valid.tf',
                       'output tfrecord valid file')
tf.flags.DEFINE_string('test_tfrecord', 'bidding_test.tf',
                       'output tfrecord testing file')
tf.flags.DEFINE_string('stats_dir', 'stats',
                       'sub directory under input_dir containing stat files')
tf.flags.DEFINE_string('sub_voc_dir', 'voc_size.txt',
                       'voc size of features')
tf.flags.DEFINE_string('sub_dict_dir', 'feature_dict.txt',
                       'features dictionary')


def _int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=value))


def _float_feature(value):
    return tf.train.Feature(float_list=tf.train.FloatList(value=value))


def load_dict(load_dir):
    rename_ids = {field_id: {} for field_id in DICT_FEATURES}
    with open(load_dir, 'r') as f:
        while True:
            line = f.readline()
            if ('' == line):
                break
            fid, size = line.split("\t")
            for _ in range(int(size)):
                line = f.readline()
                key, value = tuple(filter(None, line.split("\t")))
                rename_ids[fid][key] = int(value)
    return rename_ids


def lookup_dict(rename_ids, key, cat_id):
    try:
        if cat_id not in rename_ids[key]:
            return 0
        else:
            return rename_ids[key][cat_id]
    except KeyError:
        print('I got a KeyError - "%s"' % (key))


def insert_dict(rename_ids, key, cat_id):
    try:
        if cat_id not in rename_ids[key]:
            new_cat_id = len(rename_ids[key])+1
            rename_ids[key][cat_id] = new_cat_id
            return new_cat_id
        else:
            return rename_ids[key][cat_id]
    except KeyError:
        print('I got a KeyError - "%s"' % (key))


def load_all_stats(dir):
    all_stats = {}
    for filename in glob.glob(dir):
        load_stats(all_stats, filename)
    return all_stats


def load_stats(all_stats, filename):
    """
    An example filename is
    /ssd/users/byzhang/data/bidding/stats/imp_campaign_cat1.csv
    and one line may be
    73322X1973606\t633220,677831,1165362,1873955
    """
    dim = os.path.splitext(os.path.basename(filename))[0]
    print('loading {}'.format(dim))
    cur_stats = {}
    with open(filename) as f:
        for line in f:
            line = line.strip()
            key, val_str = line.split()
            cur_stats[key] = list(map(int, re.split(',', val_str)))
    all_stats[dim] = cur_stats


def compute_stat(all_stats, event, dim, key, cur_ts, stats_gap):
    """
    returns event_rate, [num_imps, time_since_first_imp]
    """
    ts_threshold = cur_ts - stats_gap
    stats = all_stats['imp_' + dim]
    imps = stats.get(key, [])
    num_imps = bisect.bisect_left(imps, ts_threshold)
    if num_imps == 0:
        return 0, [0, 0]
    stats = all_stats[event + '_' + dim]
    events = stats.get(key, [])
    num_events = bisect.bisect_left(events, ts_threshold)
    return num_events * 1.0 / num_imps, [math.log1p(num_imps),
                                         math.log1p(ts_threshold - imps[0])]


def compute_stats(all_stats, event, feature_list, stats_gap):
    campaign = feature_list[2]
    cur_ts = feature_list[0]
    event_stats = []
    dense_features = []
    dim = 'campaign'
    key = str(campaign)
    rate, dense = compute_stat(
        all_stats, event, dim, key, cur_ts, stats_gap)
    event_stats.append(rate)
    dense_features.extend(dense)

    for cat in [1, 2, 4, 5, 6, 8, 9]:
        dim = 'cat' + str(cat)
        key = str(feature_list[5 + cat])
        rate, dense = compute_stat(
            all_stats, event, dim, key, cur_ts, stats_gap)
        event_stats.append(rate)
        dense_features.extend(dense)

        dim = 'campaign_' + dim
        key = '{}X{}'.format(campaign, key)
        rate, dense = compute_stat(
            all_stats, event, dim, key, cur_ts, stats_gap)
        event_stats.append(rate)
        dense_features.extend(dense)
        for cat2 in [2, 4, 5, 6, 8, 9]:
            if cat2 <= cat:
                continue
            dim = 'cat{}_cat{}'.format(cat, cat2)
            key2 = str(feature_list[5 + cat2])
            key = '{}X{}'.format(str(feature_list[5 + cat]), key2)
            rate, dense = compute_stat(
                all_stats, event, dim, key, cur_ts, stats_gap)
            event_stats.append(rate)
            dense_features.extend(dense)

    return event_stats, dense_features


def add_one_feature(raw_features, name, value, rename_ids, train):
    if train:
        feature = insert_dict(rename_ids, name, value)
    else:
        feature = lookup_dict(rename_ids, name, value)
    raw_features[name].append(feature)


def write_features(writer, click_list, conv_list, delay_or_elapse_list,
                   raw_features):
    if tf.flags.FLAGS.dry_run:
        return
    features = {
        'click': _int64_feature(click_list),
        'conv': _int64_feature(conv_list),
        'delay_or_elapse': _float_feature(delay_or_elapse_list)}

    for key, value in raw_features.items():
        if key in ('ctr_stats', 'cvr_stats', 'dense'):
            features.update({key: _float_feature(value)})
        else:
            features.update({key: _int64_feature(value)})
    example = tf.train.Example(features=tf.train.Features(feature=features))
    writer.write(example.SerializeToString())


def write_lines_to_tfrecord(data, start, rename_ids, prebatch, writer,
                            all_stats, start_imp_time, end_imp_time,
                            end_conv_time, train=False, fix_delay=True):
    '''
        start: start index of data, which is a list of records.
        start_imp_time, end_imp_time, end_conv_time: in seconds
        if fix_delay: end_cov_time means the fix lateset time for conv.
        if not fix_delay: end_conv_time means the max duration between imp and
                          conv
    '''

    next_batch_index = -1
    next_batch_time = start_imp_time+DAY_IN_SECONDS
    data_len = len(data)
    cur_end_conv_time = end_conv_time
    conv_count = 0
    orig_conv_count = 0

    while start+prebatch <= data_len:
        raw_features = {field_id: [] for field_id in FEATURES}
        click_list = []
        conv_list = []
        delay_or_elapse_list = []
        for index in range(start, start+prebatch):
            feature_list = data[index]
            imp_time = feature_list[0]
            if(next_batch_index == -1 and imp_time > next_batch_time):
                next_batch_index = index
            if(imp_time > end_imp_time):
                return next_batch_index, index, conv_count, orig_conv_count
            click_list.append(feature_list[5])

            # re-calculate conv label and delay_or_elapse time
            conv_time = feature_list[4]
            if not fix_delay:
                cur_end_conv_time = imp_time + end_conv_time
            if conv_time > -1:
                orig_conv_count += 1
            if conv_time == -1 or conv_time > cur_end_conv_time:
                conv_list.append(0)
                delay_or_elapse_list.append(
                    (cur_end_conv_time-imp_time) * 1. / HOUR_IN_SECONDS)
            else:
                conv_list.append(1)
                delay_or_elapse_list.append(
                    (conv_time-imp_time) * 1. / HOUR_IN_SECONDS)

            add_one_feature(raw_features, 'campaign', feature_list[2],
                            rename_ids, train)
            raw_features['uid'].append(feature_list[1] % HASH_SIZE+1)

            for i in range(1, 10):
                add_one_feature(raw_features, 'cat{}'.format(i),
                                feature_list[5 + i], rename_ids, train)

            if tf.flags.FLAGS.with_event_feature:
                ctr, dense = compute_stats(
                    all_stats, 'click', feature_list, tf.flags.FLAGS.stats_gap)
                raw_features['ctr_stats'].extend(ctr)
                raw_features['dense'].extend(dense)
                cvr, _ = compute_stats(
                    all_stats, 'conv', feature_list, tf.flags.FLAGS.stats_gap)
                raw_features['cvr_stats'].extend(cvr)
        start += prebatch
        conv_count += np.count_nonzero(conv_list)
        write_features(writer, click_list, conv_list, delay_or_elapse_list,
                       raw_features)
    return -1, -1, conv_count, orig_conv_count


def dump_dict(rename_ids, voc_dir, dict_dir):
    with open(voc_dir, 'w') as f1:
        for fid, sub_dict in rename_ids.items():
            f1.write(fid+'\t'+str(len(sub_dict)+1)+'\n')
        for feature in HASH_FEATURES:
            f1.write(feature+'\t'+str(HASH_SIZE+1)+'\n')
    with open(dict_dir, 'w') as f2:
        for fid, sub_dict in rename_ids.items():
            f2.write(fid+'\t'+str(len(sub_dict)+1)+'\n')
            for key, value in sub_dict.items():
                f2.write('\t'+str(key)+'\t'+str(value)+'\n')


def load_data(tsv_file):
    print('loading data:{}'.format(tsv_file))
    skip_header = True
    data = []
    cols = [0, 1, 2, 3, 4, 7, 13, 14, 15, 16, 17, 18, 19, 20, 21]
    with gzip.open(tsv_file, 'rt') as f:
        for line in f:
            if skip_header:
                skip_header = False
                continue
            row = re.split('\t', line.strip())
            data.append([int(row[x]) for x in cols])
    return data


def tsv_2_tfrecord(tsv_file, data_dir, train_tfrecord,
                   valid_tfrecord, test_tfrecord, voc_dir, dict_dir):
    data = load_data(tsv_file)
    all_stats = None
    if tf.flags.FLAGS.with_event_feature:
        all_stats = load_all_stats(
            tf.flags.FLAGS.input_dir + '/' +
            tf.flags.FLAGS.stats_dir + '/*.csv')

    batch_index = 0
    total_real_conv, total_shorter_real_conv = 0, 0
    for i in range(min(tf.flags.FLAGS.num_datasets,
                       30 - tf.flags.FLAGS.train_day)):
        index = batch_index
        cur_data_dir = os.path.join(data_dir,
                                    str(tf.flags.FLAGS.train_day)+'_'+str(i))
        if not os.path.exists(cur_data_dir):
            os.makedirs(cur_data_dir)
        rename_ids = {field_id: {} for field_id in DICT_FEATURES}

        if not tf.flags.FLAGS.dry_run:
            if tf.flags.FLAGS.gzip:
                options = tf.python_io.TFRecordOptions(
                    tf.python_io.TFRecordCompressionType.GZIP)
            else:
                options = tf.python_io.TFRecordOptions(
                    tf.python_io.TFRecordCompressionType.NONE)
            train_writer = tf.python_io.TFRecordWriter(
                os.path.join(cur_data_dir, train_tfrecord), options=options)
            valid_writer = tf.python_io.TFRecordWriter(
                os.path.join(cur_data_dir, valid_tfrecord), options=options)
            real_test_writer = tf.python_io.TFRecordWriter(
                os.path.join(cur_data_dir, 'real_'+test_tfrecord),
                options=options)
            shorter_real_test_writer = tf.python_io.TFRecordWriter(
                os.path.join(cur_data_dir, 'shorter_real_'+test_tfrecord),
                options=options)
        else:
            train_writer = None
            valid_writer = None
            real_test_writer = None
            shorter_real_test_writer = None

        start_imp = i*DAY_IN_SECONDS
        train_end_imp = (i+tf.flags.FLAGS.train_day)*DAY_IN_SECONDS
        valid_end_imp = int(
            (i + tf.flags.FLAGS.train_day +
             tf.flags.FLAGS.valid_test_day * tf.flags.FLAGS.valid_pct) *
            DAY_IN_SECONDS)
        end_time = (
            i + tf.flags.FLAGS.train_day + tf.flags.FLAGS.valid_test_day) * \
            DAY_IN_SECONDS

        batch_index, index, real_conv, orig_real_conv = write_lines_to_tfrecord(
            data, index, rename_ids, tf.flags.FLAGS.prebatch, train_writer,
            all_stats, start_imp, train_end_imp, valid_end_imp, True)
        train_real_conv_ratio = real_conv * 1.0 / max(orig_real_conv, 1)
        _, index, real_conv, orig_real_conv = write_lines_to_tfrecord(
            data, index, rename_ids, tf.flags.FLAGS.prebatch, valid_writer,
            all_stats, train_end_imp, valid_end_imp, valid_end_imp, False)
        valid_real_conv_ratio = real_conv * 1.0 / max(orig_real_conv, 1)
        _, _, real_conv, _ = write_lines_to_tfrecord(
            data, index, rename_ids, tf.flags.FLAGS.prebatch, real_test_writer,
            all_stats, valid_end_imp, end_time, sys.maxsize, False)
        _, index, shorter_real_conv, _ = write_lines_to_tfrecord(
            data, index, rename_ids, tf.flags.FLAGS.prebatch,
            shorter_real_test_writer, all_stats, valid_end_imp, end_time,
            tf.flags.FLAGS.train_day*DAY_IN_SECONDS, False, False)

        train_writer.close()
        valid_writer.close()
        real_test_writer.close()
        shorter_real_test_writer.close()
        total_real_conv += real_conv
        total_shorter_real_conv += shorter_real_conv
        print('next_batch_index: {}, shorter_real_conv/real_conv: {} '
              'train_real_conv_ratio:{}, valid_real_conv_ratio: {}'.format(
                  batch_index, shorter_real_conv * 1.0 / max(1, real_conv),
                  train_real_conv_ratio, valid_real_conv_ratio))
        if not tf.flags.FLAGS.dry_run:
            dump_dict(rename_ids, os.path.join(cur_data_dir, voc_dir),
                      os.path.join(cur_data_dir, dict_dir))
    print('total_shorter_real_conv/total_real_conv: ')
    print(total_shorter_real_conv * 1.0 / max(1, total_real_conv))


def check_data():
    BaseBiddingCVRModel.voc_emb_size = BaseBiddingCVRModel.load_voc_summary()
    # TODO(Yu): generate list txt
    data_iterator = BaseBiddingCVRModel.tfrecord_pipeline(
        os.path.join(
            tf.flags.FLAGS.output_dir,
            str(tf.flags.FLAGS.train_day)+'_'+str('0'),
            'train.list'),
        tf.flags.FLAGS.batch_size,
        tf.flags.FLAGS.prebatch, 1).make_initializable_iterator()
    features = data_iterator.get_next()
    features, labels = BaseBiddingCVRModel.reshape_input(features)

    with tf.Session() as sess:
        sess.run([data_iterator.initializer,
                  tf.global_variables_initializer(),
                  tf.local_variables_initializer()])
        try:
            # while True:
            _features, _labels = sess.run([features, labels])
        except tf.errors.OutOfRangeError:
            tf.logging.warn('Done reading data')
        for f in _features.keys():
            print('key '+f+': '),
            print(_features[f])


def main():
    if tf.flags.FLAGS.with_event_feature:
        FEATURES.extend(DENSE_FEATURES)
    tsv_2_tfrecord(
        os.path.join(tf.flags.FLAGS.input_dir, tf.flags.FLAGS.input_tsv),
        tf.flags.FLAGS.output_dir,
        tf.flags.FLAGS.train_tfrecord,
        tf.flags.FLAGS.valid_tfrecord,
        tf.flags.FLAGS.test_tfrecord,
        tf.flags.FLAGS.sub_voc_dir,
        tf.flags.FLAGS.sub_dict_dir)
    if tf.flags.FLAGS.data_check:
        check_data()


if __name__ == "__main__":
    if tf.flags.FLAGS.profile:
        pr = cProfile.Profile()
        pr.enable()
    try:
        main()
    except KeyboardInterrupt:
        pass
    if tf.flags.FLAGS.profile:
        pr.disable()
        s = StringIO.StringIO()
        sortby = 'cumulative'
        ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
        ps.print_stats()
        print(s.getvalue())
