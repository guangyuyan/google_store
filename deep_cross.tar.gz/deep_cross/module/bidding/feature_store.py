#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Feature definition
"""

import tensorflow as tf


tf.flags.DEFINE_bool('with_event_feature', False, 'build event features')

HASH_SIZE = 65536

DICT_FEATURES = [
    'campaign',
    'cat1',
    'cat2',
    'cat3',
    'cat4',
    'cat5',
    'cat6',
    'cat7',
    'cat8',
    'cat9']
HASH_FEATURES = ['uid']
DENSE_FEATURES = ['ctr_stats', 'cvr_stats', 'dense']
DENSE_SIZE = 72
STATS_SIZE = 36
FEATURES = DICT_FEATURES+HASH_FEATURES
