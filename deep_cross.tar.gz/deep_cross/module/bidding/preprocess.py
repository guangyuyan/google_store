#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Preprocess csv file and create feature id list
"""

import cProfile
import pstats
import StringIO
import re
import os
import sys
import tensorflow as tf

tf.flags.DEFINE_string('data_dir', '/ssd/users/xyyu/data/bidding', 'working directory')
tf.flags.DEFINE_string(
    'input_tsv',
    'criteo_attribution_dataset.tsv',
    'input data file')
tf.flags.DEFINE_string(
    'train_tfrecord',
    'bidding_train.tf',
    'output tfrecord training file')
tf.flags.DEFINE_string(
    'valid_tfrecord',
    'bidding_valid.tf',
    'output tfrecord training file')
tf.flags.DEFINE_string(
    'test_tfrecord',
    'bidding_test.tf',
    'output tfrecord testing file')
tf.flags.DEFINE_string(
    'sub_voc_dir',
    'voc_size.txt',
    'voc size of features')
tf.flags.DEFINE_string(
    'sub_dict_dir',
    'feature_dict.txt',
    'features dictionary')
tf.flags.DEFINE_bool('data_check', False, 'Check the data format')


from .feature_store import FEATURES, DICT_FEATURES, HASH_FEATURES, HASH_SIZE
from .model_v0 import BaseBiddingCVRModel


def _int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=value))


def _float_feature(value):
    return tf.train.Feature(float_list=tf.train.FloatList(value=value))


def load_dict(load_dir):
    rename_ids = {field_id: {} for field_id in DICT_FEATURES}
    with open(load_dir, 'r') as f:
        while True:
            line = f.readline()
            if ('' == line):
                break
            fid, size = line.split("\t")
            for _ in range(int(size)):
                line = f.readline()
                key, value = tuple(filter(None, line.split("\t")))
                rename_ids[fid][key] = int(value)
    return rename_ids


def lookup_dict(rename_ids, key, cat_id):
    try:
        if cat_id not in rename_ids[key]:
            return 0
        else:
            return rename_ids[key][cat_id]
    except KeyError:
        print('I got a KeyError - "%s"' % (field_id))


def insert_dict(rename_ids, key, cat_id):
    try:
        if cat_id not in rename_ids[key]:
            new_cat_id  = len(rename_ids[key])+1
            rename_ids[key][cat_id] = new_cat_id
            return new_cat_id
        else:
            return rename_ids[key][cat_id]
    except KeyError:
        print('I got a KeyError - "%s"' % (field_id))


def write_line_to_tfrecord(rename_ids, lines, writer, train=False):
    raw_features = {field_id: [] for field_id in FEATURES}
    click_list = []
    conv_list = []

    for index in range(len(lines)):
        feature_list = re.split('\t', lines[index])
        click_list.append(int(feature_list[7]))
        conv_list.append(int(feature_list[3]))
        if train:
            new_campaign = insert_dict(rename_ids, 'campaign', int(feature_list[2]))
        else:
            new_campaign = lookup_dict(rename_ids, 'campaign', int(feature_list[2]))
        raw_features['campaign'].append(new_campaign)
        raw_features['uid'].append(int(feature_list[1])%HASH_SIZE+1)
        
        for i in range(1, 10):
            if train:
                new_cat = insert_dict(rename_ids, 'cat'+str(i), int(feature_list[12+i]))
            else:
                new_cat = lookup_dict(rename_ids, 'cat'+str(i), int(feature_list[12+i]))
            raw_features['cat'+str(i)].append(new_cat)
    features = {
        'click': _int64_feature(click_list),
        'conv': _int64_feature(conv_list)}

    for key, value in raw_features.items():
        features.update({
            key: _int64_feature(value)
            })
    example = tf.train.Example(
        features=tf.train.Features(
            feature=features))
    writer.write(example.SerializeToString())


def dump_dict(rename_ids, voc_dir, dict_dir):
    with open(voc_dir, 'w') as f1:
        for fid, sub_dict in rename_ids.items():
            f1.write(fid+'\t'+str(len(sub_dict)+1)+'\n')
        for feature in HASH_FEATURES:
            f1.write(feature+'\t'+str(HASH_SIZE+1)+'\n')
    with open(dict_dir, 'w') as f2:
        for fid, sub_dict in rename_ids.items():
            f2.write(fid+'\t'+str(len(sub_dict)+1)+'\n')
            for key, value in sub_dict.items():
                f2.write('\t'+str(key)+'\t'+str(value)+'\n')


def tsv_2_tfrecord(tsv_file, train_tfrecord, valid_tfrecord, test_tfrecord, voc_dir, dict_dir):
    rename_ids = {field_id: {} for field_id in DICT_FEATURES}
    train_writer = tf.python_io.TFRecordWriter(train_tfrecord)
    valid_writer = tf.python_io.TFRecordWriter(valid_tfrecord)
    test_writer = tf.python_io.TFRecordWriter(test_tfrecord)
    reader = open(tsv_file, 'r')
    reader.readline()
    i = 0
    try:
        count = 0
        mylines = []
        for line in reader:
            if count < tf.flags.FLAGS.prebatch:
                mylines.append(line)
                count += 1
                continue
            if i < 40000:
                write_line_to_tfrecord(rename_ids, mylines, train_writer, True)
            elif i < 60000:
                write_line_to_tfrecord(rename_ids, mylines, valid_writer, False)
            else:
                write_line_to_tfrecord(rename_ids, mylines, test_writer, False)
            count = 0
            mylines = []
            if(i % 5000 == 0):
                print(i)
            i += 1
    except EOFError:
        print("Finished!")
    reader.close()
    dump_dict(rename_ids, voc_dir, dict_dir)



def check_data():
    BaseBiddingCVRModel.voc_emb_size = BaseBiddingCVRModel.load_voc_summary()
    data_iterator = BaseBiddingCVRModel.tfrecord_pipeline(
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.train_tfrecord),
        tf.flags.FLAGS.batch_size,
        tf.flags.FLAGS.prebatch,
        1)
    features = data_iterator.get_next()
    features, labels = BaseBiddingCVRModel.reshape_input(features)

    with tf.Session() as sess:
        sess.run([data_iterator.initializer,
                  tf.global_variables_initializer(),
                  tf.local_variables_initializer()])
        try:
            # while True:
            _features, _labels = sess.run([features, labels])
        except tf.errors.OutOfRangeError:
            tf.logging.warn('Done reading data')
        for f in _features.keys():
            print('key '+f+': '),
            print(_features[f])


def main():
    tsv_2_tfrecord(
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.input_tsv),
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.train_tfrecord),
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.valid_tfrecord),
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.test_tfrecord),
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.sub_voc_dir),
        os.path.join(tf.flags.FLAGS.data_dir, tf.flags.FLAGS.sub_dict_dir))
    if tf.flags.FLAGS.data_check:
        check_data()


if __name__ == "__main__":
    pr = cProfile.Profile()
    # pr.enable()
    main()
    # pr.disable()
    # s = StringIO.StringIO()
    # sortby = 'cumulative'
    # ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
    # ps.print_stats()
    # print s.getvalue()
