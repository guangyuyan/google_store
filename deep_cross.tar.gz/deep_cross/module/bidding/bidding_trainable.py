#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
"""

from ..base.cvr_trainable import BaseCVRTrainable
from .feature_store import FEATURES, DENSE_FEATURES, DENSE_SIZE, STATS_SIZE
import tensorflow as tf


class BiddingTrainable(BaseCVRTrainable, object):

    def __init__(self, flags):
        super(BiddingTrainable, self).__init__(flags)
        if self.flags.with_event_feature:
            FEATURES.extend(DENSE_FEATURES)

    @classmethod
    def parser(cls, record):
        prebatch = tf.flags.FLAGS.prebatch
        feature_map = {
            'click': tf.FixedLenFeature([prebatch], tf.int64),
            'conv': tf.FixedLenFeature([prebatch], tf.int64),
            'delay_or_elapse': tf.FixedLenFeature([prebatch], tf.float32),
        }
        '''
            delay_or_elapse in hours
            when conv is true, delay = time_conv - time_imp
            when conv is false, elapse = time_cur - time_imp
            it can be availble in train/valid/test tfrecords,
            but not in serving requests
        '''
        for feature in FEATURES:
            if feature == 'dense':
                feature_map[feature] = tf.FixedLenFeature(
                    [prebatch * DENSE_SIZE], tf.float32)
            elif feature in ('ctr_stats', 'cvr_stats'):
                feature_map[feature] = tf.FixedLenFeature(
                    [prebatch * STATS_SIZE], tf.float32)
            else:
                feature_map[feature] = tf.FixedLenFeature([prebatch],
                                                            tf.int64)

        features = tf.parse_single_example(record, features=feature_map)
        return features
