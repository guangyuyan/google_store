#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build model
"""


from . import model_v1, model_v2, model_v3


def build_model(flags):
    if flags.model == 'v1':
        model = model_v1.BiddingCVRModel(flags)
    elif flags.model == 'v2':
        model = model_v2.BiddingCVRModelMixtureHistory(flags)
    elif flags.model == 'v3':
        model = model_v3.BiddingCVRModelMixtureHistory2(flags)
    else:
        raise ValueError('--model {} was not found.'.format(flags.model))
    return model
