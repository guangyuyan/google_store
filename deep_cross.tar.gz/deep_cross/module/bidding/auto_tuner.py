#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
auto tuner for hyperparameter searching
"""

from datetime import datetime
import tensorflow as tf
from hyperopt import STATUS_OK, Trials
from hyperopt import hp
import hyperopt as hopt
import copy
import numpy as np
from .build_model import build_model


class Config:
    spaces = [
        {'learning_rate': hp.choice(
             "x_learning_rate", [0.00005, 0.0001, 0.0002]),
         'deep_layers': hp.choice("x_deep_layers", ['512,256', '512,512']),
         'cross_layers': hp.choice("x_cross_layers", [2, 3]),
         'with_conv_delay': hp.choice("x_with_conv_delay", [True, False]),
         'weibull_conv_delay': hp.choice(
             "x_weibull_conv_delay", [True, False]),
         'ctr_loss_weight': hp.choice(
             "x_ctr_loss_weight", [1, 0.7, 0.3, 0]),
         'HOPT_ITERATION': 60}]


def cost(space):
    tf.reset_default_graph()
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    flags = tf.app.flags.FLAGS
    flags.deep_layers = space['deep_layers']
    flags.cross_layers = space['cross_layers']
    flags.learning_rate = space['learning_rate']
    flags.with_conv_delay = space['with_conv_delay']
    flags.weibull_conv_delay = space['weibull_conv_delay']
    flags.ctr_loss_weight = space['ctr_loss_weight']

    cur_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = flags.checkpoint_path.split('/')[0: -1]
    path.append(cur_time)
    flags.checkpoint_path = '/'.join(path)
    flags.model_path = '/'.join(path)

    path = flags.summaries_dir.split('/')[0: -1]
    path.append(cur_time)
    flags.summaries_dir = '/'.join(path)

    model = build_model(flags)
    model.build()

    tf.logging.warn('     --AT Start current space setting {0}'.format(space))
    with tf.Session(config=sess_config) as session:
        session.run([tf.global_variables_initializer(),
                     tf.local_variables_initializer(),
                     tf.tables_initializer(),
                     model.initializer()])
        roc = model.train(session)

    tf.logging.warn('     --AT End current space setting {0} roc {1}'.format(space, roc))
    return {'loss': -float(roc), 'status': STATUS_OK}


best_last_stage = {}
for i, space in enumerate(Config.spaces):
    current_space = copy.deepcopy(best_last_stage)
    for s in space:
        current_space[s] = space[s]
    try:
        hopt_iteration = current_space['HOPT_ITERATION']
        current_space.pop('HOPT_ITERATION', None)
    except BaseException:
        tf.logging.error('===AT=== Please config HOPT_ITERATION in each space defination.')
        raise

    tf.logging.warn('===AT=== Round {0} Config Space {1}'
                    .format(i, current_space))
    trials = Trials()
    rt = hopt.fmin(fn=cost,
                   space=current_space,
                   algo=hopt.tpe.suggest,
                   max_evals=hopt_iteration,
                   trials=trials)
    best_value = hopt.space_eval(space, rt)
    for s in best_value:
        best_last_stage[s] = best_value[s]
    losses = np.asarray(trials.losses(), dtype=float)
    tf.logging.warn('===AT=== Tuner found best config {0} in round {1} with best loss {2}'
                    .format(best_last_stage, i, losses[np.argmin(losses)]))

