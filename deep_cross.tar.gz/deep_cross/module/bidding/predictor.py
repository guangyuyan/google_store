#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
predictor
"""

import tensorflow as tf
from ..base.predictor import predict
from .bidding_trainable import BiddingTrainable

def main(unused=None):
    flags = tf.app.flags.FLAGS
    model = BiddingTrainable(flags)
    model.load_graph_from_file()
    predict(model)

if __name__ == '__main__':
    tf.app.run(main)
