#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V3: https://d.cloudbrain.cc:10443/developers/deep_cross/wikis/0924
"""


import tensorflow as tf

from .model_v2 import BiddingCVRModelMixtureHistory


class BiddingCVRModelMixtureHistory2(BiddingCVRModelMixtureHistory):
    def __init__(self, flags):
        super(BiddingCVRModelMixtureHistory2, self).__init__(flags)

    def build_mixture_history(self, dense, history, epsilon=1e-7):
        combined_historical_logits = super(
            BiddingCVRModelMixtureHistory2, self).build_mixture_history(
                dense, history, epsilon)
        another_logit = tf.layers.Dense(1)(dense)
        return tf.concat([combined_historical_logits, another_logit], -1)
