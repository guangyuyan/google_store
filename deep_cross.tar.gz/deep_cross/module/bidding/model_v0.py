#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base CVR model for ALI taobao dataset
"""

from ..base.model_cvr_base import BaseCVRModel
from .bidding_trainable import BiddingTrainable
from .feature_store import FEATURES, DENSE_SIZE, STATS_SIZE
import tensorflow as tf


class BaseBiddingCVRModel(BaseCVRModel, BiddingTrainable):
    voc_emb_size = None

    def __init__(self, flags):
        BaseCVRModel.__init__(self, flags)
        BiddingTrainable.__init__(self, flags)
        self.NUM_POSITIONS = 100
        BaseBiddingCVRModel.voc_emb_size = self.load_voc_summary()

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_file,  batch_size,
                          epochs, shuffle=True):
        return BiddingTrainable.tfrecord_pipeline(tfrecord_file, batch_size,
                                                  epochs, shuffle)

    @classmethod
    def reshape_input(cls, features):
        labels = [tf.reshape(features.pop('click'), [-1, 1]),
                  tf.reshape(features.pop('conv'), [-1, 1])]
        if 'delay_or_elapse' in features:
            labels.append(
                tf.reshape(features.pop('delay_or_elapse'), [-1, 1]))
        for feature in FEATURES:
            if feature == 'dense':
                features[feature] = tf.reshape(features[feature],
                                               [-1, DENSE_SIZE])
            elif feature in ('ctr_stats', 'cvr_stats'):
                features[feature] = tf.reshape(features[feature],
                                               [-1, STATS_SIZE])
            else:
                features[feature] = tf.reshape(features[feature], [-1, 1])
        return features, labels

    @classmethod
    def load_voc_summary(cls):
        voc_emb_size = {}
        with open(tf.flags.FLAGS.voc_dir) as f:
            for line in f:
                content = line.strip().split('\t')
                key, voc_size = content[0], int(content[1])
                emb_size = cls.compute_emb_size(voc_size)
                voc_emb_size[key] = [voc_size, emb_size]
            for key, value in voc_emb_size.items():
                cls.print_emb_info(key, value[0], value[1])
        return voc_emb_size
