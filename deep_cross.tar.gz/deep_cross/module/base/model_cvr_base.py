#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base model to build and train CVR
"""


from .model_dxl import BaseDXLModel

import tensorflow as tf

CTR_PREDICT_LAYER_NAME = "ctr_predict"
CTR_PREDICT_NODE_NAME = CTR_PREDICT_LAYER_NAME + "/Sigmoid"
CVR_PREDICT_LAYER_NAME = "cvr_predict"
CVR_PREDICT_NODE_NAME = CVR_PREDICT_LAYER_NAME + "/Sigmoid"
PREDICT_CLICK = "predict_click"
PREDICT_CONV = "predict_convert"


tf.app.flags.DEFINE_bool('cvr_on_click_only', False,
                         'Only data whose click label is True')
tf.app.flags.DEFINE_bool('weibull_conv_delay', False, 'otherwise, assume exp')
tf.app.flags.DEFINE_bool('with_conv_delay', False, 'train with conv_delay')
tf.app.flags.DEFINE_float('exp_clip', 20.0, 'clip value before tf.exp')
tf.app.flags.DEFINE_bool('different_ctr_cvr_embedding', False,
                         'different embedding for ctr and cvr model')
tf.app.flags.DEFINE_bool('separated_x', False,
                         'separated network for conv delay')
tf.app.flags.DEFINE_bool('cvr_signature_only', False,
        'set saved model default signature to cvr prediction only')


class BaseCVRModel(BaseDXLModel):

    def __init__(self, flags):
        super(BaseCVRModel, self).__init__(flags)

    def build_network(self, features, embedding_suffix=''):
        with tf.device('/gpu:0'):
            """
            sharing inputs for ctr and cvr, so kind of transfer learning
            """
            inputs = self.build_features(features, embedding_suffix)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            with tf.name_scope('ctr'):
                ctr_out = self.build_sub_network(
                    inputs, hidden=hidden, num_layers=self.flags.cross_layers)
            with tf.name_scope('cvr'):
                if self.flags.different_ctr_cvr_embedding:
                    inputs = self.build_features(features,
                                                 embedding_suffix + 'cvr')
                cvr_out = self.build_sub_network(
                    inputs, hidden=hidden, num_layers=self.flags.cross_layers)
            return tf.concat(ctr_out, -1), tf.concat(cvr_out, -1)

    def build_sub_network(self, inputs, hidden, num_layers):
        deep_out = self.build_deep(inputs, hidden=hidden)
        cross_out = self.build_cross(
                    inputs, num_layers=self.flags.cross_layers)
        return deep_out, cross_out

    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)

    def build_cross(self, raw_inputs, num_layers=3):
        return self.cross_net(raw_inputs, num_layers,
                              use_bias=self.flags.cross_bias,
                              sparse=self.flags.sparse_cross)

    def build_predictions(self, v, predict_layer_name):
        # TODO(xjfan): Find a way to explicitly define the output node name.
        # Currently it relays on TF appending /Sigmoid after predict_layer_name
        pr = tf.layers.Dense(1, activation=tf.nn.sigmoid,
                             name=predict_layer_name)(v)
        if self.flags.ns_rate < 1:
            pr = pr / (pr + tf.divide(tf.subtract(1.0, pr), self.flags.ns_rate))
        return pr

    def build_loss(self, clicks, convs, pr_clicks, pr_convs, x,
                   delay_or_elapse):
        if not self.flags.with_conv_delay or delay_or_elapse is None:
            cvr_loss = tf.losses.log_loss(convs, pr_clicks * pr_convs)
        else:
            cvr_loss = self.build_delayed_loss(
                convs, pr_clicks * pr_convs, x, delay_or_elapse)
        if tf.flags.FLAGS.cvr_on_click_only:
            cvr_loss *= clicks
        return tf.reduce_mean(cvr_loss + self.flags.ctr_loss_weight *
                              tf.losses.log_loss(clicks, pr_clicks))

    def build_delayed_hazard(self, x):
        clip = self.flags.exp_clip
        return tf.exp(tf.clip_by_value(tf.layers.Dense(1)(x), -clip, clip))

    def build_delayed_loss(self, labels, predictions, x,
                           delay_or_elapse, epsilon=1e-7):
        hazard = self.build_delayed_hazard(x)
        if self.flags.weibull_conv_delay:
            weibull_p = tf.get_variable('weibull_p', shape=[1],
                                        initializer=tf.ones_initializer)
            p1 = tf.pow(hazard * delay_or_elapse, weibull_p - 1)
            p2 = tf.pow(hazard * delay_or_elapse, weibull_p)
        else:
            weibull_p = tf.constant(1.0)
            p1 = tf.constant(1.0)
            p2 = hazard * delay_or_elapse
        positive_logloss = tf.log(predictions + epsilon) + \
            tf.log(weibull_p * hazard * p1 + epsilon) - p2
        negative_logloss = tf.log(1 - predictions + epsilon +
                                  predictions * tf.exp(-p2))
        return -labels * positive_logloss - (1 - labels) * negative_logloss

    def build_eval_metric_ops(self, clicks, convs, pr_clicks, pr_convs, loss):
        pr_convs_perfect_ctr = pr_convs * clicks
        pr_convs *= pr_clicks
        with tf.device('/cpu:0'):
            loss_stream = tf.metrics.mean(loss)
            ctr_roc = tf.metrics.auc(clicks, pr_clicks, curve='ROC')
            ctr_pr = tf.metrics.auc(clicks, pr_clicks, curve='PR',
                                    summation_method='careful_interpolation')
            pr_clicks_stream = tf.metrics.mean(pr_clicks)
            clicks_stream = tf.metrics.mean(clicks)

            ctcvr_roc = tf.metrics.auc(convs, pr_convs, curve='ROC')
            ctcvr_pr = tf.metrics.auc(convs, pr_convs, curve='PR',
                                      summation_method='careful_interpolation')
            pr_convs_stream = tf.metrics.mean(pr_convs)
            convs_stream = tf.metrics.mean(convs)

            cvr_roc = tf.metrics.auc(convs, pr_convs_perfect_ctr, curve='ROC',
                                     weights=clicks)
            cvr_pr = tf.metrics.auc(convs, pr_convs_perfect_ctr, curve='PR',
                                    weights=clicks)
            pr_convs_perfect_ctr_stream = tf.metrics.mean(pr_convs_perfect_ctr)

            return {
                'loss': loss,
                'stream_loss': loss_stream[1],
                'ctr_roc': ctr_roc[1],
                'ctr_pr': ctr_pr[1],
                'ctr_calibration': pr_clicks_stream[1] / clicks_stream[1],
                'ctcvr_roc': ctcvr_roc[1],
                'ctcvr_pr': ctcvr_pr[1],
                'ctcvr_calibration': pr_convs_stream[1] / convs_stream[1],
                'cvr_roc': cvr_roc[1],
                'cvr_pr': cvr_pr[1],
                'cvr_calibration': pr_convs_perfect_ctr_stream[1] / convs_stream[1]
            }

    def build_cost_summary(self):
        tf.summary.scalar('cost/stream_loss',
                          self.costs['stream_loss'])
        tf.summary.scalar('cost/loss', self.costs['loss'])
        tf.summary.scalar('cost/ctr_roc', self.costs['ctr_roc'])
        tf.summary.scalar('cost/ctr_pr', self.costs['ctr_pr'])
        tf.summary.scalar('cost/ctr_calibration',
                          self.costs['ctr_calibration'])
        tf.summary.scalar('cost/ctcvr_roc',
                          self.costs['ctcvr_roc'])
        tf.summary.scalar('cost/ctcvr_pr',
                          self.costs['ctcvr_pr'])
        tf.summary.scalar('cost/ctcvr_calibration',
                          self.costs['ctcvr_calibration'])
        tf.summary.scalar('cost/cvr_roc',
                          self.costs['cvr_roc'])
        tf.summary.scalar('cost/cvr_pr',
                          self.costs['cvr_pr'])
        tf.summary.scalar('cost/cvr_calibration',
                          self.costs['cvr_calibration'])

    def set_prediction_signature(self, model_inputs, model_outputs):
        # model_inputs and model_outputs are tensors_info dict
        ctcvr_signature = (
            tf.saved_model.signature_def_utils.build_signature_def(
                inputs=model_inputs,
                outputs=model_outputs,
                method_name=tf.saved_model
                              .signature_constants
                              .PREDICT_METHOD_NAME))
        cvr_signature = (
            tf.saved_model.signature_def_utils.build_signature_def(
                inputs=model_inputs,
                outputs={PREDICT_CONV: model_outputs[PREDICT_CONV]},
                method_name=tf.saved_model
                              .signature_constants
                              .PREDICT_METHOD_NAME))

        if self.flags.cvr_signature_only:
            cvr_key = tf.saved_model \
                        .signature_constants \
                        .DEFAULT_SERVING_SIGNATURE_DEF_KEY
            ctcvr_key = 'ctcvr_signature'
        else:
            cvr_key = 'cvr_signature'
            ctcvr_key = tf.saved_model \
                          .signature_constants \
                          .DEFAULT_SERVING_SIGNATURE_DEF_KEY
        self.signature_def_map = {cvr_key: cvr_signature,
                                  ctcvr_key: ctcvr_signature}

    def build(self):
        features, labels = self.build_input()
        self.reshape_sparse2dense(features)
        self.model_inputs = self.build_model_tensors_info(features)
        self.features = features
        self.reshape_dense2sparse(features)
        self.labels = labels
        delay_or_elapse = labels.pop() if len(labels) > 2 else None
        clicks, convs = labels[0], labels[1]

        ctr_v, cvr_v = self.build_network(features)

        with tf.device('/gpu:0'):
            pr_clicks = self.build_predictions(ctr_v, CTR_PREDICT_LAYER_NAME)
            pr_convs = self.build_predictions(cvr_v, CVR_PREDICT_LAYER_NAME)
            self.model_outputs = self.build_model_tensors_info(
                {PREDICT_CLICK: pr_clicks, PREDICT_CONV: pr_convs})
            self.set_prediction_signature(
                self.model_inputs, self.model_outputs)
            self.preds = [pr_clicks, pr_convs]
            clicks = tf.cast(clicks, tf.float32)
            convs = tf.cast(convs, tf.float32)
            if self.flags.separated_x:
                x = tf.concat(self.build_network(features, '-delay'), -1)
            else:
                x = tf.concat([ctr_v, cvr_v], -1)
            loss = self.build_loss(clicks, convs, pr_clicks, pr_convs, x,
                                   delay_or_elapse)
            self.costs = self.build_eval_metric_ops(
                clicks, convs, pr_clicks, pr_convs, loss)
            self.build_cost_summary()
            self.train_op = self.build_train_op(loss)
