#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <wangqh@>
#
# Distributed under terms of the CloudBrain license.

"""
use to plot ctr and cvr calibration
python3 -m module.base.plot_all_calibration -t {pred/normal} -p {input_data_file} -o {output_file_dir} -s {sep}
notice:
the input file format is like , ctr_label1\tctr_pred1\ncvr_label1\tcvr_pred1
the output filename will be set as the pic title
"""

from .plot_calibration import plot_calibration_buckets
import argparse
import numpy as np


def main(args):
    cvr_labels = []
    cvr_preds = []
    ctr_labels = []
    ctr_preds = []
    labels = []
    preds = []
    if args.mode == 'pred':
        with open(args.predictions) as f:
            is_ctr = True
            for line in f:
                if is_ctr:
                    is_ctr = False
                    if args.sep:
                        label, pred = line.split(args.sep)
                    else:
                        label, pred = line.split()
                    ctr_labels.append(float(label))
                    ctr_preds.append(float(pred))
                    continue
                is_ctr = True
                if args.sep:
                    label, pred = line.split(args.sep)
                else:
                    label, pred = line.split()
                cvr_labels.append(float(label))
                cvr_preds.append(float(pred))

        print('start generating filtered cvr data')
        filtered_cvr_labels = [cvr_labels[i] for i, item in enumerate(ctr_labels) if
                               item != 0]  # cvr_labels[ctr_labels != 0]
        filtered_cvr_preds = [cvr_preds[i] for i, item in enumerate(ctr_labels) if
                              item != 0]  # cvr_preds[ctr_labels != 0]
        print('start generating ctcvr')
        ctcvr_preds = np.multiply(np.array(ctr_preds),np.array(cvr_preds)).tolist() #[x * y for x in ctr_preds for y in cvr_preds]

        print('ploting ctr')
        plot_calibration_buckets(ctr_labels, ctr_preds, args, 'ctr')
        print('ploting filtered_cvr')
        plot_calibration_buckets(filtered_cvr_labels, filtered_cvr_preds, args, 'filtered_cvr')
        print('ploting ctcvr')
        plot_calibration_buckets(cvr_labels, ctcvr_preds, args, 'ctcvr')
        print('finished')
    else:
        with open(args.predictions) as f:
            for line in f:
                if args.sep:
                    label, pred = line.split(args.sep)
                else:
                    label, pred = line.split()
                labels.append(float(label))
                preds.append(float(pred))
        plot_calibration_buckets(labels, preds, args)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--predictions', type=str, required=True)
    parser.add_argument('-o', '--output_dir', type=str, required=True)
    parser.add_argument('-n', '--name', type=str, help='title name prefix', default='')
    parser.add_argument('-s', '--sep', type=str, default='')
    parser.add_argument('-t', '--mode', type=str, required=True, choices=['pred', 'normal'])
    parser.add_argument('-m', '--min_positives', type=int, default=10)
    parser.add_argument('-w', '--bucket_width', type=int, default=20000)
    main(parser.parse_args())
