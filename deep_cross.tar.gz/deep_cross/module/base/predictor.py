#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
trainer
CUDA_VISIBLE_DEVICES=0 python predictor.py --model=v1 --deep_layers=2048,1024,512,256
--cross_layers=5 --valid_data /data3/liuyazhou/data/tfrecord
--prebatch 256 --batch_size 4 --model_dir ./outputs/ --model_prefix v1_best
"""


import tensorflow as tf
import os
# import threading

tf.app.flags.DEFINE_string('model_dir', None, 'model file directory')
tf.app.flags.DEFINE_string('model_prefix', None, 'model file prefix')
tf.app.flags.DEFINE_string('predictions', '', 'model output and labels')
tf.app.flags.DEFINE_bool('predict_summary', False, 'write summary in predictor')
tf.app.flags.DEFINE_bool('xla', False, 'enable xla')


def predict(model):
    flags = tf.app.flags.FLAGS
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True
    if flags.xla:
        sess_config.graph_options.optimizer_options.global_jit_level =\
            tf.OptimizerOptions.ON_1

    # coord = tf.train.Coordinator()
    if flags.quantize:
        tf.contrib.quantize.experimental_create_eval_graph()
    model_prefix = os.path.join(flags.model_dir, '%s' % flags.model_prefix)
    with tf.Session(config=sess_config) as session:
        session.run([tf.global_variables_initializer(),
                     tf.tables_initializer()])
        saver = tf.train.Saver()
        saver.restore(session, model_prefix)
        if hasattr(model, 'iv_emb_init'):
            model.iv_emb_init(session)
        res = model.predict(session)
        if flags.predictions:
            with open(flags.predictions, 'w') as fout:
                fout.write(
                    '\n'.join(['{}\t{}'.format(l, p) for l, p in res]))
        tf.train.write_graph(session.graph_def,
                             flags.model_dir,
                             flags.model_prefix + "_infer.pbtxt")
        saver.save(session, model_prefix + "_infer")

        # threads = []
        # for i in range(4):
        #     t = threading.Thread(target=model.train, args=(session, ))
        #     t.start()
        #     threads.append(t)
        # coord.join(threads)
