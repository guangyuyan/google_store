#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.


import tensorflow as tf

tf.app.flags.DEFINE_integer("print_steps", 1, "print steps for data_reader")
tf.app.flags.DEFINE_bool("cal_stats", True, "calculate data statics")
tf.app.flags.DEFINE_string("data_stats_file", "data_stats.txt",
                           "data stats result file")


def write_stats(features_stats, data_stats_file):
    with open(data_stats_file, 'w') as f:
        f.write("mean\tmax\tmin\tname\n")
        for key, value in sorted(features_stats.items()):
            if len(value[0]) <= 1:
                f.write("{:.4f}\t{:.2f}\t{:.2f}\t{}\n".format(
                    value[0][0], value[1][0], value[2][0], key))
            else:
                for i in range(len(value[0])):
                    f.write("{:.4f}\t{:.2f}\t{:.2f}\t{}\n".format(
                        value[0][i], value[1][i],
                        value[2][i], '{}_{}'.format(key, i)))
        tf.logging.warn("Data statistics wrote in {}".format(data_stats_file))


def data_reader(build_model):
    flags = tf.app.flags.FLAGS
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    model = build_model(flags)
    model.build()
    with tf.Session(config=sess_config) as session:
        features_stats = model.read_data(session)
    if flags.cal_stats:
        write_stats(features_stats, flags.data_stats_file)
