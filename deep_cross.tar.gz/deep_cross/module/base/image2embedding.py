#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Convert images to embeddings
"""


import argparse
import cv2
import numpy as np


def main(args):
    with open(args.list_file) as f:
        image_paths = f.read().splitlines()
        data = [cv2.resize(cv2.imread(img, 3), (240, 180))
                for img in image_paths]
        data = np.array([np.array(img) for img in data])
        np.savez_compressed(args.output_npz,
                            img=data.flatten().reshape(len(image_paths), -1))
        loaded = np.load(args.output_npz + '.npz')['img'].reshape(
            len(image_paths), 180, 240, 3)
        print np.array_equal(loaded, data)
        print data.shape


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-l', '--list_file', type=str, required=True)
    parser.add_argument('-o', '--output_npz', type=str, required=True)
    main(parser.parse_args())
