#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""

"""

from .plot_calibration import plot_calibration_buckets
import argparse


def main(args):
    labels = []
    preds = []
    with open(args.predictions) as f:
        is_ctr = True
        for line in f:
            if is_ctr:
                is_ctr = False
                continue
            is_ctr = True
            label, pred = line.split()
            labels.append(float(label))
            preds.append(float(pred))
    plot_calibration_buckets(labels, preds, args)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--predictions', type=str, required=True)
    parser.add_argument('-o', '--png', type=str, required=True)
    parser.add_argument('-m', '--min_positives', type=int, default=10)
    parser.add_argument('-w', '--bucket_width', type=int, default=20000)
    main(parser.parse_args())
