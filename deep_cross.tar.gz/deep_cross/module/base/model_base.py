#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base model, just build model, not working without model_train_base.
"""


import time
import tensorflow as tf

from .base_trainable import GLOBAL_STEP
from .usage_model import calc_step_rate
from tensorflow.python.framework import ops
from tensorflow.python.ops import math_ops, control_flow_ops

tf.app.flags.DEFINE_bool("cross_bias", False, "use_bias in cross")
tf.app.flags.DEFINE_bool("lazy_adam", False, 'use LazyAdamOptimizer')
tf.app.flags.DEFINE_bool("res_deep", False, "residual connections for deep")
tf.app.flags.DEFINE_bool("sparse_cross", False, "sparse weights for cross")
tf.app.flags.DEFINE_bool("sparse_deep", False, "sparse weights for deep")
tf.app.flags.DEFINE_enum("summary_mode", "loss", ["loss", "all"],
                         "tf.summary, loss: loss scalar only; "
                         "all: summary for all scalar and histogram.")
# Note: decoupled_weight_decay cannot be used util r1.10
tf.app.flags.DEFINE_float("decoupled_weight_decay", 0,
                          "if > 0, using extend_with_decoupled_weight_decay")
tf.app.flags.DEFINE_float("keep_prob", 1.0, "keep prob for dropout")
tf.app.flags.DEFINE_float("learning_rate", 0.0001, "learning rate")
tf.app.flags.DEFINE_float("ns_rate", 1, 'negative sampling rate, keep prob')
tf.app.flags.DEFINE_integer("bucket_peak", 9, "tanh(9)=0.99999997")
tf.app.flags.DEFINE_integer("cross_layers", 6, "number of cross layers")
tf.app.flags.DEFINE_integer("embedding_size", 50, "embedding size")
tf.app.flags.DEFINE_integer("factor_size", 64, "factor size for mvm")
tf.app.flags.DEFINE_integer("fm_order", 2, "FM net polynomial order")
tf.app.flags.DEFINE_integer("fm_rank", 2,
                            "Number of factors in low-rank appoximation.")
tf.app.flags.DEFINE_integer("hash_bits", 20,
                            "hash bits for categorical features")
tf.app.flags.DEFINE_integer("inference_num_position", 10,
                            "number of positions for inference")
tf.app.flags.DEFINE_integer("lr_decay_step", 0,
                            "learning rate first decay step "
                            "for cosine_decay_restarts")
tf.app.flags.DEFINE_float("lr_schedule_max", 10.0,
                            "upper bound for learning rate update")
tf.app.flags.DEFINE_integer("lr_schedule_update_step", 1,
                            "step is used for smoothing lr scheduling, set to 1 to update lr per every minibatch")
tf.app.flags.DEFINE_integer("lr_schedule_print_step", 100,
                            "print out every N step")
tf.app.flags.DEFINE_integer("num_buckets", 100,
                            "number of buckets on continuous features")
tf.app.flags.DEFINE_string("deep_layers", "1024,1024",
                           "sizes of deep layers, string delimited by comma")
tf.app.flags.DEFINE_string("dense_minmax_dir", "", "dense minmax summary file")
tf.app.flags.DEFINE_string("img_npz", "", "npz for images")
tf.app.flags.DEFINE_string("iv_npz", "", "npz for image vector")
tf.app.flags.DEFINE_string("model", "v1", "model")
tf.app.flags.DEFINE_string("voc_dir", "", "vocabulary size summary dir")


class BaseModel(object):
    def __init__(self, flags):
        # build by subclass' build function
        self.train_op = None
        self.costs = None
        self.global_step = None
        self.is_training = tf.placeholder_with_default(
            False, [], name='training')
        self.iterator_handle = tf.placeholder(tf.string, shape=[])

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_file, batch_size,
                          epochs, shuffle=True):
        raise NotImplementedError("tfrecord_pipeline: not implemented!")

    @classmethod
    def reshape_input(cls, features):
        raise NotImplementedError("reshpae_input: not implemented!")

    @classmethod
    def reshape_sparse2dense(cls, features):
        for key, tensor in features.items():
            if isinstance(tensor, tf.SparseTensor):
                features[key] = {'_SparseIndices': tensor.indices,
                                 '_SparseValues': tensor.values,
                                 '_SparseShape': tensor.dense_shape}

    @classmethod
    def reshape_dense2sparse(cls, features):
        for key, tensor in features.items():
            if isinstance(tensor, dict):
                features[key] = \
                    tf.SparseTensor(indices=tensor['_SparseIndices'],
                                    values=tensor['_SparseValues'],
                                    dense_shape=tensor['_SparseShape'])

    def build_input(self):
        example_dataset = self.tfrecord_pipeline(
            [""], self.flags.batch_size, epochs=self.flags.epochs)
        with tf.device('/cpu:0'):
            self.data_iterator = tf.data.Iterator.from_string_handle(
                self.iterator_handle,
                example_dataset.output_types,
                output_classes=example_dataset.output_classes)
            features = self.data_iterator.get_next()
            return self.reshape_input(features)

    def build_train_op(self, loss):
        self.global_step = tf.Variable(0, name=GLOBAL_STEP, trainable=False)
        with tf.device('/gpu:0'):
            with tf.control_dependencies(
                    tf.get_collection(tf.GraphKeys.UPDATE_OPS)):

                if self.flags.lr_schedule_mode > 0:
                    self.learning_rate = self.learning_rate_schedule(
                        self.flags.learning_rate,
                        self.global_step,
                        self.flags.lr_schedule_mode,
                        self.flags.learning_rate,
                        self.flags.lr_schedule_max,
                        self.flags.stop_steps,
                        self.flags.lr_schedule_update_step)
                    self.build_lr_schedule_sumamry()
                elif self.flags.lr_decay_step < 1:
                    self.learning_rate = ops.convert_to_tensor(self.flags.learning_rate, name="learning_rate")
                else:
                    learning_rate = tf.train.cosine_decay_restarts(
                        self.flags.learning_rate,
                        self.global_step,
                        self.flags.lr_decay_step,
                        alpha=self.flags.learning_rate/10.,
                        name='LearningRate')
                    self.learning_rate = ops.convert_to_tensor(learning_rate, name="learning_rate")

                if not self.flags.lazy_adam:
                    optimizer = tf.train.AdamOptimizer
                else:
                    optimizer = tf.contrib.opt.LazyAdamOptimizer
                if self.flags.decoupled_weight_decay > 0:
                    optimizer = tf.contrib.opt.\
                        extend_with_decoupled_weight_decay(optimizer)(
                            weight_decay=self.flags.decoupled_weight_decay,
                            learning_rate=self.learning_rate)
                else:
                    optimizer = optimizer(learning_rate=self.learning_rate)

                return optimizer.minimize(loss, global_step=self.global_step)

    def build_model_tensors_info(self, tensors):
        tensors_info = {}
        for key, tensor in tensors.items():
            if isinstance(tensor, dict):
                for subkey in tensor:
                    tensors_info[key+subkey] = \
                        tf.saved_model.utils.build_tensor_info(tensor[subkey])
            else:
                tensors_info[key] = \
                    tf.saved_model.utils.build_tensor_info(tensor)
        return tensors_info

    def set_prediction_signature(self, model_inputs, model_outputs):
        # model_inputs and model_outputs are tensors_info dict
        prediction_signature = (
            tf.saved_model.signature_def_utils.build_signature_def(
                inputs=model_inputs,
                outputs=model_outputs,
                method_name=tf.saved_model
                              .signature_constants
                              .PREDICT_METHOD_NAME))
        self.signature_def_map = {
                tf.saved_model
                  .signature_constants
                  .DEFAULT_SERVING_SIGNATURE_DEF_KEY:
                prediction_signature}

    def learning_rate_schedule(self, learning_rate, global_steps, mode, min_lr, max_lr, stop_step, update_step):

        '''
        schedule = 1: linear increase
        schedule = 2: exponential increase

        '''
        learning_rate = ops.convert_to_tensor(learning_rate, name="learning_rate")
        dtype = learning_rate.dtype

        step_rate = calc_step_rate(mode, min_lr, max_lr, stop_step, update_step)
        global_steps = math_ops.cast(global_steps, dtype)

        if mode == 1:
            learning_rate = min_lr + step_rate * (global_steps // update_step)
        elif mode == 2:
            learning_rate = min_lr * (step_rate ** (global_steps // update_step))
        else:
            tf.logging.error('Wrong mode assigned to learning_rate_schedule!!!')

        return learning_rate


    def build_lr_schedule_sumamry(self):
        # currently dumping out all major costs for lr scheduling
        tf.summary.scalar('learning_rate', self.learning_rate)
