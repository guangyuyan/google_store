#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base model to train CVR
"""


from .base_trainable import BaseTrainable
import tensorflow as tf
import time
import numpy as np

CTR_PREDICT_LAYER_NAME = "ctr_predict"
CTR_PREDICT_NODE_NAME = CTR_PREDICT_LAYER_NAME + "/Sigmoid"
CVR_PREDICT_LAYER_NAME = "cvr_predict"
CVR_PREDICT_NODE_NAME = CVR_PREDICT_LAYER_NAME + "/Sigmoid"

tf.app.flags.DEFINE_float('ctr_loss_weight', 1, 'relatve weight of ctr loss')

class BaseCVRTrainable(BaseTrainable):

    def __init__(self, flags):
        super(BaseCVRTrainable, self).__init__(flags)

    def get_costs_keys(self):
        costs_keys = sorted(['loss', 'stream_loss',
                      'ctr_roc', 'ctr_pr', 'ctr_calibration',
                      'ctcvr_roc', 'ctcvr_pr', 'ctcvr_calibration',
                      'cvr_roc', 'cvr_pr', 'cvr_calibration'])
        return costs_keys

    def print_stats(self, string, num_data, duration, cost, base_logloss):
        throughput = num_data / duration
        tf.logging.warn(
            "{} {:10} loss={} norm_loss={} rate={} "
            "ctr_roc={} ctr_pr={} ctr_calibration={} "
            "cvr_roc={} cvr_pr={} cvr_calibration={} "
            "ctcvr_roc={} ctcvr_pr={} ctcvr_calibration={} ".format(
                string,
                num_data,
                cost['stream_loss'],
                cost['stream_loss'] / base_logloss,
                throughput,
                cost['ctr_roc'],
                cost['ctr_pr'],
                cost['ctr_calibration'],
                cost['cvr_roc'],
                cost['cvr_pr'],
                cost['cvr_calibration'],
                cost['ctcvr_roc'],
                cost['ctcvr_pr'],
                cost['ctcvr_calibration']))

    def compute_base_logloss(self, session, data_handle):
        try:
            start_time = time.time()
            total_click = 0
            total_conv = 0
            total = 0
            while True:
                labels = session.run(
                    self.labels, feed_dict={self.iterator_handle: data_handle})
                clicks, convs = labels[0], labels[1]
                """
                Assume the negative label is 0
                """
                total_click += np.count_nonzero(clicks)
                total_conv += np.count_nonzero(convs)
                total += np.size(clicks)
        except tf.errors.OutOfRangeError:
            end_time = time.time()
            total_time = (end_time-start_time)
            ctr = 1.0 * total_click / total
            ctcvr = 1.0 * total_conv / total
            # TODO(byzhang): this base log_loss is not with_conv_delay
            log_loss = -self.flags.ctr_loss_weight * (
                self._mylog(ctr) * ctr + self._mylog(1-ctr) * (1-ctr)) - \
                self._mylog(ctcvr) * ctcvr - self._mylog(1-ctcvr) * (1-ctcvr)
            tf.logging.warn('Done computing base logloss: {} ctr: {} '
                            'ctcvr: {}'.format(log_loss, ctr, ctcvr))
            tf.logging.warn('Total time %.2f s, speed %.2f sample/s,'
                            ' total samples %d.' %
                            (total_time, total / total_time, total))
            return log_loss

    def metric_for_auto_tuner(self, best_cost):
        return best_cost['cvr_roc']
