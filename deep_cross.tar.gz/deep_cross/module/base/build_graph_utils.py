#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
trainer
"""


import tensorflow as tf
from ..base.base_trainable import GRAPH_ITERATOR_HANDLE, GRAPH_TRAIN_FLAG
from ..base.base_trainable import GRAPH_PREDS, GRAPH_TRAIN_OP, GRAPH_COSTS
from ..base.base_trainable import GRAPH_FEATURES, GRAPH_LABELS

tf.flags.DEFINE_string('export_graph', None, 'graph path')


def graph_add_collection(model):
    # For all the placeholder to feed
    tf.add_to_collection(GRAPH_ITERATOR_HANDLE, model.iterator_handle)
    tf.add_to_collection(GRAPH_TRAIN_FLAG, model.is_training)
    # Features for model_base::read_data()
    # Attention, not support sparse tensor, so for sparse features,
    # after reshape_sparse2_dense, should call self.feature = features.copy()
    # if read_data use model build from scratch, pay attention to the change
    # for key in sorted(model.features.keys()):
    #     if isinstance(model.features[key], dict):
    #         for sub_key in sorted(model.features[key].keys()):
    #             tf.add_to_collection(GRAPH_FEATURES,
    #                                  model.features[key][sub_key])
    #     else:
    #         tf.add_to_collection(GRAPH_FEATURES, model.features[key])
    # Labels for model_base::predict()
    for label in model.labels:
        tf.add_to_collection(GRAPH_LABELS, label)
    # For model output nodes
    for pred in model.preds:
        tf.add_to_collection(GRAPH_PREDS, pred)
    tf.add_to_collection(GRAPH_TRAIN_OP, model.train_op)
    for key in sorted(model.costs.keys()):
        tf.add_to_collection(GRAPH_COSTS, model.costs[key])


def build_graph(model):
    graph_add_collection(model)
    meta_graph_def = tf.train.export_meta_graph()
    meta_graph_def.meta_info_def.tags.append(
        tf.saved_model.tag_constants.SERVING)
    for key, tensorinfo in model.signature_def_map.items():
        meta_graph_def.signature_def[key].CopyFrom(tensorinfo)
        # tf.logging.warning(tensorinfo)
    with open(tf.app.flags.FLAGS.export_graph, 'wb+') as graph_file:
        graph_file.write(meta_graph_def.SerializeToString())
        tf.logging.warn("Model graph is saved at {}".format(
            tf.app.flags.FLAGS.export_graph))
