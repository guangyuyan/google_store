#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""

"""

import matplotlib.pyplot as plt
import numpy as np
import os
plt.switch_backend('agg')

def plot_calibration_buckets(labels, preds, args,plot_name):
    if args.name:
        pic_name=args.name+'_'+plot_name
    else:
        pic_name=plot_name
    data = sorted(zip(labels, preds), key=lambda x: x[1])
    buckets = []
    begin = 0
    while begin < len(data):
        end = begin + args.bucket_width
        positives = np.sum(data[begin:end][0])
        while positives < args.min_positives and end < len(data):
            end += 1
            positives += data[end - 1][0]
        buckets.append(tuple(np.mean(data[begin:end], axis=0)))
        begin = end

    # buckets = [tuple(np.mean(data[x:x+bucket_width], axis=0))
    #            for x in range(0, len(data), bucket_width)]
    x, y = zip(*buckets)
    plt.loglog(x, y, 'b.', markersize=2, basex=2, basey=2)
    plt.plot([0, 1], [0, 1], color='k', linewidth=1, linestyle='-')
    plt.grid(True)
    plt.xlabel("{}_true_label".format(pic_name))
    plt.ylabel("{}_pred_label".format(pic_name))
    plt.title(pic_name)
    plt.show()
    plt.savefig(os.path.join(args.output_dir,pic_name)+'.png', dpi=600)
