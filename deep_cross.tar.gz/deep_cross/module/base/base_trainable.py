#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base training model, train/eval functions, support load from graph
"""


import json
import math
import numpy as np
import os
import shutil
import tensorflow as tf
import time
from glob import glob
from multiprocessing.dummy import Process, Queue
from tensorflow.python.client import timeline
from tensorflow.core.protobuf import meta_graph_pb2

LEARNING_RATE = 'learning_rate'
GLOBAL_STEP = 'global_step'
GRAPH_PREDS = 'graph_preds'
GRAPH_TRAIN_OP = 'graph_train_op'
GRAPH_TRAIN_FLAG = 'graph_train_flag'
GRAPH_COSTS = 'graph_costs'
GRAPH_FEATURES = 'graph_features'
GRAPH_LABELS = 'graph_labels'
GRAPH_ITERATOR_HANDLE = 'iterator_handle'

tf.app.flags.DEFINE_bool("concat_last_deep", False,
                         "use the deep output with the self attentive output")
tf.app.flags.DEFINE_bool("do_profile", False, "flag to profile the validation")
tf.app.flags.DEFINE_bool("gzip", False, 'tfrecord file is gzip or not')
tf.app.flags.DEFINE_bool("normalize_dense", False, "normalize to [0,1]")
tf.app.flags.DEFINE_bool("quantize", False, "enable tf quantization")
tf.app.flags.DEFINE_bool("renorm", False, "renorm in BN")
# Note: decoupled_weight_decay cannot be used util r1.10
tf.app.flags.DEFINE_enum("hot_mode", "none",
                         ["retrain_classfier", "emb_only", "all", "none"],
                         "session restore, emb_only: just keep weights of emb;"
                         " all: keep all weights including classifier"
                         " retrain_classfier: excluding predict weights")
tf.app.flags.DEFINE_float("l1", 0.1, "l1 regularization")
tf.app.flags.DEFINE_float("l2", 0.1, "l2 regularization")
tf.app.flags.DEFINE_integer("data_per_valid", 0,
                            "number of data to train before validating")
tf.app.flags.DEFINE_integer("steps_per_summary", 1024,
                            "number of steps to perform summary")
tf.app.flags.DEFINE_integer("patient_valid_passes", 2,
                            "number of valid passes before early stopping")
tf.app.flags.DEFINE_integer("quant_delay", 50, "training quantize delay")
tf.app.flags.DEFINE_integer("stop_steps", 0,
                            "steps when training stops")
tf.app.flags.DEFINE_string("checkpoint_path", "/tmp/checkpoint",
                           "path to save checkpoint")
tf.app.flags.DEFINE_string("model_name", "ctr", "name to save checkpoints.")
tf.app.flags.DEFINE_string("model_path", "/tmp/model_base",
                           "path to save models")
tf.app.flags.DEFINE_string("summaries_dir", "summaries", "summary dir")
tf.app.flags.DEFINE_string("train_data", None, "training data")
tf.app.flags.DEFINE_string("valid_data", None, "validating data")
tf.app.flags.DEFINE_string("hot_checkpoint", "",
                           "checkpoint path of hot training")
tf.app.flags.DEFINE_string("input_graph", "", "path of model graph")
tf.app.flags.DEFINE_integer("batch_size", 4, "batch size")
tf.app.flags.DEFINE_integer("prebatch", 256, "prebatch size for tfrecord")
tf.app.flags.DEFINE_integer("epochs", 10, "number of training epochs")
tf.app.flags.DEFINE_integer("interleave_cycle", 8,
                            "Number of interleaved inputs")
tf.app.flags.DEFINE_integer("parallel_parse", 8, "Number of parallel parsing")
tf.app.flags.DEFINE_integer("parallel_reads_per_file", 8,
                            "Number of parallel reads per file")
tf.app.flags.DEFINE_integer("shuffle_buffer", 512, "Size of shuffle buffer")
tf.app.flags.DEFINE_integer("prefetch_buffer", 4096, "Size of prefetch buffer")
tf.app.flags.DEFINE_integer("lr_schedule_mode", 0,
                            "0: no schedule; 1: linear increase 2: exponential increase")


class TimeLiner:
    _timeline_dict = None

    def update_timeline(self, run_metadata):
        fetched_timeline = timeline.Timeline(run_metadata.step_stats)
        chrome_trace = fetched_timeline.generate_chrome_trace_format()
        # convert crome trace to python dict
        chrome_trace_dict = json.loads(chrome_trace)
        # for first run store full trace
        if self._timeline_dict is None:
            self._timeline_dict = chrome_trace_dict
        # for other - update only time consumption, not definitions
        else:
            for event in chrome_trace_dict['traceEvents']:
                # events time consumption started with 'ts' prefix
                if 'ts' in event:
                    self._timeline_dict['traceEvents'].append(event)

    def save(self, output_folder, prefix):
        with open('{}/{}_timeline.json'.format(output_folder, prefix),
                  'w') as f:
            json.dump(self._timeline_dict, f)


def save_timeline(run_metadata, output_folder, steps, prefix):
    tl = timeline.Timeline(run_metadata.step_stats)
    ctf = tl.generate_chrome_trace_format()
    with open('{}/{}_{}_timeline.json'.format(output_folder, prefix, steps),
              'w') as f:
        f.write(ctf)


class BaseTrainable(object):
    def __init__(self, flags):
        tf.logging.warn(' {} Initialize training'.format(
            time.strftime("%Y%m%d %H:%M:%S")))
        if 'use_autotuner' in flags.__dict__:
            self.flags = flags
            tf.logging.warn(self.flags)
        else:
            self.flags = tf.app.flags.FLAGS
            tf.logging.warn('\ttf.app.flags.FLAGS:')
            for key, value in sorted(self.flags.flag_values_dict().items()):
                tf.logging.warn('\t{:25}= {}'.format(key, value))

        self.next_step_to_trace = 2
        self.batch_size = self.flags.prebatch * self.flags.batch_size
        self.best_loss = float('Inf')
        self.best_checkpoint = None
        self.patient_pass = 0
        self.max_patient_passes = self.flags.patient_valid_passes
        self.eval_timeline = TimeLiner()
        self.prediction_signature = None
        self.last_model_path = None
        self.queue = Queue()

    @classmethod
    def read_list_from_file(cls, filename):
        # tfrecord file should be a text file with absolute path of tfrecords
        if not os.path.isfile(filename):
            raise ValueError('{} should be a text file'.format(filename))
        with open(filename) as f:
            record_files = [path.strip() for path in f]
            return record_files

    @classmethod
    def parser(cls, record):
        raise NotImplementedError(
            "parser(called by tfrecord_pipeline): not implemented!")

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_files, batch_size,
                          epochs, shuffle=True):
        flags = tf.app.flags.FLAGS
        dataset = tf.data.Dataset.from_tensor_slices(tfrecord_files)
        if shuffle:
            dataset = dataset.shuffle(buffer_size=len(tfrecord_files))
        dataset = dataset.apply(
            tf.contrib.data.parallel_interleave(
                lambda x: tf.data.TFRecordDataset(
                    x,
                    compression_type='GZIP' if flags.gzip else None,
                    num_parallel_reads=flags.parallel_reads_per_file),
                cycle_length=flags.interleave_cycle,
                block_length=1))
        if shuffle:
            dataset = dataset.shuffle(buffer_size=flags.shuffle_buffer)
        dataset = \
            dataset.repeat(epochs) \
                   .map(cls.parser, num_parallel_calls=flags.parallel_parse) \
                   .batch(batch_size) \
                   .prefetch(buffer_size=int(flags.prefetch_buffer/batch_size))
        return dataset

    def initializer(self):
        return [self.train_iterator.initializer,
                self.one_epoch_iterator.initializer,
                self.valid_iterator.initializer]

    def valid_initializer(self):
        return self.valid_iterator.initializer

    def create_train_data_iterator(self):
        train_data = self.read_list_from_file(self.flags.train_data)
        valid_data = self.read_list_from_file(self.flags.valid_data)
        with tf.device('/cpu:0'):
            self.train_iterator = self.tfrecord_pipeline(
                train_data, self.flags.batch_size, epochs=self.flags.epochs
            ).make_initializable_iterator()
            self.valid_iterator = self.tfrecord_pipeline(
                valid_data, self.flags.batch_size, epochs=1, shuffle=False
            ).make_initializable_iterator()
            self.one_epoch_iterator = self.tfrecord_pipeline(
                train_data, self.flags.batch_size, epochs=1, shuffle=False
            ).make_initializable_iterator()

    def create_predict_data_iterator(self):
        valid_data = self.read_list_from_file(self.flags.valid_data)
        self.valid_iterator = self.tfrecord_pipeline(
            valid_data, self.flags.batch_size, epochs=1, shuffle=False
        ).make_initializable_iterator()

    def eval(self, steps):
        session = self.valid_session
        start_time = time.time()
        with session.graph.as_default():
            valid_handle = session.run(self.valid_iterator.string_handle())
            session.run([self.valid_initializer(),
                         tf.local_variables_initializer()])
            batches = 0
            FULL_TRACE_OPTION = tf.RunOptions(
                trace_level=tf.RunOptions.FULL_TRACE)
            RUN_METADATA = tf.RunMetadata()
            try:
                while True:
                    if self.flags.do_profile and batches < 3:
                        summary, valid_cost = session.run(
                            [self.merged, self.costs],
                            feed_dict={
                                self.is_training: False,
                                self.iterator_handle: valid_handle},
                            options=FULL_TRACE_OPTION,
                            run_metadata=RUN_METADATA)
                        self.eval_timeline.update_timeline(RUN_METADATA)
                    else:
                        summary, valid_cost = session.run(
                            [self.merged, self.costs],
                            feed_dict={
                                self.is_training: False,
                                self.iterator_handle: valid_handle})
                    batches += 1
            except tf.errors.OutOfRangeError:
                pass
            duration = time.time() - start_time
        if self.flags.do_profile:
            # TODO(chenp): profiling the large gap between evals
            self.eval_timeline.save(self.flags.summaries_dir,
                                    'eval_{}'.format(steps))
        self.queue.put(
            (valid_cost, summary, batches, duration, session, steps))

    def prepare_summary(self, session):
        self.saver = tf.train.Saver()
        self.merged = tf.summary.merge_all()
        self.train_writer = tf.summary.FileWriter(
            os.path.join(self.flags.summaries_dir, 'train'),
            session.graph)
        self.valid_writer = tf.summary.FileWriter(
            os.path.join(self.flags.summaries_dir, 'valid'),
            session.graph)

    def print_stats(self, string, num_data, duration, cost, base_logloss):
        throughput = num_data / duration
        tf.logging.warn("{} {:10} loss={} norm_loss={} roc={} pr={}"
                        " calibration={} rate={}".format(
                            string,
                            num_data,
                            cost['stream_loss'],
                            cost['stream_loss'] / base_logloss,
                            cost['roc'],
                            cost['pr'],
                            cost['calibration'],
                            throughput))

    def print_train_stats(self, steps, start_time, cost, lr):
        self.print_stats('Train', steps * self.batch_size,
                         time.time() - start_time, cost,
                         self.train_base_logloss)

    def print_train_stats_lr_schedule(self, steps, start_time, cost, lr):
        num_data = steps * self.batch_size
        throughput = num_data / (time.time() - start_time)
        base_logloss = self.train_base_logloss
        tf.logging.warn("Train lr schedule {:10} lr={} loss={} norm_loss={}".format(
                            num_data,
                            lr,
                            cost['stream_loss'],
                            cost['stream_loss'] / base_logloss,
                            throughput))

    def maybe_trace(self, steps, start_time, cost, lr):
        if steps == self.next_step_to_trace:
            if self.flags.lr_schedule_mode > 0:
                self.next_step_to_trace = int(self.next_step_to_trace + self.flags.lr_schedule_print_step)
                self.print_train_stats_lr_schedule(steps, start_time, cost, lr)
            else:
                self.next_step_to_trace = int(self.next_step_to_trace * 1.5)
                self.print_train_stats(steps, start_time, cost, lr)
            return True
        else:
            return False

    def should_early_stop(self, valid_cost, summary, batches,
                          duration, session, steps):
        chkpoint = os.path.join(self.flags.checkpoint_path,
                                self.flags.model_name+'_best')
        self.valid_writer.add_summary(summary, steps)
        self.print_stats('Eval', batches * self.batch_size, duration,
                         valid_cost, self.valid_base_logloss)
        valid_loss = valid_cost['stream_loss']
        if valid_loss < self.best_loss:
            self.best_loss = valid_loss
            self.best_cost = valid_cost
            self.patient_pass = 0
            tf.logging.warn(
                'A better loss {} found at {}, steps={}'.format(
                    self.best_loss, chkpoint, steps))
            self.best_checkpoint = self.saver.save(session, chkpoint)
            self.save_model(session)
        else:
            self.patient_pass += 1
            tf.logging.warn(
                'best_loss={}, cur_loss={}'.format(
                    self.best_loss, valid_loss))
            if self.patient_pass >= self.max_patient_passes:
                return True
        return False

    def get_costs_keys(self):
        costs_keys = sorted(['loss', 'stream_loss',
                             'roc', 'pr', 'calibration'])
        return costs_keys

    def load_graph_from_file(self):
        tf.train.import_meta_graph(self.flags.input_graph)
        self.preds = tuple(tf.get_collection(GRAPH_PREDS))
        self.train_op = tuple(tf.get_collection(GRAPH_TRAIN_OP))
        costs_keys = self.get_costs_keys()
        costs_values = tf.get_collection(GRAPH_COSTS)
        self.costs = {costs_keys[i]:
                      costs_values[i] for i in range(len(costs_keys))}
        self.is_training = tuple(tf.get_collection(GRAPH_TRAIN_FLAG))
        self.iterator_handle = tuple(tf.get_collection(GRAPH_ITERATOR_HANDLE))
        self.features = tf.get_collection(GRAPH_FEATURES)
        self.labels = tf.get_collection(GRAPH_LABELS)
        self.global_step = tf.get_default_graph().get_tensor_by_name(
            GLOBAL_STEP+':0')
        self.learning_rate = tf.get_default_graph().get_tensor_by_name(
            LEARNING_RATE+':0')
        meta_graph_def = meta_graph_pb2.MetaGraphDef()
        with open(self.flags.input_graph, 'rb') as graph_file:
            meta_graph_def.ParseFromString(graph_file.read())
        self.signature_def_map = meta_graph_def.signature_def

    def train(self, session):
        sess_config = tf.ConfigProto(allow_soft_placement=True)
        sess_config.gpu_options.allow_growth = True
        self.valid_session = tf.Session(config=sess_config)
        self.create_train_data_iterator()
        one_epoch_handle = session.run(self.one_epoch_iterator.string_handle())
        train_handle = session.run(self.train_iterator.string_handle())
        valid_handle = session.run(self.valid_iterator.string_handle())
        self.prepare_summary(session)
        self.session_initializer(session)
        steps_per_valid = int(self.flags.data_per_valid / self.batch_size)
        stop_steps = self.flags.stop_steps
        if (steps_per_valid <= 0) == (stop_steps <= 0):
            raise ValueError('data_per_valid and stop_steps'
                             ' can not be larger than, less than or equal to 0'
                             ' at the same time')
        self.train_base_logloss = self.compute_base_logloss(
            session, one_epoch_handle)
        steps_per_summary = self.flags.steps_per_summary
        if steps_per_valid > 0:
            """
            is_training is unspecified, and the default value is False so the
            self.labels is read from valid input
            """
            self.valid_base_logloss = self.compute_base_logloss(
                session, valid_handle)
            steps_per_summary = steps_per_valid
        start_time = time.time()
        steps = 0
        process = None
        start_steps = session.run(self.global_step)
        try:
            while True:
                _, global_steps, cost, lr = session.run(
                    [self.train_op, self.global_step, self.costs, self.learning_rate],
                    feed_dict={
                        self.is_training: True,
                        self.iterator_handle: train_handle})
                # tf.logging.warn('steps:{}'.format(steps))
                steps = global_steps - start_steps

                # also show the summary of the first step
                if (steps == 1) or (steps % steps_per_summary) == 0:
                    summary = session.run(
                        # TODO(yu) waste a little bit data here,
                        self.merged, feed_dict={
                            self.is_training: True,
                            self.iterator_handle: train_handle})
                    self.train_writer.add_summary(summary, steps)

                # do training trace before the first eval with eval
                # or always training trace without eval
                # print training loss together with eval after that.
                if steps < steps_per_valid or stop_steps > 0:
                    if self.maybe_trace(steps, start_time, cost, lr):
                        session.run([tf.local_variables_initializer()])
                elif steps_per_valid > 0 and steps % steps_per_valid == 0:
                    # just in case last eval isn't done yet
                    if process:
                        valid_detail = self.queue.get()
                        do_stop = self.should_early_stop(*valid_detail)
                        process = None
                        if do_stop:
                            tf.logging.warn('Early stopping')
                            break
                    prefix = self.saver.save(
                        session,
                        os.path.join(self.flags.checkpoint_path,
                                     self.flags.model_name),
                        global_step=int(time.time()))
                    self.print_train_stats(steps, start_time, cost, lr)
                    # reset training session eval metrics
                    session.run([tf.local_variables_initializer()])

                    # run eval in separate session and thread
                    self.saver.restore(self.valid_session, prefix)
                    # delete checkpoint file after restore
                    chkpt = glob('{}.*'.format(prefix))
                    for f in chkpt:
                        os.remove(f)
                    process = Process(target=self.eval, args=(steps,))
                    process.start()
                if not self.queue.empty():
                    valid_detail = self.queue.get()
                    do_stop = self.should_early_stop(*valid_detail)
                    process = None
                    if do_stop:
                        tf.logging.warn('Early stopping')
                        break
                # stop training when steps reachs the stop_steps
                if stop_steps > 0 and steps >= stop_steps:
                    tf.logging.warn('Training stoped at'
                                    ' steps={}'.format(global_steps))
                    self.save_model(session)
                    break
        except tf.errors.OutOfRangeError:
            tf.logging.warn('Done reading data')
            # in case stop_steps > max_steps
            if stop_steps > 0:
                self.save_model(session)
        # logging best valid loss with eval, last train loss without eval
        if steps_per_valid <= 0:
            best_cost = cost
            log_name = 'train'
            base_logloss = self.train_base_logloss
        else:
            best_cost = self.best_cost
            log_name = 'valid'
            base_logloss = self.valid_base_logloss
        """
        set num_data to 0 and duration to 1 to skip these two stats
        """
        self.print_stats('Final best ' + log_name, 0, 1, best_cost,
                         base_logloss)
        tf.logging.warn(" {} Save final checkpoint".format(
            time.strftime("%Y%m%d %H:%M:%S")))
        model_path_name = os.path.join(self.flags.checkpoint_path,
                                       self.flags.model_name)
        self.saver.save(session, model_path_name, global_step=global_steps)
        with open(model_path_name + '.pbtxt', 'w') as f:
            f.write(str(tf.get_default_graph().as_graph_def()))
        return self.metric_for_auto_tuner(best_cost)

    def metric_for_auto_tuner(self, best_cost):
        return best_cost['stream_loss']

    def _mylog(self, r):
        return math.log(max(r, 1e-18))

    def compute_base_logloss(self, session, data_handle):
        try:
            start_time = time.time()
            total_positive = 0
            total = 0
            while True:
                results = session.run(
                    self.labels, feed_dict={self.iterator_handle: data_handle})
                """
                Assume negatice is 0
                """
                total_positive += np.count_nonzero(results)
                total += np.size(results)
        except tf.errors.OutOfRangeError:
            end_time = time.time()
            total_time = (end_time-start_time)
            positive_rate = 1.0 * total_positive / total
            log_loss = -self._mylog(positive_rate) * positive_rate \
                - self._mylog(1-positive_rate) * (1-positive_rate)
            tf.logging.warn('Done computing base logloss: {}'
                            ' ctr: {}'.format(log_loss, positive_rate))
            tf.logging.warn('Total time %.2f s, speed %.2f sample/s,'
                            ' total samples %d.' %
                            (total_time, total / total_time, total))
            return log_loss

    def read_data(self, session, print_keys=None):
        self.create_predict_data_iterator()
        valid_handle = session.run(self.valid_iterator.string_handle())
        session.run(self.valid_initializer())
        try:
            start_time = time.time()
            s = 0
            features_stats = {}
            total_samples = 0
            while True:
                features, labels = session.run(
                    [self.features, self.labels],
                    feed_dict={self.is_training: True,
                               self.iterator_handle: valid_handle})
                s += 1
                if (s <= self.flags.print_steps) and (print_keys is not None):
                    for key in print_keys:
                        tf.logging.warn(key)
                        tf.logging.warn(features[key])
                if self.flags.cal_stats:
                    for key, tensor in features.items():
                        if isinstance(tensor, tf.SparseTensorValue):
                            tensor = tensor.values
                        if s == 1:
                            # tensor may be a concat of multiple features
                            if len(tensor.shape) > 1:
                                value_len = tensor.shape[-1]
                            else:
                                value_len = 1
                            # sum, max, min
                            features_stats[key] = [[0.0] * value_len,
                                                   [float('-inf')] * value_len,
                                                   [float('inf')] * value_len]
                        features_stats[key][0] += np.sum(tensor, axis=0)
                        features_stats[key][1] = np.maximum(
                            features_stats[key][1],
                            np.max(tensor, axis=0))
                        features_stats[key][2] = np.minimum(
                            features_stats[key][2],
                            np.min(tensor, axis=0))
                    for i in range(len(labels)):
                        key = 'label_' + str(i)
                        if s == 1:
                            features_stats[key] = [0.0,
                                                   float('-inf'),
                                                   float('inf')]
                        features_stats[key][0] += sum(labels[i])
                        features_stats[key][1] = max(
                            features_stats[key][1], max(labels[i]))
                        features_stats[key][2] = min(
                            features_stats[key][2], min(labels[i]))
                    for key, tensor in features.items():
                        if isinstance(tensor, tf.SparseTensorValue):
                            tensor = tensor.values
                        total_samples += int(tensor.shape[0])
                        break
        except tf.errors.OutOfRangeError:
            if self.flags.cal_stats:
                for key, value in sorted(features_stats.items()):
                    features_stats[key][0] /= total_samples
                    tf.logging.warn(" mean={:<18} max={:<8} "
                                    "min={:<8} name={}".format(
                                        str(features_stats[key][0]),
                                        str(value[1]),
                                        str(value[2]),
                                        str(key)))
            else:
                total_samples = s * self.batch_size
            tf.logging.warn('Done reading data')
            end_time = time.time()
            total_time = (end_time-start_time)
            tf.logging.warn('Total time %.2f s, total samples by batch %d,'
                            ' speed %.2f sample/s' %
                            (total_time, total_samples,
                             total_samples / total_time))
            return features_stats

    def predict(self, session):
        self.create_predict_data_iterator()
        if self.flags.predict_summary:
            self.prepare_summary(session)
        valid_handle = session.run(self.valid_iterator.string_handle())
        session.run([self.valid_initializer()])
        self.valid_base_logloss = self.compute_base_logloss(
            session, valid_handle)
        session.run([self.valid_initializer(),
                     tf.local_variables_initializer()])
        start_time = time.time()
        batches = 0
        label_list = []
        pred_list = []
        try:
            while True:
                if self.flags.predict_summary:
                    summary, steps, labels, preds, valid_cost = session.run(
                        [self.merged, self.global_step,
                         self.labels, self.preds, self.costs],
                        feed_dict={
                            self.is_training: False,
                            self.iterator_handle: valid_handle})
                    self.valid_writer.add_summary(summary, steps)
                else:
                    labels, preds, valid_cost = session.run(
                        [self.labels, self.preds, self.costs],
                        feed_dict={
                            self.is_training: False,
                            self.iterator_handle: valid_handle})
                """
                labels and preds maybe a np array, or list of np arrays,
                depending on self.labels and self.preds
                """
                label_list.extend(np.concatenate(labels, -1).ravel().tolist())
                pred_list.extend(np.concatenate(preds, -1).ravel().tolist())
                batches += 1
        except tf.errors.OutOfRangeError:
            self.best_loss = valid_cost['stream_loss']
            self.print_stats('Eval', batches * self.batch_size,
                             time.time() - start_time, valid_cost,
                             self.valid_base_logloss)
        tf.logging.warn("Done prediction")
        return zip(label_list, pred_list)

    def save_model(self, session):
        if self.last_model_path is not None:
            shutil.rmtree(self.last_model_path)
        timestamp = time.strftime("%Y%m%d%H%M%S")
        export_path = os.path.join(
            self.flags.model_path, self.flags.model_name, timestamp)
        self.last_model_path = export_path
        tf.logging.warn("Save Models Path: " + export_path)
        builder = tf.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            session, [tf.saved_model.tag_constants.SERVING],
            signature_def_map=self.signature_def_map,
            clear_devices=True)
        builder.save()

    def session_initializer(self, session):
        if self.flags.do_profile:
            tf.logging.warn('global vars to initialize')
            for var in tf.global_variables():
                tf.logging.warn(var.name)
            tf.logging.warn('local vars to initialize')
            for var in tf.local_variables():
                """
                local_variable are metrics related variables
                """
                tf.logging.warn(var.name)
        if self.flags.hot_mode == 'all':
            session.run([tf.local_variables_initializer(), self.initializer()])
        elif self.flags.hot_mode == 'emb_only':
            variables = tf.global_variables(scope=r'^(?!.*embedding)')
            session.run([tf.variables_initializer(variables),
                         tf.local_variables_initializer(),
                         self.initializer()])
        elif self.flags.hot_mode == 'retrain_classfier':
            variables = tf.global_variables(scope='predict')
            session.run([tf.variables_initializer(variables),
                         tf.local_variables_initializer(),
                         self.initializer()])
        else:
            session.run([tf.global_variables_initializer(),
                         tf.local_variables_initializer(),
                         tf.tables_initializer(),
                         self.initializer()])
