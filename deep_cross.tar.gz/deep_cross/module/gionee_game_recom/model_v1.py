#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
V1:
    cross: BN(dense) + embedding
    deep: BN(dense) + embedding
"""


import tensorflow as tf

from .model_v0 import BaseGioneeGameDXLModel
from .summary import NUMERICAL_MAX, NUMERICAL_MIN


class DeepCrossModel(BaseGioneeGameDXLModel):
    def __init__(self, flags):
        super(DeepCrossModel, self).__init__(flags)
        self.dense_min = tf.Variable(NUMERICAL_MIN,dtype=tf.float32)
        self.dense_max = tf.Variable(NUMERICAL_MAX,dtype=tf.float32)
        self.dense_norm = self.dense_max - self.dense_min

    def build_network(self, features):
        fv = features['continuous']
        ids = features['categorical']
        with tf.device('/gpu:0'):
            ev = self.build_embedding_layer(ids)
            fv = self.build_dense_layer(fv)
            inputs = self.concat([fv, ev])
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            return tf.concat([deep_out, cross_out], -1)

    def build_embedding_layer(self, ids):
        return self.embedding(ids, "embedding", None)

    def get_dense_max(self):
        return self.dense_max

    def get_dense_min(self):
        return self.dense_min

    def get_dense_norm(self):
        return self.dense_norm

    def build_dense_layer(self, fv):
        return self.BN(tf.log1p(fv))

    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)

    def build_cross(self, raw_inputs, num_layers=3):
        return self.cross_net(raw_inputs, num_layers,
                              use_bias=self.flags.cross_bias,
                              sparse=self.flags.sparse_cross)
