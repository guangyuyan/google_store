#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
build graph for gionee
"""


import tensorflow as tf
from ..base.build_graph_utils import build_graph
from .build_model import build_model


def main(unused=None):
    flags = tf.app.flags.FLAGS
    with tf.Graph().as_default():
        model = build_model(flags)
        model.build()
        build_graph(model)

if __name__ == "__main__":
    tf.app.run(main)
