#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
name and vocabulary size of sparse size
"""

import os


CATEGORY_FEATURES = list()
VOC_SIZE = list()
NUMERICAL_MIN = list()
NUMERICAL_MAX = list()


OFFLINE_FEATURE_RANGE = (0, 1071)
ONLINE_FEATURE_RANGE = None

with open(os.path.join(os.path.dirname(__file__),
                       'data/sparse_size.txt')) as f:
    VOC_SIZE = [int(line) for line in f]

CATEGORY_FEATURES = [str(i) for i in range(len(VOC_SIZE))]

with open(os.path.join(os.path.dirname(__file__),
                       './data/numerical_minmax.txt')) as f:
    minmax = [m.split('\t') for m in f]
    minmax = [col for col in zip(*minmax)]
    NUMERICAL_MIN = [float(item) for item in minmax[0]]
    NUMERICAL_MAX = [float(item) for item in minmax[1]]
