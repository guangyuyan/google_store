#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build model
"""


from . import model_v1


def build_model(flags):
    if flags.model == 'v1':
        model = model_v1.DeepCrossModel(flags)

    return model
