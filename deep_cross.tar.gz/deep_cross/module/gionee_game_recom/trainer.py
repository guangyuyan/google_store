#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

from __future__ import division
import time
import tensorflow as tf
from ..base.trainer import train
from .build_model import build_model
from ..base.build_graph_utils import graph_add_collection


def main(unused=None):
    start_time = time.time()
    print '训练开始时间:',start_time
    flags = tf.app.flags.FLAGS

    model = build_model(flags)
    model.build()
    graph_add_collection(model)
    train(model)
    end_time = time.time()
    print '训练结束时间:',end_time
    print '模型训练时长(分钟):',(end_time-start_time)/60


if __name__ == "__main__":
    tf.app.run(main)
