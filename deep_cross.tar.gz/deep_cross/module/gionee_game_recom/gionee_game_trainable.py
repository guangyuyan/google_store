#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""

"""

from ..base.base_trainable import BaseTrainable
import tensorflow as tf

tf.app.flags.DEFINE_integer("dense_features", 16, "number of dense features")
tf.app.flags.DEFINE_integer("sparse_features", 7, "number of sparse features")


class GioneeGameTrainable(BaseTrainable, object):

    def __init__(self, flags):
        super(GioneeGameTrainable, self).__init__(flags)

    @classmethod
    def parser(cls, record):
        #TODO(pengzx)Add variable length feature processing
        prebatch = tf.flags.FLAGS.prebatch
        feature_map = {
            'dense': tf.FixedLenFeature(
                [prebatch * tf.app.flags.FLAGS.dense_features], tf.float32),
            'sparse': tf.FixedLenFeature(
                [prebatch * tf.app.flags.FLAGS.sparse_features], tf.int64),
            'label': tf.FixedLenFeature([prebatch], tf.int64),
        }
        features = tf.parse_single_example(record, features=feature_map)
        return features
