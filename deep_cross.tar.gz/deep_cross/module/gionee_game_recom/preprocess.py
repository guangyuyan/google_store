#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
Preprocess gionee_game_recom dataset.
(/var/data/zhangm/gamec/data/).
"""
from __future__ import division
import time
import os
import sys
import click
import random
import collections

# There are 38 integer features and 3 categorical features
categorial_features = range(2, 9)#不使用imei特征
continous_features = range(9, 25)

# Clip integer features. The clip point for each integer feature
# is derived from the 95% quantile of the total values in each feature
#continous_clip = [20, 600, 100, 50, 64000, 500, 100, 50, 500, 10, 10, 10, 50]

@click.command("preprocess")
@click.option("--datadir", type=str, help="Path to raw criteo dataset")
@click.option("--outdir", type=str, help="Path to save the processed data")
def preprocess(datadir, outdir):
    start_time = time.time()
    print '开始时间:',start_time
    random.seed(0)
    with open(os.path.join(outdir, 'train_0625.txt'), 'w') as out_train:
        with open(os.path.join(datadir, 'gamec_cb_train_sample_0625'), 'r') as f:
            next(f)
            for line in f:
                features = line.rstrip('\n').split('\t')

                continous_vals = []
                for i in range(len(categorial_features)+2, \
                    len(categorial_features)+len(continous_features)+2):
                    val = features[i]
                    if val == '':
                        val = 0.0
                    continous_vals.append("{0:.6f}".format(float(val)).\
                                          rstrip('0').rstrip('.'))
                categorial_vals = []
                for i in range(2, len(categorial_features)+2):
                    val = features[i]
                    if val == '':
                        val = -1
                    categorial_vals.append(str(val))

                continous_vals = ','.join(continous_vals)
                categorial_vals = ','.join(categorial_vals)
                label = features[0]
                out_train.write('\t'.join(
                    [continous_vals, categorial_vals, label]) + '\n')
    end_time = time.time()
    print '结束时间:',end_time
    print '数据预处理总时长(分钟):',(end_time-start_time)/60

if __name__ == "__main__":
    preprocess()
