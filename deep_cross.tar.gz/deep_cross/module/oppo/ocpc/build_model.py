#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build Model
"""

from . import model_v1

def build_model(flags):
    if flags.model == 'v1':
        model = model_v1.OPPOCVRModel(flags)
    else:
        raise ValueError('--model {} was not found.'.format(flags.model))
    return model
