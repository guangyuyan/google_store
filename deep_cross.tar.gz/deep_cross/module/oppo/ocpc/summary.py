#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.

"""
name and vocabulary size of sparse size
"""

import csv
import tensorflow as tf

tf.app.flags.DEFINE_string('feature_schema_file', '', 'feature format file')
tf.app.flags.DEFINE_string('categorical_name', 'categorical', 'class name for categorical feature')
tf.app.flags.DEFINE_string('numerical_name', 'numerical', 'class name for numerical feature')
tf.app.flags.DEFINE_string('varlen_name', 'sparse', 'class name for var length feature')

CATEGORY_FEATURES = list()
VARLEN_FEATURES = list()
VOC_SIZE_DICT = dict()
NUMERICAL_MIN = list()
NUMERICAL_MAX = list()
DENSE_SIZE = 0


def parse_schema(flags):
    with open(flags.feature_schema_file, "r") as csvfile:
        schema = csv.reader(csvfile, delimiter=',')
        schema = list(schema)
        DENSE_SIZE = len([row[1] for row in schema if row[2] == flags.numerical_name])
        CATEGORY_FEATURES = [row[1] for row in schema if row[2] == flags.categorical_name]
        VARLEN_FEATURES = [row[1] for row in schema if row[2] == flags.varlen_name]
        VOC_SIZE_DICT = {row[1]:int(row[0]) for row in schema}
    return CATEGORY_FEATURES, VARLEN_FEATURES, VOC_SIZE_DICT, DENSE_SIZE
