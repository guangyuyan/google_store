#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
V1:
    cross: BN(log(dense)) + embedding
    deep: BN(log(dense)) + embedding
"""


import tensorflow as tf
from .model_v0 import BaseOPPOCVRModel, CONTINUOUS_FEATURES_KEY


class OPPOCVRModel(BaseOPPOCVRModel):
    def __init__(self, flags):
        super(OPPOCVRModel, self).__init__(flags)

    def build_features(self, features, embedding_suffix=''):
        with tf.device('/cpu:0'):
            ev_list = []
            for key in self.CATEGORY_FEATURES:
                ev_list.append(
                    self.build_single_embedding(
                        features[key],
                        layer_name=key + embedding_suffix,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))

            sparse_ev_list = []
            for key in self.VARLEN_FEATURES:
                sparse_ev_list.append(
                    self.build_sparse_embedding(
                        features[key],
                        layer_name=key + embedding_suffix,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))

            fv = self.build_dense_layer(features[CONTINUOUS_FEATURES_KEY])

            if self.flags.summary_mode == 'all':
                tf.summary.histogram(fv.name, fv)

            network_inputs = self.concat([fv] + ev_list + sparse_ev_list)

            input_dim = 0
            for key in network_inputs:
                tf.logging.warn(key)
                input_dim += int(key.get_shape()[-1])
            tf.logging.warn("Total input dim: {}".format(input_dim))
            return network_inputs

    def build_dense_layer(self, fv):
        return self.BN(tf.log1p(tf.nn.relu(fv)))
