package ai.cloudbrain.feature.job

import java.text.SimpleDateFormat
import java.util.Random

import ai.cloudbrain.feature.common.{ArgSetup, Util}
import net.sourceforge.argparse4j.inf.Namespace
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.catalyst.expressions.GenericRow
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.types._

import scala.collection.mutable.ListBuffer

object TfrecordBuild extends BaseJob {
  override val NAME = "tfrecords"
  val FORMAT: SimpleDateFormat = Util.dateFormat("yyyyMMdd")
  val millsSecondsInHour: Int = 1000 * 60 * 60

  val NUMERICAL = "numerical"
  val CATEGORICAL = "categorical"
  val VAR_LEN = "sparse"
  val CLICK = "click"
  val CONVERSION = "conversion"
  val CONVERSION_TF = "conv"
  val DISPLAY_TIME = "display_time"
  val CONVERSION_TIME = "conversion_time"
  val INTERVAL = "delay_or_elapse"

  val ROOT = "/user/yunnao/spark_out/"
  val OUT = "/user/yunnao/tfrecords/"
  //  val FEATURE_MAP = "rs_widemeta/"
  //  val FEATURES = "widetable/"
  val LABELS = "conversion/ready_conversion/"
  val WIDE = "widetable"

  def main(args: Array[String]): Unit = {
    val ns = ArgSetup.setup("staticsFeature", parser => {
      parser.addArgument("--ns-rate").help("negative sampling rate")
      parser.addArgument("--prebatch").help("sampling size of a prebatch")
      parser.addArgument("--partition").help("partition of dataset formatted like 'yyyyMMdd'").required(true)
      parser.addArgument("--cutoff-time").help("a fake current time")
      parser.addArgument("--num-partitions").help("number of minimum partitions")
      parser.addArgument("--duration").help("day range length before partition(include)")
      parser.addArgument("--version").help("version of features").required(true)
      parser.setDefault("ns_rate", "1")
      parser.setDefault("prebatch", "256")
      parser.setDefault("cutoff_time", FORMAT.format(System.currentTimeMillis()))
      parser.setDefault("num_partitions", "20")
      parser.setDefault("duration", "1")
    }, args)
    setUpSession()
    process(ns)
  }

  def process(ns: Namespace): Unit = {
    val partition = ns.getString("partition")
    val duration = ns.getString("duration").toInt
    val partitions = Util.dateSeq(partition, FORMAT, duration, reverse = true)

    val features = CurrentSession.read.orc(partitions.map(part => s"$ROOT$WIDE/dayno=$part/data"): _*)
    val labels = CurrentSession.read.orc(partitions.map(part => s"$ROOT${LABELS}dayno=$part"): _*)
    val schema = CurrentSession.read.orc(s"$ROOT$WIDE/dayno=$partition/meta").collect()

    val dataSet = features.join(labels, Seq("adid", "imei", "traceid"), "left").na.fill(0, Seq("conversion", "click"))
    val vocabulary = schema.map(row => row.getAs[String]("name") -> row.getAs[Long]("dim")).toMap
    val featureMap = schema.groupBy(_.getAs[String]("type"))
      .map({ case (key, rows) => key -> rows.map(_.getAs[String]("name")).toList })

    val nsRate = ns.getString("ns_rate").toFloat
    val preBatch = ns.getString("prebatch").toInt
    val numPartitions = ns.getString("num_partitions").toInt
    val cutoffTime = FORMAT.parse(ns.getString("cutoff_time")).getTime
    val version = ns.getString("version")

    val trainSet = convert(nsRate, preBatch, cutoffTime, dataSet, vocabulary, featureMap, numPartitions)
    writeToTfrecord(trainSet, featureMap, partition, version)
  }

  def convert(nsRate: Float, preBatch: Int, cutoffTime: Long, dataSet: DataFrame, vocabulary: Map[String, Long],
              featureMap: Map[String, List[String]], partitionNum: Int): RDD[Row] = {
    val random = new Random()

    val clickName = featureMap(CLICK).head
    val conversionName = featureMap(CONVERSION).head
    val displayTime = featureMap(DISPLAY_TIME).head
    val conversionTime = featureMap(CONVERSION_TIME).head

    val negSamples = dataSet.filter(row => row.getAs[Long](clickName) > 1 || random.nextFloat() < nsRate)
      // if conversion is 0, conversion time is null, make it current time
      .na.fill(cutoffTime, Seq(conversionTime))
    val cutoffData = negSamples
      // make the conversion to 0 if conversion time behind current time
      .withColumn(conversionName, when(negSamples(conversionTime) > cutoffTime, 0l).otherwise(negSamples(conversionName)))
      // make the conversion time not bigger than current time
      .withColumn(conversionTime, when(negSamples(conversionTime) > cutoffTime, cutoffTime).otherwise(negSamples(conversionTime)))

    cutoffData.rdd.coalesce(partitionNum, shuffle = true).mapPartitions[Row](rows => {
      val retVal = ListBuffer[Row]()

      var count: Int = 0
      val numerical = ListBuffer[Double]()
      val categorical = Map[String, ListBuffer[Long]](featureMap(CATEGORICAL).map(col => col -> ListBuffer[Long]()): _*)
      val varLen = Map[String, ListBuffer[Long]](featureMap(VAR_LEN).map(col => col -> ListBuffer[Long]()): _*)
      val click = ListBuffer[Long]()
      val conversion = ListBuffer[Long]()
      val interval = ListBuffer[Double]()
      val convTime = ListBuffer[Long]()

      rows.foreach(row => {
        // features
        featureMap(NUMERICAL).foreach(numerical += row.getAs[Double](_))
        featureMap(CATEGORICAL).foreach(col => categorical(col) += row.getAs[Long](col))
        // special treatment for var_len features
        featureMap(VAR_LEN).foreach(col =>
          str2ids(row.getAs[String](col))
            .map(_ + (count * vocabulary(col)))
            .foreach(varLen(col) += _)
        )
        // labels
        click += row.getAs[Long](clickName)
        conversion += row.getAs[Long](conversionName)
        interval += (row.getAs[Long](conversionTime) - row.getAs[Long](displayTime)).toDouble / millsSecondsInHour
        convTime += row.getAs[Long](conversionTime)
        count += 1
        // write as one line when counts touch the pre-batch
        if (count == preBatch) {
          val ret = ListBuffer[List[Any]](numerical.result())
          ret += click.result()
          ret += conversion.result()
          ret += interval.result()
          ret += convTime.result()
          featureMap(CATEGORICAL).foreach(ret += categorical(_).result())
          featureMap(VAR_LEN).foreach(ret += varLen(_).result())
          retVal += new GenericRow(ret.toArray[Any])
          numerical.clear()
          categorical.foreach(p => categorical(p._1).clear())
          varLen.foreach(p => varLen(p._1).clear())
          click.clear()
          conversion.clear()
          interval.clear()
          convTime.clear()
          count = 0
        }
      })
      retVal.iterator
    })
  }

  private def str2ids(str: String): Array[Long] = {
    str.split(",").map(_.split(":").head.toLong).sorted
  }

  def writeToTfrecord(rdd: RDD[Row], featureMap: Map[String, List[String]], outPath: String, version: String): Unit = {
    val schema = StructType(List(
      StructField(NUMERICAL, ArrayType(DoubleType, containsNull = false), nullable = true),
      StructField(CLICK, ArrayType(LongType, containsNull = false), nullable = true),
      StructField(CONVERSION_TF, ArrayType(LongType, containsNull = false), nullable = true),
      StructField(INTERVAL, ArrayType(DoubleType, containsNull = false), nullable = false),
      StructField(CONVERSION_TIME, ArrayType(LongType, containsNull = false), nullable = false))
      .union(featureMap(CATEGORICAL).map(StructField(_, ArrayType(LongType, containsNull = false), nullable = false)))
      .union(featureMap(VAR_LEN).map(StructField(_, ArrayType(LongType, containsNull = false), nullable = false)))
    )

    val path = s"$OUT$version$outPath"
    val df: DataFrame = CurrentSession.createDataFrame(rdd, schema)
    df.write.mode(SaveMode.Overwrite).format("tfrecords").option("recordType", "Example").save(path)
  }
}
