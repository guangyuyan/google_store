#! /bin/sh
#
# tfrecords.sh
# Copyright (C) 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.
#
# train set


yspark-submit \
  --class ai.cloudbrain.feature.job.TfrecordBuild \
  --master yarn \
  --deploy-mode cluster \
  --num-executors 16 \
  --executors-cores 3 \
  --executors-memory 16g \
  --driver-memory 2g \
  ./target/feature-engneering-1.0.0-with-custom-lib.jar \
  --partition 20180720 \
  --duration 14 \
  # means date range 20180706-20180720
  --cutoff-time 20180720
