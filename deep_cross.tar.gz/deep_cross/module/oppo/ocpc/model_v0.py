#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base CVR model for OPPO OCPC
"""

import tensorflow as tf
from ...base.model_cvr_base import BaseCVRModel
from .oppo_trainable import OppoTrainable, CONTINUOUS_FEATURES_KEY

'''
DO NOT put flags here, since import oppo_trainable would call parse_schema(),
which would parse flags. If defined flags here, the flags would be unknown
to parse_schema()
Please put it into oppo_trainable or base directory,
like model_cvr_base, model_base, which are imported before oppo_trainable
'''

class BaseOPPOCVRModel(BaseCVRModel, OppoTrainable):
    voc_emb_size = None

    def __init__(self, flags):
        BaseCVRModel.__init__(self, flags)
        OppoTrainable.__init__(self, flags)
        self.NUM_POSITIONS = 100
        BaseOPPOCVRModel.voc_emb_size = self.load_voc_summary()

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_file,  batch_size,
                          epochs, shuffle=True):
        return OppoTrainable.tfrecord_pipeline(tfrecord_file, batch_size,
                                               epochs, shuffle)

    @classmethod
    def reshape_input(cls, features):
        labels = [tf.reshape(features.pop('click'), [-1, 1]),
                  tf.reshape(features.pop('conv'), [-1, 1])]
        if 'delay_or_elapse' in features:
            labels.append(
                tf.reshape(features.pop('delay_or_elapse'), [-1, 1]))
        features[CONTINUOUS_FEATURES_KEY] = tf.reshape(
            features[CONTINUOUS_FEATURES_KEY], [-1, cls.DENSE_SIZE])
        for key in cls.CATEGORY_FEATURES:
            features[key] = tf.reshape(features[key], [-1, 1])
        for key in cls.VARLEN_FEATURES:
            features[key] = cls.reshape_sparse(
                features[key], cls.voc_emb_size[key][0])
        return features, labels

    @classmethod
    def reshape_sparse(cls, feature, voc_size):
        with tf.device('/cpu:0'):
            new_indices = (feature.values // voc_size +
                           feature.indices[:, 0] * tf.flags.FLAGS.prebatch)
            new_feature = tf.SparseTensor(
                indices=tf.stack([new_indices, feature.values % voc_size],
                                 axis=1),
                values=feature.values % voc_size,
                dense_shape=[-1, voc_size])
            return new_feature

    @classmethod
    def load_voc_summary(cls):
        concat_features = cls.VARLEN_FEATURES + cls.CATEGORY_FEATURES
        voc_emb_size = {}
        for key in concat_features:
            voc_size = cls.VOC_SIZE_DICT[key]
            emb_size = cls.compute_emb_size(voc_size)
            voc_emb_size[key] = [voc_size, emb_size]
        for k, v in voc_emb_size.items():
            cls.print_emb_info(k, v[0], v[1])
        return voc_emb_size
