#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Client to use rpc connecting the Sever to send features and get labels back

CUDA_VISIBLE_DEVICE=0 python3 -m module.oppo.ocpc.model_client --server 10.12.184.34:9000
  --work_dir /home/devops/gpudata/xyang/deep_cross/serving_data.txt server_model_name v1
  --num_tests 1 --feature_schema_file /home/devops/gpudata/tfrecord/schema.csv
"""

from ...base.client_utils import client_test
from .model_v0 import BaseOPPOCVRModel


if __name__ == '__main__':
    BaseOPPOCVRModel.voc_emb_size = BaseOPPOCVRModel.load_voc_summary()
    client_test(BaseOPPOCVRModel)
