#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
build and train model
"""

import tensorflow as tf
from ..base.trainer import train
from .build_model import build_model
from ..base.build_graph_utils import graph_add_collection


def main(unused=None):
    flags = tf.app.flags.FLAGS
    model = build_model(flags)
    # coord = tf.train.Coordinator()
    model.build()
    graph_add_collection(model)
    train(model)


if __name__ == "__main__":
    tf.app.run(main)
