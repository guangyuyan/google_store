#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Load graph and do training
"""

from .kaggle_trainable import KaggleTrainable
from ..base.trainer import train
import tensorflow as tf


def main(unused=None):
    flags = tf.app.flags.FLAGS
    model = KaggleTrainable(flags)
    model.load_graph_from_file()
    train(model)


if __name__ == '__main__':
    tf.app.run(main)
