#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V7:
    cross: bin(BN(dense)) + bin(embedding)
    shallow: BN(dense)

WARNING:tensorflow:Eval    4583424 loss=0.471526067594 roc = 0.777000546455 rate=151502.051375
WARNING:tensorflow:A better loss 0.471526067594 found at /ssd/criteo/outputs/v7_best, steps=166004

WARNING:tensorflow:Eval    4583424 loss=0.488882147282 roc = 0.751404345036 rate=155805.29249
WARNING:tensorflow:A better loss 0.488882147282 found at /ssd/criteo/outputs/v7.sp_best, steps=39059

WARNING:tensorflow:Eval    4583424 loss=0.482426026804 roc = 0.761474370956 rate=158209.319974
WARNING:tensorflow:A better loss 0.482426026804 found at /ssd/criteo/outputs/v7.renorm_best, steps=39059

WARNING:tensorflow:Eval    4583424 loss=0.475218355556 roc = 0.770909786224 rate=148154.583952
WARNING:tensorflow:A better loss 0.475218355556 found at /ssd/criteo/outputs/v7.sp.renorm_best, steps=78119
"""


import tensorflow as tf
from .model_v6 import DeepFastBinaryQuadCrossModel


class FastBinaryQuadCrossModel(DeepFastBinaryQuadCrossModel):
    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        outputs = raw_inputs[0]
        return outputs
