#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
V1:
    cross: BN(dense) + embedding
    deep: BN(dense) + embedding

WARNING:tensorflow:Eval    4583424 loss=0.443976968986 roc = 0.807885587215 rate=172292.89067
WARNING:tensorflow:A better loss 0.443976968986 found at /ssd/criteo/outputs/v1_best

WARNING:tensorflow:Eval    4583424 loss=0.44395586279 roc = 0.807891726494 rate=177785.838891
WARNING:tensorflow:A better loss 0.44395586279 found at /ssd/criteo/outputs/v1.sp_best

WARNING:tensorflow:Eval    4583424 loss=0.443865011642 roc = 0.807922542095 rate=178787.533263
WARNING:tensorflow:A better loss 0.443865011642 found at /ssd/criteo/outputs/v1.renorm_best around step 78125

WARNING:tensorflow:Eval    4583424 loss=0.444042322829 roc = 0.807768404484 rate=177989.390292
WARNING:tensorflow:A better loss 0.444042322829 found at /ssd/criteo/outputs/v1.sp.renorm_best

Hyperparameters search in original paper:
    cross layer depth: 1~6
    deep layer depth: 2~5
    deep layer size: 32~1024
    batch normalization: continuous and categorical
    deep layer gradient clip: 100
    learning rate: 0.0001~0.001
    batch size: 512
    early stop step: 150000
    seperate emb for each categorical feature: True
    total emb size: 1026
    optimizer: Adam
Optimal parameters in original paper:
    cross layer depth: 6
    deep layer depth: 2
    deep layer size: 1024
model_v1:
    cross layer depth: 2
    deep layer depth: 3
    deep layer size: 100,80,40
    batch normalization: continuous
    deep layer gradient clip: N/A
    learning rate: 0.0001
    batch size: 256*4
    early stop step: N/A
    seperate emb for each categorical feature: False
    total emb size: 26*50
    optimizer: Adam
"""


import tensorflow as tf

from .model_v0 import BaseKaggleDeepCrossModel


class DeepCrossModel(BaseKaggleDeepCrossModel):
    def __init__(self, flags):
        super(DeepCrossModel, self).__init__(flags)
        self.dense_min = tf.Variable([0, -3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                                     dtype=tf.float32)
        self.dense_max = tf.Variable(
            [20, 600, 100, 50, 64000, 500, 100, 50, 500, 10, 10, 10, 50],
            dtype=tf.float32)
        self.dense_norm = self.dense_max - self.dense_min

    def build_network(self, features):
        fv = features['continuous']
        ids = features['categorical']
        with tf.device('/gpu:0'):
            ev = self.build_embedding_layer(ids)
            fv = self.build_dense_layer(fv)
            inputs = self.concat([fv, ev])
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            return tf.concat([deep_out, cross_out], -1)

    def build_embedding_layer(self, ids):
        return self.embedding(ids, "embedding", None)

    def get_dense_max(self):
        return self.dense_max

    def get_dense_min(self):
        return self.dense_min

    def get_dense_norm(self):
        return self.dense_norm

    def build_dense_layer(self, fv):
        return self.BN(fv)

    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)

    def build_cross(self, raw_inputs, num_layers=3):
        return self.cross_net(raw_inputs, num_layers,
                              use_bias=self.flags.cross_bias,
                              sparse=self.flags.sparse_cross)
