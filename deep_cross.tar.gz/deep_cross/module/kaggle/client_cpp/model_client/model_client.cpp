/*
 * model_client.cpp
 * Copyright (C) 2018- CloudBrain <byzhang@>

 Bazel build and run from WORKSPACE directory:
build: bazel build -c opt --define=grpc_no_ares=true //model_client:model_client_cc
run: OMP_NUM_THREADS=4 bazel-bin//model_client/model_client_cc --batch_size=1

*/

#include <algorithm>
#include <assert.h>
#include <chrono>
#include <mutex>
#include <sstream>  //std::stringstream

#include "grpc++/create_channel.h"
#include "grpc++/security/credentials.h"
#include "google/protobuf/map.h"
#include "tensorflow/core/example/example.pb.h"
#include "tensorflow/core/framework/tensor.h"
#include "tensorflow/core/lib/core/errors.h"
#include "tensorflow/core/lib/core/status.h"
#include "tensorflow/core/lib/io/compression.h"
#include "tensorflow/core/lib/io/record_reader.h"
#include "tensorflow/core/util/command_line_flags.h"
#include "tensorflow_serving/apis/prediction_service.grpc.pb.h"

#define PREBATCH 256
#define DENSEFEATURES 13
#define SPARSEFEATURES 26

int omp_get_num_threads();
int omp_get_thread_num();

using grpc::Channel;
using grpc::ClientContext;
//Refer to https://github.com/grpc/grpc/blob/34e8e0a6400d8b529125a3b83ec1facf71acf99b/include/grpcpp/impl/codegen/client_context.h
//for the deadline of Client Call Predict

using tensorflow::serving::PredictRequest;
using tensorflow::serving::PredictResponse;
using tensorflow::serving::PredictionService;

typedef google::protobuf::Map<tensorflow::string, tensorflow::TensorProto> ProtoMap;
typedef google::protobuf::Map<std::string, tensorflow::Feature> FeatureMap;

class MyRecordReader {
 public:
  MyRecordReader(const tensorflow::string &file_name, int buf_size)
    : offset_(0), tensor_size_(0){
        TF_CHECK_OK(tensorflow::Env::Default()->NewRandomAccessFile(
                  file_name, &input_file_));
    tensorflow::io::RecordReaderOptions options =
      tensorflow::io::RecordReaderOptions::CreateRecordReaderOptions(
        tensorflow::io::compression::kGzip);
    options.zlib_options.input_buffer_size = buf_size;
    reader_ = std::unique_ptr<tensorflow::io::RecordReader>(
                new tensorflow::io::RecordReader(input_file_.get(), options));
  }
  void recordsToTensorProto(std::vector<tensorflow::Example> &records){
    int record_num = records.size();
    tensorflow::TensorProto conti_proto;
    tensorflow::TensorProto cate_proto;
    conti_proto.set_dtype(tensorflow::DataType::DT_FLOAT);
    cate_proto.set_dtype(tensorflow::DataType::DT_INT64);
    for(int  i = 0; i < record_num; ++i){
      const FeatureMap& features = records[i].mutable_features()->feature();
      assert(features.size()==3);
      const tensorflow::FloatList& denselist = features.at("dense").float_list();
      int densesize = denselist.value_size();
      for(int i = 0; i < densesize; ++i) {
        conti_proto.add_float_val(denselist.value(i));
      }
      const tensorflow::Int64List& sparselist = features.at("sparse").int64_list();
      int sparsesize = sparselist.value_size();
      for(int i = 0; i < sparsesize; ++i) {
        cate_proto.add_int64_val(sparselist.value(i));
      }
    }
    conti_proto.mutable_tensor_shape()->add_dim()->set_size(
        PREBATCH*record_num);
    conti_proto.mutable_tensor_shape()->add_dim()->set_size(DENSEFEATURES);
    cate_proto.mutable_tensor_shape()->add_dim()->set_size(
        PREBATCH*SPARSEFEATURES*record_num);
    cate_proto.mutable_tensor_shape()->add_dim()->set_size(1);
    conti_protos_.push_back(std::move(conti_proto));
    cate_protos_.push_back(std::move(cate_proto));
    ++tensor_size_;
  }
  int loadTensorProtosFromFile(tensorflow::int64 batch_size, tensorflow::int64 num_tests){
    std::cerr<<"Loading from file with batch_size = "<<batch_size<<std::endl;
    tensorflow::string stringrecord;
    bool fileEnd = false;
    for(int i=0; i<num_tests&&!fileEnd; ++i){
      std::vector<tensorflow::Example> records;
      for(int record_num = 0; record_num < batch_size; ++record_num){
        tensorflow::Status s = reader_->ReadRecord(&offset_, &stringrecord);
        if(!s.ok()){
          std::cerr<<s.error_message()<<std::endl;
          fileEnd = true;
          break;
        }
        tensorflow::Example record;
        record.ParseFromString(stringrecord);
        records.push_back(std::move(record));
      }
      recordsToTensorProto(records);
    }
    std::cerr<<"Loading size: "<<tensor_size_<<std::endl;
    return tensor_size_;
  }
  bool getTensorProtofromReader(ProtoMap& inputs, int i) {
    if(i < 0 || i >= tensor_size_) return false;
    inputs["continuous"] = std::move(conti_protos_[i]);
    inputs["categorical"] = std::move(cate_protos_[i]);
    return true;
  }

 private:
  std::unique_ptr<tensorflow::RandomAccessFile> input_file_;
  std::unique_ptr<tensorflow::io::RecordReader> reader_;
  tensorflow::uint64 offset_;
  int tensor_size_;
  std::vector<tensorflow::TensorProto> conti_protos_;
  std::vector<tensorflow::TensorProto> cate_protos_;
};

class ServingClient {
 public:
  ServingClient(std::shared_ptr<Channel> channel)
    : total_prepare_time_(0.0), stub_(PredictionService::NewStub(channel)){}

  void insertTime(const double& time){
    time_mutex_.lock();
    time_cost_.push_back(time);
    time_mutex_.unlock();
  }
  void sortTime(){
    sort(time_cost_.begin(), time_cost_.end());
  }
  double getAverageTimeCost(){
    double total = 0.0;
    for(auto t : time_cost_){
      total += t;
    }
    return total/time_cost_.size();
  }
  double getThe90MaxTime(){
    return time_cost_[int(time_cost_.size()*0.9)];
  }
  double getMaxTime(){
    return time_cost_.back();
  }
  double getMinTime(){
    return time_cost_.front();
  }
  double getAvePrepareTime(){
    return total_prepare_time_/time_cost_.size();
  }
  void callPredict(const tensorflow::string& model_name,
                  const tensorflow::string& model_signature_name,
                  MyRecordReader &reader, bool print, int i){
    PredictRequest request;
    PredictResponse response;
    ClientContext context;
    bool nempty = reader.getTensorProtofromReader(*request.mutable_inputs(), i);
    if(!nempty){
      std::cout<<"No More Tensor Proto in RecordReader!\n";
      return;
    }
    request.mutable_model_spec()->set_name(model_name);
    request.mutable_model_spec()->set_signature_name(
      model_signature_name);
    std::chrono::high_resolution_clock::time_point start =
      std::chrono::high_resolution_clock::now();
    grpc::Status status = stub_->Predict(&context, request, &response);
    std::chrono::high_resolution_clock::time_point end =
      std::chrono::high_resolution_clock::now();
    double duration = std::chrono::duration_cast
      <std::chrono::microseconds>(end-start).count()/1000.0;
    insertTime(duration);
    if(status.ok()) {
      int index = 0;
      ProtoMap& outputs = *response.mutable_outputs();
      for(auto iter = outputs.begin(); iter!=outputs.end(); ++iter) {
        tensorflow::TensorProto& result_tensor_proto = iter->second;
        tensorflow::Tensor tensor;
        if(print){
        if(tensor.FromProto(result_tensor_proto)) {
          std::cout<<"The result tensor[" << index << "] is: "
                   << tensor.SummarizeValue(tensor.NumElements()) << std::endl;
        } else {
          std::cout<<"The result tensor[" << index <<"] convert failed\n";
        }
        }
        ++index;
      }
    } else {
      std::cout<<"gRPC failed, return code: " << status.error_code() <<": "
               << status.error_message() << std::endl;
    }
  }
 private:
  std::unique_ptr<PredictionService::Stub> stub_;
  std::vector<double> time_cost_;
  double total_prepare_time_;
  std::mutex time_mutex_;
};

int main(int argc, char **argv) {
  tensorflow::int64 batch_size = 2;
  tensorflow::int64 num_tests = 2000;
  tensorflow::string file_name = "/ssd/users/xjfan/valid_256_compress.tfrecords";
  tensorflow::string server_port = "localhost:9000";
  tensorflow::string model_name = "model_v8";
  tensorflow::string model_signature_name = "predict_label";
  std::vector<tensorflow::Flag> flag_list = {
    tensorflow::Flag("batch_size", &batch_size, "The batch size for predictor"),
    tensorflow::Flag("num_tests", &num_tests, "The num of predict request"),
    tensorflow::Flag("file_name", &file_name, "name of input file"),
    tensorflow::Flag("server_port", &server_port, "IP and port of server"),
    tensorflow::Flag("model_name", &model_name, "name of model"),
    tensorflow::Flag("model_signature_name", &model_signature_name,
    "name of model signature")
  };
  tensorflow::string usage = tensorflow::Flags::Usage(argv[0], flag_list);
  const bool parse_result = tensorflow::Flags::Parse(&argc, argv, flag_list);
  if (!parse_result) {
    std::cout << usage;
    return -1;
  }

  int num_threads;
  #pragma omp parallel
  {
    num_threads = omp_get_num_threads();
  }
  std::cout<<"OMP threads num = "<<num_threads<<std::endl;

  ServingClient guide(
    grpc::CreateChannel(server_port, grpc::InsecureChannelCredentials()));

  MyRecordReader reader(file_name, 1 << 30);//buf_size!=0, sequentialRead, buf_size=0, randomRead
  int size = reader.loadTensorProtosFromFile(batch_size, num_tests);

  #pragma omp parallel for
  for(int i = 0; i < size; ++i){
    guide.callPredict(model_name, model_signature_name, reader, false, i);
  }
  guide.sortTime();
  std::cout<<"The Average Prepare Time: "<<guide.getAvePrepareTime()<<"us, ";
  std::cout<<"The 90% Max Time: "<<guide.getThe90MaxTime()<<"ms, ";
  std::cout<<"The Max Time: "<< guide.getMaxTime()<<"ms, ";
  std::cout<<"The Average Time: " << guide.getAverageTimeCost()<<"ms, ";
  std::cout<<"The Min Time: "<<guide.getMinTime()<<"ms"<<std::endl;
  return 0;
}
