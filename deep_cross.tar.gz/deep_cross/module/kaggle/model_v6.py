#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V6:
    cross: bin(BN(dense)) + bin(embedding)
    deep: BN(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.453125144817 roc = 0.797476351261 rate=121008.724904
WARNING:tensorflow:A better loss 0.453125144817 found at /ssd/criteo/outputs/v6_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.454216383431 roc = 0.796270549297 rate=121009.510982
WARNING:tensorflow:A better loss 0.454216383431 found at /ssd/criteo/outputs/v6.sp_best, steps=87884

WARNING:tensorflow:Eval    4583424 loss=0.452946939194 roc = 0.797559976578 rate=126067.697619
WARNING:tensorflow:A better loss 0.452946939194 found at /ssd/criteo/outputs/v6.renorm_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.452750234637 roc = 0.797768831253 rate=121369.972584
WARNING:tensorflow:A better loss 0.452750234637 found at /ssd/criteo/outputs/v6.sp.renorm_best, steps=117179
"""


from .model_v11 import OriginalDeepCrossModel


class DeepFastBinaryQuadCrossModel(OriginalDeepCrossModel):
    def build_embedding_layer(self, ids):
        return self.embedding(ids, "embedding", 10)

    def build_cross(self, raw_inputs, num_layers=3):
        bucked_dense = self.binary_dense(raw_inputs[0])
        binary_sparse = self.binary_embedding(raw_inputs[1])
        return super(DeepFastBinaryQuadCrossModel, self).build_cross(
            [bucked_dense, binary_sparse], num_layers)
