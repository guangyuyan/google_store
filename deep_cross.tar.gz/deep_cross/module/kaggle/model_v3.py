#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V3:
    cross: BN(dense) + bin(embedding)
    deep: BN(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.452956892969 roc = 0.797762513161 rate=156541.511242
WARNING:tensorflow:A better loss 0.452956892969 found at /ssd/criteo/outputs/v3_best

WARNING:tensorflow:Eval    4583424 loss=0.453910003379 roc = 0.796402513981 rate=97794.109433
WARNING:tensorflow:A better loss 0.453910003379 found at /ssd/criteo/outputs/v3.sp_best

WARNING:tensorflow:A better loss 0.453901538367 found at /ssd/criteo/outputs/v3.renorm_best, steps=87884
WARNING:tensorflow:  94382080 loss=0.463383585215 roc=0.802992165089 rate=61181.2803558

WARNING:tensorflow:Eval    4583424 loss=0.452882376071 roc = 0.797756373882 rate=158856.251409
WARNING:tensorflow:A better loss 0.452882376071 found at /ssd/criteo/outputs/v3.sp.renorm_best, steps=117179
"""


from .model_v11 import OriginalDeepCrossModel


class DeepFastBinaryCrossModel(OriginalDeepCrossModel):
    def build_embedding_layer(self, ids):
        return self.embedding(ids, "embedding", 10)

    def build_cross(self, raw_inputs, num_layers=3):
        return super(DeepFastBinaryCrossModel, self).build_cross(
            [raw_inputs[0], self.binary_embedding(raw_inputs[1])], num_layers)
