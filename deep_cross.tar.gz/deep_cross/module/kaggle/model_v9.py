#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V9:
    cross: bin(dense) + bin(embedding)
    deep: bin(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.454738322982 roc = 0.795367896557 rate=118471.736456
WARNING:tensorflow:A better loss 0.454738322982 found at /ssd/criteo/outputs/v9.1_best, steps=87884

WARNING:tensorflow:Eval    4583424 loss=0.454452914403 roc = 0.795670747757 rate=113791.853541
WARNING:tensorflow:A better loss 0.454452914403 found at /ssd/criteo/outputs/v9.1.sp_best, steps=87884

WARNING:tensorflow:Eval    4583424 loss=0.453364255514 roc = 0.79690605402 rate=115150.580763
WARNING:tensorflow:A better loss 0.453364255514 found at /ssd/criteo/outputs/v9.1.renorm_best, steps=136709

WARNING:tensorflow:Eval    4583424 loss=0.454271115989 roc = 0.795814454556 rate=114749.269323
WARNING:tensorflow:A better loss 0.454271115989 found at /ssd/criteo/outputs/v9.1.sp.renorm_best, steps=87884
"""


from .model_v3 import DeepFastBinaryCrossModel


class BinaryDeepCrossModel(DeepFastBinaryCrossModel):
    def build_dense_layer(self, fv):
        return self.binary_dense(fv)
