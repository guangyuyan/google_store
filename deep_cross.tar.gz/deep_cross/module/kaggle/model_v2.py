#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
deep & binary cross model DEPRECATED
it avoids self-self cross, but uses too much memory.
"""


import numpy as np
import tensorflow as tf
from .model_v1 import DeepCrossModel


def mask_diag(*dims):
    """Create a block diagonal mask matrix from the provided dims.

    Examples
    --------
    >>> print(mask_diag(1, 2, 3))
    [[0 1 1 1 1 1]
     [1 0 0 1 1 1]
     [1 0 0 1 1 1]
     [1 1 1 0 0 0]
     [1 1 1 0 0 0]
     [1 1 1 0 0 0]]

    """
    out = np.ones((np.sum(dims), np.sum(dims)))

    idx = 0
    for _, dim in enumerate(dims):
        out[idx:idx + dim, idx:idx + dim] = np.zeros(dim)
        idx += dim
    out = tf.convert_to_tensor(out, tf.float32)
    return out


class DeepBinaryCrossModel(DeepCrossModel):
    def build_cross(self, raw_inputs, num_layers=3):
        dims = [x.get_shape()[-1].value for x in raw_inputs]
        mask = mask_diag(*dims)
        mask = tf.expand_dims(mask, 0)

        inputs = tf.concat(raw_inputs, -1)
        dim = inputs.get_shape()[-1]
        t = tf.sigmoid(inputs)
        for i in range(num_layers):
            c = tf.matmul(tf.expand_dims(t, 2), tf.expand_dims(t, 1))
            masked = tf.multiply(c, mask)
            weight = tf.get_variable(
                name='cross_weight_{}'.format(i), shape=[1, dim],
                dtype=tf.float32, initializer=tf.random_normal_initializer())
            reshaped = tf.reshape(masked, [-1, dim])
            product = tf.matmul(weight, tf.transpose(reshaped))
            t += tf.reshape(product, [-1, dim])
        return t
