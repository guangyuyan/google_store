#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build model
"""


from . import model_v1
from . import model_v3
from . import model_v4
from . import model_v5
from . import model_v6
from . import model_v7
from . import model_v8
from . import model_v9
from . import model_v10
from . import model_v11
from . import model_v12
from . import model_v13
from . import model_v14
from . import model_v15
from . import model_v16
from . import model_v17
from . import model_v18
from . import model_v19
from . import model_v20

import tensorflow as tf


def build_model(flags):
    if flags.model == 'v1':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v1.DeepCrossModel(flags)
    elif flags.model == 'v3':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v3.DeepFastBinaryCrossModel(flags)
    elif flags.model == 'v4':
        model = model_v4.BinaryDenseDeepCrossModel(flags)
    elif flags.model == 'v5':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v5.DeepBinaryDenseCrossModel(flags)
    elif flags.model == 'v6':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v6.DeepFastBinaryQuadCrossModel(flags)
    elif flags.model == 'v7':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v7.FastBinaryQuadCrossModel(flags)
    elif flags.model == 'v9':
        model = model_v9.BinaryDeepCrossModel(flags)
    elif flags.model == 'v11':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v11.OriginalDeepCrossModel(flags)
    elif flags.model == 'v12':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v12.DeepCrossFMModel(flags)
    elif flags.model == 'v13':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v13.DeepBinaryDenseCrossFMModel(flags)
    elif flags.model == 'v14':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v14.DeepCrossBNFMModel(flags)
    elif flags.model == 'v15':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v15.StackDeepCrossBNFMModel(flags)
    elif flags.model == 'v10':
        model = model_v10.OriginalDeepCrossModel2(flags)
    elif flags.model == 'v8':
        model = model_v8.DeepCrossModel2(flags)
    elif flags.model == 'v16':
        model = model_v16.DeepFastBinaryCrossModel2(flags)
    elif flags.model == 'v17':
        model = model_v17.DeepBinaryDenseCrossModel2(flags)
    elif flags.model == 'v18':
        model = model_v18.DeepFastBinaryQuadCrossModel2(flags)
    elif flags.model == 'v19':
        tf.app.flags.FLAGS.normalize_dense = True
        model = model_v19.DeepCrossFMModel2(flags)
    elif flags.model == 'v20':
        model = model_v20.DeepCrossFMModel3(flags)
    return model
