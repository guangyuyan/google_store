#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V4:
    cross: bin(dense) + embedding
    deep: bin(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.446754855421 roc = 0.805015146732 rate=115016.02739
WARNING:tensorflow:A better loss 0.446754855421 found at /ssd/criteo/outputs/v4.1_best, steps=58589

WARNING:tensorflow:Eval    4583424 loss=0.447348559523 roc = 0.8041421175 rate=114254.752407
WARNING:tensorflow:A better loss 0.447348559523 found at /ssd/criteo/outputs/v4.1.sp_best, steps=58589

WARNING:tensorflow:Eval    4583424 loss=0.446937373572 roc = 0.804923295975 rate=114174.582918
WARNING:tensorflow:A better loss 0.446937373572 found at /ssd/criteo/outputs/v4.1.renorm_best, steps=58589

WARNING:tensorflow:Eval    4583424 loss=0.446424039941 roc = 0.805292546749 rate=115408.334509
WARNING:tensorflow:A better loss 0.446424039941 found at /ssd/criteo/outputs/v4.1.sp.renorm_best, steps=58589
"""


from .model_v11 import OriginalDeepCrossModel


class BinaryDenseDeepCrossModel(OriginalDeepCrossModel):
    def build_dense_layer(self, fv):
        return self.binary_dense(fv)
