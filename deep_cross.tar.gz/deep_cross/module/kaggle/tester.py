#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <huangs@>
#
# Distributed under terms of the CloudBrain license.
"""
./tester.py --model_dir=./checkpoint --model_prefix=v1_best --test_file=./data/sample/test.100K.tf --out_file=./output/predict
WARNING:tensorflow:model loaded in 3.0985 seconds
WARNING:tensorflow:92160 samples processed, avg throughput so far = 29614.49
WARNING:tensorflow:total samples=99840, avg throughput=29639.62
on laptop, 1 CPU w/ 2 cores, model v1 about 6K at training and 30K at testing and 25K at validating
"""
import os
import time
import tensorflow as tf
from reader import tfrecord_pipeline


tf.app.flags.DEFINE_string('model_dir', None, 'model file directory')
tf.app.flags.DEFINE_string('model_prefix', None, 'model file prefix')
tf.app.flags.DEFINE_string('test_file', None, 
        'full path to testing file, in tfrecords format')
tf.app.flags.DEFINE_string('out_file', None, 
        'full path to output/prediction file')
tf.app.flags.DEFINE_float('cutoff', 0.5, 'cutoff used for binary prediction')
tf.app.flags.DEFINE_integer('batch', 4, 'batch size')
tf.app.flags.DEFINE_integer('prebatch', 256, 'prebatch size')
tf.app.flags.DEFINE_integer('steps_per_trace', 20, 'steps before trace')
tf.app.flags.DEFINE_bool('clear_devices', True, 
        'whether to clear device info in a graph')


def inference(unused_arg):
    flags = tf.app.flags.FLAGS

    with tf.Session() as sess:
        # restore the saved model
        start_time = time.time()
        meta_file = os.path.join(flags.model_dir, '%s.meta' % flags.model_prefix)
        saver = tf.train.import_meta_graph(meta_file, flags.clear_devices)
        model_file = os.path.join(flags.model_dir, '%s' % flags.model_prefix)
        saver.restore(sess, model_file)
        tf.logging.warn('model loaded in {:.4f} seconds'
                .format((time.time()-start_time)))

        g = sess.graph
        output = g.get_tensor_by_name('predict/Sigmoid:0')
        binary_output = tf.cast(tf.greater(output, flags.cutoff), tf.int64)
        continuous_features = g.get_tensor_by_name('continuous:0')
        categorical_features = g.get_tensor_by_name('categorical:0')
        is_training = g.get_tensor_by_name('training:0')

        iterator = tfrecord_pipeline(flags.test_file, flags.batch, flags.prebatch, 
                epochs=1, shuffle=False)
        one_element = iterator.get_next()

        sess.run(iterator.initializer)
        n_samples = 0
        steps = 0
        out_dir = os.path.dirname(flags.out_file)
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)

        start_time = time.time()
        with open(flags.out_file, 'w') as f:
            try:
                while True:
                    _, fv, ids = sess.run(one_element)
                    feed_dict = {
                            continuous_features: 
                                fv.reshape([-1, flags.dense_features]), 
                            categorical_features: ids.reshape([-1, 1]), 
                            is_training: False
                            }
                    _, bo = sess.run([output, binary_output], feed_dict=feed_dict)
                    n_samples += len(bo)
                    f.write('%s\n' % ('\n'.join(['%d' % pred for pred in bo.flat])))
                    f.flush()
                    steps += 1
                    if steps % flags.steps_per_trace == 0:
                        throughput = 1.0 * n_samples / (time.time() - start_time)
                        tf.logging.warn(
                                '{} samples processed, avg throughput so far = {:.2f}'
                                .format(n_samples,throughput))
            except tf.errors.OutOfRangeError:
                tf.logging.warn('done reading data')

        throughput = 1.0 * n_samples / (time.time() - start_time)
        tf.logging.warn('total samples {}, avg throughput {:.2f}'
                .format(n_samples, throughput))
        tf.logging.warn('predictions in {}'.format(flags.out_file))


if __name__ == '__main__':
    tf.flags.mark_flags_as_required(['model_dir', 'model_prefix',
        'test_file', 'out_file'])
    tf.app.run(inference)
