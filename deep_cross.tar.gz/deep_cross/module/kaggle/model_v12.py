#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V12:
    cross: BN(dense) + embedding
    deep: BN(dense) + BN(embedding)
    fm: BN(dense) + embedding

WARNING:tensorflow:Eval    4583424 loss=0.445878228218 roc = 0.806084752083 rate=153884.041211
WARNING:tensorflow:A better loss 0.445878228218 found at /ssd/criteo/outputs/v12.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445785814285 roc = 0.806249201298 rate=151398.636172
WARNING:tensorflow:A better loss 0.445785814285 found at /ssd/criteo/outputs/v12.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445730192272 roc = 0.806309580803 rate=153833.998713
WARNING:tensorflow:A better loss 0.445730192272 found at /ssd/criteo/outputs/v12.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445781238171 roc = 0.806234478951 rate=154418.267274
WARNING:tensorflow:A better loss 0.445781238171 found at /ssd/criteo/outputs/v12.1.sp.renorm_best, steps=78119
"""


import tensorflow as tf

from .model_v11 import OriginalDeepCrossModel


class DeepCrossFMModel(OriginalDeepCrossModel):
    def build_network(self, features):
        fv = features['continuous']
        ids = features['categorical']
        with tf.device('/gpu:0'):
            ev = self.build_embedding_layer(ids)
            fv = self.build_dense_layer(fv)
            inputs = self.concat([fv, ev])
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            if self.flags.fm_order > 0:
                fm_out = self.build_fm(inputs)
                output = [deep_out, cross_out, fm_out]
            else:
                output = [deep_out, cross_out]
            return tf.concat(output, -1)

    def build_fm(self, raw_inputs):
        return self.fm_net(raw_inputs, order=self.flags.fm_order,
                           rank=self.flags.fm_rank)
