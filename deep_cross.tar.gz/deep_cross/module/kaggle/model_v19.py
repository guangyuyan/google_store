#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V19:
    cross: BN(dense) + embedding
    deep: BN(dense) + embedding
    fm: BN(dense) + embedding

WARNING:tensorflow:Eval    4583424 loss=0.444200154064 roc = 0.807840943336 rate=106542.382384
WARNING:tensorflow:A better loss 0.444200154064 found at /ssd/criteo/outputs/v19.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444173251929 roc = 0.807813882828 rate=85554.1890509
WARNING:tensorflow:A better loss 0.444173251929 found at /ssd/criteo/outputs/v19.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444237089076 roc = 0.807766020298 rate=111028.983812
WARNING:tensorflow:A better loss 0.444237089076 found at /ssd/criteo/outputs/v19.1.renorm_best, steps=87884

WARNING:tensorflow:Eval    4583424 loss=0.444207486394 roc = 0.807832956314 rate=83664.7457947
WARNING:tensorflow:A better loss 0.444207486394 found at /ssd/criteo/outputs/v19.1.sp.renorm_best, steps=78119
"""


import tensorflow as tf

from .model_v1 import DeepCrossModel


class DeepCrossFMModel2(DeepCrossModel):
    def build_network(self, features):
        fv = features['continuous']
        ids = features['categorical']
        with tf.device('/gpu:0'):
            ev = self.build_embedding_layer(ids)
            fv = self.build_dense_layer(fv)
            inputs = self.concat([fv, ev])
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            if self.flags.fm_order > 0:
                fm_out = self.build_fm(inputs)
                output = [deep_out, cross_out, fm_out]
            else:
                output = [deep_out, cross_out]
            return tf.concat(output, -1)

    def build_fm(self, raw_inputs):
        return self.fm_net(raw_inputs, order=self.flags.fm_order,
                           rank=self.flags.fm_rank)
