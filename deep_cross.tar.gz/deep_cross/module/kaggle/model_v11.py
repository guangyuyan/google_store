#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Reproduce original deep & cross model
V11:
    cross: BN(dense) + embedding
    deep: BN(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.445588691784 roc = 0.806269705296 rate=163043.658278
WARNING:tensorflow:A better loss 0.445588691784 found at /ssd/criteo/outputs/v11_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.44575868794 roc = 0.806252837181 rate=158206.21344
WARNING:tensorflow:A better loss 0.44575868794 found at /ssd/criteo/outputs/v11.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445762294294 roc = 0.806232988834 rate=159533.87442
WARNING:tensorflow:A better loss 0.445762294294 found at /ssd/criteo/outputs/v11.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445805139913 roc = 0.806247472763 rate=157779.425852
WARNING:tensorflow:A better loss 0.445805139913 found at /ssd/criteo/outputs/v11.sp.renorm_best, steps=78119

Original paper parameters:
    continous feature process: log
    cross layer depth: 6
    deep layer depth: 2
    deep layer size: 1024
    batch normalization: continuous and categorical
    deep layer gradient clip: 100
    learning rate: 0.0001
    batch size: 512
    early stop step: 150000
    seperate emb for each categorical feature: True
    total emb size: 1026
    optimizer: Adam
model_v11 parameters:
    continous feature process: min-max normalization with clip
    cross layer depth: 6
    deep layer depth: 2
    deep layer size: 1024
    batch normalization: continuous and categorical
    deep layer gradient clip: N/A
    learning rate: 0.0001
    batch size: 256*4
    early stop step: 5 epochs
    seperate emb for each categorical feature: False
    total emb size: 26*50
    optimizer: Adam
"""


import tensorflow as tf

from .model_v1 import DeepCrossModel


class OriginalDeepCrossModel(DeepCrossModel, object):
    '''
    reproduce DCN in https://arxiv.org/abs/1708.05123
    '''

    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        raw_inputs = [raw_inputs[0], self.BN(raw_inputs[1])]
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)
