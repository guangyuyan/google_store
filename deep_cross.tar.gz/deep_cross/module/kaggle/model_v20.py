#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V20:
    cross: dense + embedding
    deep: dense + embedding
    fm: dense + embedding

WARNING:tensorflow:Eval    4583424 loss=0.444862348624 roc = 0.807353198528 rate=159223.028001
WARNING:tensorflow:A better loss 0.444862348624 found at /ssd/criteo/outputs/v20.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444516655214 roc = 0.807571172714 rate=161577.926329
WARNING:tensorflow:A better loss 0.444516655214 found at /ssd/criteo/outputs/v20.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444563682513 roc = 0.80757266283 rate=165073.967841
WARNING:tensorflow:A better loss 0.444563682513 found at /ssd/criteo/outputs/v20.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444683735483 roc = 0.807431817055 rate=165363.687342
WARNING:tensorflow:A better loss 0.444683735483 found at /ssd/criteo/outputs/v20.1.sp.renorm_best, steps=78119
"""


from .model_v19 import DeepCrossFMModel2


class DeepCrossFMModel3(DeepCrossFMModel2):
    def build_dense_layer(self, fv):
        return fv
