#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V15:
    cross: BN(dense) + embedding
    deep: BN(dense) + BN(embedding)
    fm: BN(dense) + BN(embedding)

    deep: BN(deep + fm) + BN(cross)

WARNING:tensorflow:Eval    4583424 loss=0.445542336849 roc = 0.806670486927 rate=76059.1243221
WARNING:tensorflow:A better loss 0.445542336849 found at /ssd/criteo/outputs/v15.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445433183279 roc = 0.806729137897 rate=76478.508319
WARNING:tensorflow:A better loss 0.445433183279 found at /ssd/criteo/outputs/v15.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445895543733 roc = 0.80647867918 rate=82169.8551922
WARNING:tensorflow:A better loss 0.445895543733 found at /ssd/criteo/outputs/v15.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445787968568 roc = 0.806490182877 rate=113223.493091
WARNING:tensorflow:A better loss 0.445787968568 found at /ssd/criteo/outputs/v15.1.sp.renorm_best, steps=78119
"""


import tensorflow as tf

from .model_v14 import DeepCrossBNFMModel


class StackDeepCrossBNFMModel(DeepCrossBNFMModel):
    def one_layer_network(self, inputs, enable_fm):
        with tf.device('/gpu:0'):
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=self.flags.cross_layers)
            if enable_fm:
                fm_out = self.build_fm(inputs)
                output = [tf.concat([deep_out, fm_out], -1), cross_out]
            else:
                output = [deep_out, cross_out]
        return output

    def build_network(self, features):
        fv = features['continuous']
        ids = features['categorical']
        with tf.device('/gpu:0'):
            ev = self.build_embedding_layer(ids)
            fv = self.build_dense_layer(fv)
            inputs = self.concat([fv, ev])
            inputs = self.one_layer_network(inputs, self.flags.fm_order > 0)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            return self.build_deep(
                [self.build_dense_layer(inputs[0]), inputs[1]],
                hidden=hidden)
            # output = self.one_layer_network(
            #     [self.build_dense_layer(inputs[0]), inputs[1]], False)
            # # output = self.one_layer_network(inputs)
            # return tf.concat(output, -1)
