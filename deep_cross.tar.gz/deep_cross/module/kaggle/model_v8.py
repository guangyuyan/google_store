#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V8:
    cross: dense + embedding
    deep: dense + embedding

WARNING:tensorflow:Eval    4583424 loss=0.44462118951 roc = 0.807581245899 rate=174621.909904
WARNING:tensorflow:A better loss 0.44462118951 found at /ssd/criteo/outputs/v8.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444609330749 roc = 0.807526350021 rate=173575.891808
WARNING:tensorflow:A better loss 0.444609330749 found at /ssd/criteo/outputs/v8.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.444635816984 roc = 0.807500720024 rate=179086.050525
WARNING:tensorflow:A better loss 0.444635816984 found at /ssd/criteo/outputs/v8.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445736299837 roc = 0.80574297905 rate=174481.674247
WARNING:tensorflow:A better loss 0.445736299837 found at /ssd/criteo/outputs/v8.1.sp.renorm_best, steps=48824
"""


from .model_v1 import DeepCrossModel


class DeepCrossModel2(DeepCrossModel):
    def build_dense_layer(self, fv):
        return fv
