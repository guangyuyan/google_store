#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V14:
    cross: BN(dense) + embedding
    deep: BN(dense) + BN(embedding)
    fm: BN(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.446050614685 roc = 0.805843830109 rate=150841.7347
WARNING:tensorflow:A better loss 0.446050614685 found at /ssd/criteo/outputs/v14.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445652892252 roc = 0.806378722191 rate=152635.419902
WARNING:tensorflow:A better loss 0.445652892252 found at /ssd/criteo/outputs/v14.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445722444361 roc = 0.806247770786 rate=152672.932052
WARNING:tensorflow:A better loss 0.445722444361 found at /ssd/criteo/outputs/v14.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445894220233 roc = 0.806082844734 rate=94499.5818531
WARNING:tensorflow:A better loss 0.445894220233 found at /ssd/criteo/outputs/v14.1.sp.renorm_best, steps=78119
"""

from .model_v12 import DeepCrossFMModel


class DeepCrossBNFMModel(DeepCrossFMModel):
    def build_fm(self, raw_inputs):
        return super(DeepCrossBNFMModel, self).build_fm(
            [raw_inputs[0], self.BN(raw_inputs[1])])
