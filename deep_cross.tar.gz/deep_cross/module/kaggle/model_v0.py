#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base DXL with kaggle data
"""

from ..base.model_dxl import BaseDXLModel
from .kaggle_trainable import KaggleTrainable
import tensorflow as tf

CATEGORICAL_FEATURE_NAME = "categorical"
CONTINUOUS_FEATURE_NAME = "continuous"
OUTPUT_NAME = "predictions"

tf.app.flags.DEFINE_integer("vocabulary_size", 117568, "categorical feature size")


class BaseKaggleDeepCrossModel(BaseDXLModel, KaggleTrainable):
    def __init__(self, flags):
        BaseDXLModel.__init__(self, flags)
        KaggleTrainable.__init__(self, flags)
        if self.flags.vocabulary_size:
            self.vocabulary_size = self.flags.vocabulary_size
        else:
            self.vocabulary_size = 2 ** self.flags.hash_bits
        tf.logging.warn('vocabulary_size:{}'.format(self.vocabulary_size))
        self.model_inputs = {}
        self.model_outputs = {}

    @classmethod
    def tfrecord_pipeline(cls, tfrecord_file, batch_size,
                          epochs, shuffle=True):
        return KaggleTrainable.tfrecord_pipeline(tfrecord_file, batch_size,
                                                 epochs, shuffle)

    @classmethod
    def reshape_input(cls, features):
        labels = tf.reshape(features['label'], [-1, 1])
        fv = features['dense']
        if tf.app.flags.FLAGS.normalize_dense:
            fv = tf.minimum(fv, 1)
        fv = tf.reshape(fv, [-1, tf.app.flags.FLAGS.dense_features])
        ids = tf.reshape(features['sparse'], [-1, 1])
        return {'continuous': fv, 'categorical': ids}, labels

    def build(self):
        features, labels = self.build_input()
        self.features = features
        self.labels = [labels]
        self.model_inputs = self.build_model_tensors_info(features)

        v = self.build_network(features)
        with tf.device('/gpu:0'):
            preds = self.build_predictions(v)
            self.preds = [preds]
            loss = self.build_loss(labels, preds)
            self.model_outputs[OUTPUT_NAME] = \
                tf.saved_model.utils.build_tensor_info(preds)
            if self.prediction_signature is None:
                self.set_prediction_signature(self.model_inputs,
                                              self.model_outputs)
            self.costs = self.build_eval_metric_ops(labels, preds, loss)
            self.build_cost_summary()
            self.train_op = self.build_train_op(loss)
