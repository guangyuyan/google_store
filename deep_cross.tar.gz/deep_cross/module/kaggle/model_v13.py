#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V13:
    cross: bin(BN(dense)) + embedding
    deep: BN(dense) + BN(embedding)
    fm: bin(BN(dense)) + embedding

WARNING:tensorflow:Eval    4583424 loss=0.445728778539 roc = 0.806365907192 rate=115866.77081
WARNING:tensorflow:A better loss 0.445728778539 found at /ssd/criteo/outputs/v13.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.446149437787 roc = 0.806055665016 rate=116403.822053
WARNING:tensorflow:A better loss 0.446149437787 found at /ssd/criteo/outputs/v13.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445986365125 roc = 0.806479334831 rate=115781.114852
WARNING:tensorflow:A better loss 0.445986365125 found at /ssd/criteo/outputs/v13.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.445913243856 roc = 0.806495964527 rate=115889.326044
WARNING:tensorflow:A better loss 0.445913243856 found at /ssd/criteo/outputs/v13.1.sp.renorm_best, steps=78119
"""

from .model_v12 import DeepCrossFMModel


class DeepBinaryDenseCrossFMModel(DeepCrossFMModel):
    def build_cross(self, raw_inputs, num_layers=3):
        self.bin_dense = self.binary_dense(raw_inputs[0])
        return super(DeepBinaryDenseCrossFMModel, self).build_cross(
            [self.bin_dense, raw_inputs[1]], num_layers)

    def build_fm(self, raw_inputs):
        return super(DeepBinaryDenseCrossFMModel, self).build_fm(
            [self.bin_dense, raw_inputs[1]])
