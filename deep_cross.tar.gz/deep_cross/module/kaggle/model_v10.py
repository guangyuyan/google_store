#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V10:
    cross: dense + embedding
    deep: dense + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.44833029997 roc = 0.803454041481 rate=159180.636267
WARNING:tensorflow:A better loss 0.44833029997 found at /ssd/criteo/outputs/v10.1_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.448366268457 roc = 0.80342912674 rate=156510.412112
WARNING:tensorflow:A better loss 0.448366268457 found at /ssd/criteo/outputs/v10.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.448455795719 roc = 0.803349435329 rate=158808.581325
WARNING:tensorflow:A better loss 0.448455795719 found at /ssd/criteo/outputs/v10.1.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.448669161611 roc = 0.803086936474 rate=156377.530731
WARNING:tensorflow:A better loss 0.448669161611 found at /ssd/criteo/outputs/v10.1.sp.renorm_best, steps=78119
"""


import tensorflow as tf
from .model_v8 import DeepCrossModel2


class OriginalDeepCrossModel2(DeepCrossModel2):
    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        raw_inputs = [raw_inputs[0], self.BN(raw_inputs[1])]
        return self.deep_net(raw_inputs, hidden, activation, sparse=False)
