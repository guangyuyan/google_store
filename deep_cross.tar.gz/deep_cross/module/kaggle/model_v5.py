#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V5:
    cross: bin(BN(dense)) + embedding
    deep: BN(dense) + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.446103798241 roc = 0.805838704109 rate=128843.690693
WARNING:tensorflow:A better loss 0.446103798241 found at /ssd/criteo/outputs/v5_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.446025578929 roc = 0.805903434753 rate=120116.137711
WARNING:tensorflow:A better loss 0.446025578929 found at /ssd/criteo/outputs/v5.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.446145697449 roc = 0.805722475052 rate=122346.105262
WARNING:tensorflow:A better loss 0.446145697449 found at /ssd/criteo/outputs/v5.renorm_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.446070326577 roc = 0.805943250656 rate=122823.498104
WARNING:tensorflow:A better loss 0.446070326577 found at /ssd/criteo/outputs/v5.sp.renorm_best, steps=78119
"""


from .model_v11 import OriginalDeepCrossModel


class DeepBinaryDenseCrossModel(OriginalDeepCrossModel):
    def build_cross(self, raw_inputs, num_layers=3):
        return super(DeepBinaryDenseCrossModel, self).build_cross(
            [self.binary_dense(raw_inputs[0]), raw_inputs[1]], num_layers)
