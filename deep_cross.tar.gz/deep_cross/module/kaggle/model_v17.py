#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V17:
    cross: bin(dense) + embedding
    deep: dense + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.448042665486 roc = 0.803871929646 rate=120471.820297
WARNING:tensorflow:A better loss 0.448042665486 found at /ssd/criteo/outputs/v17.1_best, steps=39059

WARNING:tensorflow:Eval    4583424 loss=0.448790934466 roc = 0.802905976772 rate=119802.179759
WARNING:tensorflow:A better loss 0.448790934466 found at /ssd/criteo/outputs/v17.1.sp_best, steps=78119

WARNING:tensorflow:Eval    4583424 loss=0.448542237555 roc = 0.803398549557 rate=120575.691162
WARNING:tensorflow:A better loss 0.448542237555 found at /ssd/criteo/outputs/v17.1.renorm_best, steps=39059

WARNING:tensorflow:Eval    4583424 loss=0.44862089165 roc = 0.803142309189 rate=120337.377894
WARNING:tensorflow:A better loss 0.44862089165 found at /ssd/criteo/outputs/v17.1.sp.renorm_best, steps=78119
"""

from .model_v10 import OriginalDeepCrossModel2


class DeepBinaryDenseCrossModel2(OriginalDeepCrossModel2):
    def build_cross(self, raw_inputs, num_layers=3):
        return super(DeepBinaryDenseCrossModel2, self).build_cross(
            [self.binary_dense(raw_inputs[0]), raw_inputs[1]], num_layers)
