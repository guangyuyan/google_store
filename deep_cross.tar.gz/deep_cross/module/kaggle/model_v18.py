#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V18:
    cross: bin(dense) + bin(embedding)
    deep: dense + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.455459919642 roc = 0.794954180717 rate=119417.435432
WARNING:tensorflow:A better loss 0.455459919642 found at /ssd/criteo/outputs/v18.1_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.455371679254 roc = 0.795145571232 rate=119580.567159
WARNING:tensorflow:A better loss 0.455371679254 found at /ssd/criteo/outputs/v18.1.sp_best, steps=136709

WARNING:tensorflow:Eval    4583424 loss=0.455046269067 roc = 0.795198500156 rate=126115.258488
WARNING:tensorflow:A better loss 0.455046269067 found at /ssd/criteo/outputs/v18.1.renorm_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.454891522399 roc = 0.796095311642 rate=120246.060425
WARNING:tensorflow:A better loss 0.454891522399 found at /ssd/criteo/outputs/v18.1.sp.renorm_best, steps=146474
"""

from .model_v10 import OriginalDeepCrossModel2


class DeepFastBinaryQuadCrossModel2(OriginalDeepCrossModel2):
    def build_embedding_layer(self, ids):
        return self.embedding(ids, "embedding", 10)

    def build_cross(self, raw_inputs, num_layers=3):
        bucked_dense = self.binary_dense(raw_inputs[0])
        binary_sparse = self.binary_embedding(raw_inputs[1])
        return super(DeepFastBinaryQuadCrossModel2, self).build_cross(
            [bucked_dense, binary_sparse], num_layers)
