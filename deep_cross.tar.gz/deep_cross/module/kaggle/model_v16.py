#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
V16:
    cross: dense + bin(embedding)
    deep: dense + BN(embedding)

WARNING:tensorflow:Eval    4583424 loss=0.455032597105 roc = 0.795314967632 rate=154557.886655
WARNING:tensorflow:A better loss 0.455032597105 found at /ssd/criteo/outputs/v16.1_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.455339583424 roc = 0.794873356819 rate=154437.204917
WARNING:tensorflow:A better loss 0.455339583424 found at /ssd/criteo/outputs/v16.1.sp_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.455322396087 roc = 0.79495215416 rate=159057.599592
WARNING:tensorflow:A better loss 0.455322396087 found at /ssd/criteo/outputs/v16.1.renorm_best, steps=117179

WARNING:tensorflow:Eval    4583424 loss=0.455041240425 roc = 0.795209050179 rate=157137.068883
WARNING:tensorflow:A better loss 0.455041240425 found at /ssd/criteo/outputs/v16.1.sp.renorm_best, steps=117179
"""


from .model_v10 import OriginalDeepCrossModel2


class DeepFastBinaryCrossModel2(OriginalDeepCrossModel2):
    def build_embedding_layer(self, ids):
        return self.embedding(ids, "embedding", 10)

    def build_cross(self, raw_inputs, num_layers=3):
        return super(DeepFastBinaryCrossModel2, self).build_cross(
            [raw_inputs[0], self.binary_embedding(raw_inputs[1])], num_layers)
