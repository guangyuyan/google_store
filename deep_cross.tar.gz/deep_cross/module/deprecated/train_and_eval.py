#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""

"""

import tensorflow as tf
from build_model import build_model


tf.app.flags.DEFINE_string("model_dir", ".", "model dir")

model = build_model(tf.app.flags.FLAGS)


def model_fn(features, labels, mode, params):
    """Model function used in the estimator.
    Args:
        features (Tensor): Input features to the model.
        labels (Tensor): Labels tensor for training and evaluation.
        mode (ModeKeys): Specifies if training, evaluation or prediction.
        params (HParams): hyperparameters.
    Returns:
        (EstimatorSpec): Model to be run by Estimator.
    """
    v = model.build_network(features, labels)
    with tf.device('/gpu:0'):
        preds = model.build_predictions(v)
        # Loss, training and eval operations are not needed during inference.
        loss = None
        train_op = None
        eval_metric_ops = {}
        if mode != tf.estimator.ModeKeys.PREDICT:
            loss = model.build_loss(labels, preds)
            train_op = get_train_op_fn(loss, params)
            eval_metric_ops = model.build_eval_metric_ops(labels, preds, loss)
    return tf.estimator.EstimatorSpec(
        mode=mode,
        predictions=preds,
        loss=loss,
        train_op=train_op,
        eval_metric_ops=eval_metric_ops
    )


def get_train_op_fn(loss, params):
    """Get the training Op.
    Args:
         loss (Tensor): Scalar Tensor that represents the loss function.
         params (HParams): Hyperparameters (needs to have `learning_rate`)
    Returns:
        Training Op
    """
    return tf.contrib.layers.optimize_loss(
        loss=loss,
        global_step=tf.train.get_global_step(),
        optimizer=tf.train.AdamOptimizer,
        learning_rate=params.learning_rate
    )


def get_estimator(run_config, params):
    """Return the model as a Tensorflow Estimator object.
    Args:
         run_config (RunConfig): Configuration for Estimator run.
         params (HParams): hyperparameters.
    """
    return tf.estimator.Estimator(
        model_fn=model_fn,  # First-class function
        params=params,  # HParams
        config=run_config  # RunConfig
    )


class EarlyStopper():
    def __init__(self):
        self.max_patient_passes = tf.app.flags.FLAGS.patient_valid_passes
        self.best_loss = float('Inf')
        self.patient_pass = 0

    def after_run(self, eval_results, checkpoint_path):
        # None argument for the first evaluation
        if not eval_results:
            return True
        cur_loss = eval_results['loss']
        if cur_loss < self.best_loss:
            self.best_loss = cur_loss
            self.patient_pass = 0
            tf.logging.warn(
                'A better loss {} found at {}'.format(
                    cur_loss, checkpoint_path))
            return True
        self.patient_pass += 1
        tf.logging.warn(
                'best_loss={}, cur_loss={}'.format(
                    self.best_loss, cur_loss))
        if self.patient_pass >= self.max_patient_passes:
            tf.logging.warn('early stopping')
            return False
        return True


def main():
    flags = tf.app.flags.FLAGS

    params = tf.contrib.training.HParams(
        learning_rate=flags.learning_rate,
    )
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True
    run_config = tf.estimator.RunConfig(session_config=sess_config,
                                        model_dir=flags.model_dir)
    # run_config = tf.contrib.learn.RunConfig()
    # run_config = run_config.replace(session_config=sess_config)
    # run_config = run_config.replace(model_dir=flags.model_dir)

    estimator = get_estimator(run_config, params)
    experiment = tf.contrib.learn.Experiment(
        estimator=estimator,
        train_input_fn=model.build_input,
        eval_input_fn=model.build_valid_input,
        eval_steps=None,
        train_steps_per_iteration=flags.data_per_valid /
        flags.prebatch /
        flags.batch_size,
     )
    early_stopper = EarlyStopper()
    experiment.continuous_train_and_eval(
        continuous_eval_predicate_fn=early_stopper.after_run)


if __name__ == "__main__":
    main()
