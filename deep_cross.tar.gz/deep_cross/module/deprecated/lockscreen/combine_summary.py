#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
combine daily summary files
"""

import argparse
import glob
import pandas as pd


def main(args):
    filepath = args.data_folder
    flist = glob.glob(filepath + '/*libsvm*summary')
    print(flist)

    df_all = None
    for f in flist:
        df = pd.read_csv(f, header=None, delimiter=' ', index_col=0)
        if df_all is None:
            df_all = df
        df_all[1].where(df_all[1] < df[1], df[1], inplace=True)
        df_all[2].where(df_all[2] > df[2], df[2], inplace=True)
    df_all.to_csv(filepath + '/all_date.minmax.summary', header=None, sep=' ')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--data_folder', type=str, required=True)
    main(parser.parse_args())
