#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep & cross model
"""


import numpy as np
import tensorflow as tf

from model_v0 import BaseLockscreenDXLModel
from gen_field_dicts import FIX_LEN_CATEGORY, VAR_LEN_CATEGORY, FIX_LEN_INT
from reader import DENSE_INT_SIZE


class LockscreenDXLModel(BaseLockscreenDXLModel):
    def __init__(self, flags):
        super(LockscreenDXLModel, self).__init__(flags)

    def load_minmax(self):
        dense_int_min = [0.0] * DENSE_INT_SIZE
        dense_int_max = [1.0] * DENSE_INT_SIZE
        with open(self.flags.dense_minmax_dir) as f:
            for line in f:
                content = line.strip().split()
                key = content[0]
                v_min = float(content[1])
                v_max = float(content[2])
                if key in FIX_LEN_INT:
                    index = FIX_LEN_INT.index(key)
                    dense_int_min[index] = v_min
                    dense_int_max[index] = v_max
        self.dense_min = tf.Variable(dense_int_min, dtype=tf.float32)
        self.dense_max = tf.Variable(dense_int_max, dtype=tf.float32)
        self.dense_norm = self.dense_max - self.dense_min
        np_min = np.array(dense_int_min)
        np_max = np.array(dense_int_max)
        self.dense_int_dim = int(np.max(np.sqrt(np_max - np_min))) + 1
        self.dense_int_emb = self.compute_emb_size(self.dense_int_dim)
        tf.logging.warn('dense_int_dim:{}'.format(self.dense_int_dim))
        tf.logging.warn('dense_int_emb:{}'.format(self.dense_int_emb))
        # TODO(byzhang): too hacky to set flags here.
        self.flags.embedding_size = self.dense_int_emb
        self.vocabulary_size = self.dense_int_dim
        self.flags.sparse_features = DENSE_INT_SIZE

    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hidden = [int(h) for h in self.flags.deep_layers.split(',')]
            deep_out = self.build_deep(inputs, hidden=hidden)
            cross_out = self.build_cross(
                inputs, num_layers=int(self.flags.cross_layers))
            output = tf.concat([deep_out, cross_out], -1)
            return output

    def single_embedding(self, ids, layer_name, voc_size,
                         emb_size, initial_range):
        with tf.name_scope('embedding'):
            emb = tf.get_variable(
                layer_name, [voc_size, emb_size],
                initializer=tf.random_uniform_initializer(
                    minval=-initial_range, maxval=initial_range)
                if initial_range else None)
            out = tf.nn.embedding_lookup(emb, ids)
            out = tf.reshape(out, [-1, emb_size])
            return out

    def build_single_embedding(self, ids, layer_name, voc_size,
                               emb_size):
        return self.single_embedding(ids, layer_name, voc_size,
                                     emb_size, None)

    def sparse_embedding(self, ids, layer_name, voc_size,
                         emb_size, initial_range):
        with tf.name_scope('embedding'):
            emb = tf.get_variable(
                layer_name, [voc_size, emb_size],
                initializer=tf.random_uniform_initializer(
                    minval=-initial_range, maxval=initial_range)
                if initial_range else None)
            out = tf.nn.embedding_lookup_sparse(emb, ids, None,
                                                combiner="mean")
            return out

    def build_sparse_embedding(self, ids, layer_name, voc_size,
                               emb_size):
        return self.sparse_embedding(ids, layer_name, voc_size,
                                     emb_size, None)

    def build_features(self, features):
        with tf.device('/gpu:0'):
            ev_list = []
            for key in FIX_LEN_CATEGORY:
                ev_list.append(
                    self.build_single_embedding(
                        features[key],
                        layer_name=key,
                        voc_size=self.voc_emb_size[key][0],
                        emb_size=self.voc_emb_size[key][1]))

            sparse_ev_list = []
            if not self.flags.skip_var_len:
                for key in VAR_LEN_CATEGORY:
                    sparse_ev_list.append(
                        self.build_sparse_embedding(
                            features[key],
                            layer_name=key,
                            voc_size=self.voc_emb_size[key][0],
                            emb_size=self.voc_emb_size[key][1]))

            self.load_minmax()
            fv_int = tf.cast(features['dense_int'], dtype=tf.float32)
            # fv_int, int_ids = self.minmax_normalize_int(fv_int)
            fv_int, int_ids = self.log_int(fv_int)

            # tf.logging.warn(features['dense_float'].get_shape())
            # dense_float = tf.slice(features['dense_float'], [0,0], [-1,264])
            # tf.logging.warn(dense_float.get_shape())
            # fv = tf.concat([fv_int, dense_float], -1)

            fv = tf.concat([fv_int, features['dense_float']], -1)
            fv = self.build_dense_layer(fv)

            int_ev_list = [self.embedding(int_ids, 'int_ids', None)]

            network_inputs = self.concat(
                [fv] + ev_list + sparse_ev_list + int_ev_list)
            input_dim = 0
            for key in network_inputs:
                tf.logging.warn(key)
                input_dim += int(key.get_shape()[-1])
            tf.logging.warn("Total input dim: {}".format(input_dim))
            return network_inputs

    def log_int(self, iv):
        with tf.name_scope('dense'):
            iv = tf.log(1.0 + iv)
            ids = tf.cast(tf.sqrt(iv), dtype=tf.int64)
            return iv, ids

    def get_dense_max(self):
        return self.dense_max

    def get_dense_min(self):
        return self.dense_min

    def get_dense_norm(self):
        return self.dense_norm

    def build_dense_layer(self, fv):
        return self.BN(fv)

    def build_deep(self, raw_inputs, hidden=None, activation=tf.nn.relu):
        return self.deep_net(raw_inputs, hidden, activation,
                             sparse=self.flags.sparse_deep)

    def build_cross(self, raw_inputs, num_layers=3):
        return self.cross_net(raw_inputs, num_layers,
                              use_bias=self.flags.cross_bias,
                              sparse=self.flags.sparse_cross)
