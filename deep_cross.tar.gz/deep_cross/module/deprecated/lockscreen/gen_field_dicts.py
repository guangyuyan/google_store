#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <xjfan@>
#
# Distributed under terms of the CloudBrain license.

"""
Generate field dicts from original dict
field dicts format:
    origin_id feature_name new_id
"""

import argparse
import re
from collections import defaultdict

FIX_LEN_INT = ['11_1d_u', '11_1w_u', '11_2w_u', '11_3d_u',
               '11_1d_p', '11_1w_p', '11_2w_p', '11_3d_p',
               '21_1d_u', '21_1w_u', '21_2w_u', '21_3d_u',
               '21_1d_p', '21_1w_p', '21_2w_p', '21_3d_p',
               '22_1d_u', '22_1w_u', '22_2w_u', '22_3d_u',
               '22_1d_p', '22_1w_p', '22_2w_p', '22_3d_p',
               'icng_p_n', 'itng_p_n', 'stng_p_n', 'udtng_p_n',
               'c_n_u', 'c_t_u', 'al_u_n']
FIX_LEN_FLOAT = ['iv%d_p' % i for i in range(256)]
FIX_LEN_CATEGORY = ['dt_p', 'dtt_p', 'tc_p', 'tid_p',
                    'tp_p', 'tpp_p', 'l_u', 'm_u',
                    'r_u', 'v_u', 'dow']
VAR_LEN_CATEGORY = ['icng_p', 'itng_p', 'stng_p', 'udtng_p', 'al_u']
VAR_LEN_SPARSE = ['ca_u']
CLICK_EVENT_SIZE = 8
EVENT_SIZE = 24
EVENT_RATE_FLOAT = ['event_rate_%i' % i
                    for i in range(CLICK_EVENT_SIZE)]
CATEGORY_FEATURES = FIX_LEN_CATEGORY + VAR_LEN_CATEGORY + VAR_LEN_SPARSE
WHITE_LIST = FIX_LEN_INT + FIX_LEN_FLOAT + CATEGORY_FEATURES


def main(args):
    field_dicts = defaultdict(set)
    ignored_feature = set()
    with open(args.input_dict) as fin:
        for line in fin:
            origin_id, content = line.strip().split()
            if "__bin" in content:
                ignored_feature.add(content)
                continue
            key = re.split("__", content)
            if (key[0] in WHITE_LIST):
                field_dicts[key[0]].add(origin_id)
            else:
                ignored_feature.add(content)

    output_list = []
    feature_summary = []
    for key in field_dicts:
        for i, origin_id in enumerate(field_dicts[key], 1):
            output_list.append("%s %s %d" % (origin_id, key, i))
        if key in (FIX_LEN_CATEGORY + VAR_LEN_CATEGORY + VAR_LEN_SPARSE):
            feature_summary.append("%s %d" % (key, len(field_dicts[key])+1))

    with open(args.output_dict, 'w') as fout:
        fout.write("\n".join(output_list))

    with open(args.output_dict + ".summary", 'w') as fs:
        fs.write("\n".join(feature_summary))

    with open(args.output_dict + ".ignored", 'w') as fi:
        fi.write("\n".join(sorted(list(ignored_feature))))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input_dict', type=str, required=True)
    parser.add_argument('-o', '--output_dict', type=str, required=True)
    main(parser.parse_args())
