#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
reader functions
"""

import tensorflow as tf
from gen_field_dicts import FIX_LEN_INT, FIX_LEN_FLOAT, FIX_LEN_CATEGORY
from gen_field_dicts import VAR_LEN_CATEGORY, CLICK_EVENT_SIZE

tf.app.flags.DEFINE_bool("skip_var_len", False, "skip var length feature")
DENSE_FLOAT_SIZE = len(FIX_LEN_FLOAT) * 3 + CLICK_EVENT_SIZE
DENSE_INT_SIZE = len(FIX_LEN_INT)


def tfrecord_pipeline(tfrecord_file, batch_size, prebatch, epochs):
    def parser(record):
        map_features = {}
        map_features['label'] = tf.FixedLenFeature([prebatch], tf.int64)
        map_features['dense_float'] = tf.FixedLenFeature(
                [prebatch * DENSE_FLOAT_SIZE],
                tf.float32)
        map_features['dense_int'] = tf.FixedLenFeature(
                [prebatch * DENSE_INT_SIZE],
                tf.int64)
        for feature in FIX_LEN_CATEGORY:
            map_features[feature] = tf.FixedLenFeature([prebatch], tf.int64)

        if not tf.app.flags.FLAGS.skip_var_len:
            for feature in VAR_LEN_CATEGORY:
                map_features[feature] = tf.VarLenFeature(tf.int64)

        data_sample = tf.parse_single_example(record, features=map_features)
        labels = data_sample.pop('label')
        return data_sample, labels

    dataset = tf.data.TFRecordDataset(
                filenames=tfrecord_file, compression_type='GZIP')
    dataset = dataset.map(parser, num_parallel_calls=4)
    dataset = dataset.shuffle(buffer_size=128)
    dataset = dataset.prefetch(buffer_size=128)
    dataset = dataset.repeat(epochs)
    dataset = dataset.batch(batch_size)
    return dataset.make_initializable_iterator()
