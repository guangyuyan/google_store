#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Base DXL with lockstream data
"""

import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from gen_field_dicts import FIX_LEN_CATEGORY, VAR_LEN_CATEGORY
from gen_field_dicts import CATEGORY_FEATURES
from model_dxl import BaseDXLModel
from reader import tfrecord_pipeline
from reader import DENSE_FLOAT_SIZE, DENSE_INT_SIZE
import tensorflow as tf

OUTPUT_NAME = "predictions"

class BaseLockscreenDXLModel(BaseDXLModel, object):
    def __init__(self, flags):
        super(BaseLockscreenDXLModel, self).__init__(flags)
        with tf.device('/cpu:0'):
            train_list = self.flags.train_data.split(',')
            valid_list = self.flags.valid_data.split(',')
            self.data_iterator = tfrecord_pipeline(train_list,
                                                   self.flags.batch_size,
                                                   self.flags.prebatch,
                                                   epochs=self.flags.epochs)
            self.valid_iterator = tfrecord_pipeline(valid_list,
                                                    self.flags.batch_size,
                                                    self.flags.prebatch,
                                                    epochs=1)
            self.voc_emb_size = None
            self.prediction_signature = None

    def initializer(self):
        return [self.data_iterator.initializer,
                self.valid_iterator.initializer]

    def valid_initializer(self):
        return self.valid_iterator.initializer

    def build_input(self):
        with tf.device('/cpu:0'):
            features, labels = self.data_iterator.get_next()
            return self.reshape_input(features, labels)

    def build_valid_input(self):
        with tf.device('/cpu:0'):
            features, labels = self.valid_iterator.get_next()
            return self.reshape_input(features, labels)

    def reshape_sparse(self, feature, voc_size):
        with tf.device('/cpu:0'):
            value = tf.cast(feature.values, tf.int64)
            idx = tf.stack([feature.indices[:, 0], value], axis=1)
            new_f = tf.SparseTensor(indices=idx,
                    values=value,
                    dense_shape=[self.flags.batch_size,
                                 self.flags.prebatch * voc_size])
            new_reshape = tf.sparse_reshape(new_f, shape=[-1, voc_size])
            output = tf.SparseTensor(indices=new_reshape.indices,
                    values=new_reshape.indices[:, 1],
                    dense_shape=new_reshape.dense_shape)
            return output

    def compute_emb_size(self, voc_size):
        return int(6 * (voc_size ** 0.25))

    def load_voc_summary(self):
        # set default vocabulary and embedding size
        voc_emb_size = {key: [15000, 80] for key in CATEGORY_FEATURES}
        with open(self.flags.voc_dir) as f:
            for line in f:
                content = line.strip().split()
                key = content[0]
                voc_size = int(content[1])
                if key in CATEGORY_FEATURES:
                    emb_size = self.compute_emb_size(voc_size)
                    voc_emb_size[key] = [voc_size, emb_size]
        for key, value in voc_emb_size.iteritems():
            tf.logging.warn(" {:8} voc_size{:8} emb_size{:3}".format(
                            key, value[0], value[1]))
        self.voc_emb_size = voc_emb_size

    def reshape_input(self, features, labels):
        labels = tf.reshape(labels, [-1, 1])
        self.load_voc_summary()
        features['dense_float'] = tf.reshape(features['dense_float'],
                                             [-1, DENSE_FLOAT_SIZE])
        features['dense_int'] = tf.reshape(features['dense_int'],
                                           [-1, DENSE_INT_SIZE])
        for key in FIX_LEN_CATEGORY:
            features[key] = tf.reshape(features[key], [-1, 1])
        for key in VAR_LEN_CATEGORY:
            features[key] = self.reshape_sparse(features[key],
                                                self.voc_emb_size[key][0])
        return features, labels

    def build(self):
        features, labels = tf.cond(self.is_training, true_fn=self.build_input,
                                   false_fn=self.build_valid_input)
        self.features = features
        self.model_outputs = {}
        v = self.build_network(features)
        with tf.device('/gpu:0'):
            preds = self.build_predictions(v)
            loss = self.build_loss(labels, preds)
            self.model_output[OUTPUT_NAME]=preds
            if self.prediction_signature is None:
                self.set_prediction_signature(features, preds)
            self.costs = self.build_eval_metric_ops(labels, preds, loss)
            tf.summary.scalar('cost/stream_loss',
                              self.costs['stream_loss'][1])
            tf.summary.scalar('cost/loss', self.costs['loss'])
            tf.summary.scalar('cost/roc', self.costs['roc'][1])
            tf.summary.scalar('cost/pr', self.costs['pr'][1])
            with tf.control_dependencies(
                    tf.get_collection(tf.GraphKeys.UPDATE_OPS)):
                self.train_op = (tf.train.AdamOptimizer(
                    learning_rate=self.flags.learning_rate)
                    .minimize(loss, global_step=self.global_step))
