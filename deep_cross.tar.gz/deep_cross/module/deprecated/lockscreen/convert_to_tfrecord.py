#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <xjfan@>
#
# Distributed under terms of the CloudBrain license.

"""
Convert lock screen data to tfrecord
"""

import argparse
import tensorflow as tf
from gen_field_dicts import FIX_LEN_INT, FIX_LEN_FLOAT, FIX_LEN_CATEGORY
from gen_field_dicts import VAR_LEN_CATEGORY, VAR_LEN_SPARSE, EVENT_RATE_FLOAT
from gen_field_dicts import EVENT_SIZE, CLICK_EVENT_SIZE, CATEGORY_FEATURES
import time
import pandas as pd
import numpy as np

DENSE_INT_SIZE = len(FIX_LEN_INT)
DENSE_FLOAT_SIZE = len(FIX_LEN_FLOAT)
FEATURE_KEYS = FIX_LEN_CATEGORY + VAR_LEN_CATEGORY +\
    ["dense_int", "dense_float", "label"]
HIST_DAYS = 3


def _int64_feature(value):
    return tf.train.Feature(
        int64_list=tf.train.Int64List(value=value))


def _float_feature(value):
    return tf.train.Feature(
        float_list=tf.train.FloatList(value=value))


def load_field_dict(dict_file):
    field_dict = dict()
    with open(dict_file) as f_dict:
        for line in f_dict:
            content = line.strip().split()
            field_dict[content[0]] = content[1:]
    return field_dict


def load_summary(summary_file):
    cate_voc_size = dict()
    with open(summary_file) as f:
        for line in f:
            content = line.strip().split()
            if content[0] in CATEGORY_FEATURES:
                cate_voc_size[content[0]] = int(content[1])
    return cate_voc_size


def write_minmax(dense_minmax, out_file):
    minmax_summary = ["%s %.8f %.8f" % (k,
                                        dense_minmax[k][0],
                                        dense_minmax[k][1])
                      for k in dense_minmax]
    with open(out_file + '.summary', 'w') as fs:
        fs.write('\n'.join(minmax_summary))


def write_tf_example(writer, batch_features, skip_var_len):
    tf_features = {}
    for key in FIX_LEN_CATEGORY:
        tf_features[key] = _int64_feature(batch_features[key])
    if not skip_var_len:
        for key in VAR_LEN_CATEGORY:
            tf_features[key] = _int64_feature(batch_features[key])
    tf_features["dense_int"] = _int64_feature(batch_features["dense_int"])
    tf_features["dense_float"] = _float_feature(batch_features["dense_float"])
    tf_features["label"] = _int64_feature(batch_features["label"])

    example = tf.train.Example(
        features=tf.train.Features(
            feature=tf_features
        ))
    writer.write(example.SerializeToString())


def process_event_features(features, smooth_factor):
    event_rates = []
    for i in range(CLICK_EVENT_SIZE):
        event_rates.append((features["dense_int"][i] + 1.0) /
                           (features["dense_int"][i + CLICK_EVENT_SIZE] +
                            features["dense_int"][i + CLICK_EVENT_SIZE * 2] +
                            smooth_factor))
    return event_rates


def init_features(batch_index, ngram_voc_size):
    features = {}
    for key in FIX_LEN_CATEGORY:
        features[key] = [0]
    for key in VAR_LEN_CATEGORY:
        features[key] = [0 + batch_index * ngram_voc_size[key]]
    features["dense_int"] = [0] * DENSE_INT_SIZE
    features["dense_float"] = [0] * DENSE_FLOAT_SIZE
    features["label"] = []
    return features


def init_batch_features():
    return {k: [] for k in FEATURE_KEYS}


def init_dense_minmax():
    dense_minmax = dict()
    for key in (FIX_LEN_INT + FIX_LEN_FLOAT + EVENT_RATE_FLOAT):
        dense_minmax[key] = [float('inf'), -float('inf')]
    return dense_minmax


def update_dense_minmax(dense_minmax, field_name, value):
    if value > dense_minmax[field_name][1]:
        dense_minmax[field_name][1] = value
    if value < dense_minmax[field_name][0]:
        dense_minmax[field_name][0] = value
    return dense_minmax


def moving_avg(file_path):
    df = pd.read_csv(file_path, sep='\t', index_col=0, dtype=str)
    df.fillna('', inplace=True)
    for i in range(HIST_DAYS):
        df = df.shift(2, axis=1)
        df.fillna('', inplace=True)
        if i == 0:
            df_all = df
        else:
            df_all = df_all + df
    df_all.to_csv(file_path+'_avg', sep='\t', header=None)
    return df_all


def cal_image_avg(list_str, df_image_lib):
    image_list = list_str.split('|')
    image_list = [int(x) for x in image_list if x != '']
    if image_list == []:
        avg_vector = np.array([0.0] * df_image_lib.shape[1])
    else:
        avg_vector = df_image_lib.loc[image_list].values
        if len(avg_vector.shape) > 1:
            avg_vector = np.average(avg_vector, axis=0)
    return avg_vector.tolist()


def to_tfrecord(args, field_dict, cate_voc_size, df_hist, df_image_lib):
    options = tf.python_io.TFRecordOptions(
                tf.python_io.TFRecordCompressionType.GZIP)
    writer = tf.python_io.TFRecordWriter(args.out_file, options=options)
    print('Writing data to .tfrecord format...')
    start_time = time.time()

    dense_minmax = init_dense_minmax()
    batch_features = init_batch_features()
    batch_index = 0
    sample_date = args.in_file.split('.')[0].split('_')[-1]
    last_uid = ''
    with open(args.in_file) as fin:
        for cnt, line in enumerate(fin):
            content = line.strip().split()
            features = init_features(batch_index, cate_voc_size)
            features["label"] = [int(content[1])]
            uid, image_id = content[0].split('_')
            for i in range(2, len(content)):
                feature = content[i]
                key_id, value = feature.split(':')
                if key_id not in field_dict:
                    continue
                field_feature = field_dict[key_id]
                field_name = field_feature[0]
                field_id = field_feature[1]

                if field_name in FIX_LEN_CATEGORY:
                    features[field_name] = [int(field_id)]
                elif field_name in VAR_LEN_CATEGORY:
                    if not args.skip_var_len:
                        features[field_name].append(int(field_id) +
                                    cate_voc_size[field_name] * batch_index)
                elif field_name in FIX_LEN_INT:
                    dense_int_index = FIX_LEN_INT.index(field_name)
                    value = int(float(value))
                    features["dense_int"][dense_int_index] = value
                    dense_minmax = update_dense_minmax(dense_minmax,
                                                       field_name,
                                                       value)
                elif field_name in FIX_LEN_FLOAT:
                    dense_float_index = FIX_LEN_FLOAT.index(field_name)
                    value = float(value)
                    features["dense_float"][dense_float_index] = value
                    dense_minmax = update_dense_minmax(dense_minmax,
                                                       field_name,
                                                       value)
            # sorting is required for tf sparsetensor manipulation
            if not args.skip_var_len:
                for key in VAR_LEN_CATEGORY:
                    features[key].sort()
            event_rates = process_event_features(features, args.smooth)
            features["dense_float"].extend(event_rates)
            for i in range(len(EVENT_RATE_FLOAT)):
                dense_minmax = update_dense_minmax(dense_minmax,
                                                   EVENT_RATE_FLOAT[i],
                                                   event_rates[i])
            # cache hist_vector since uid comes in order
            if uid != last_uid:
                pos_hist = df_hist[sample_date+'_1'][int(uid)]
                neg_hist = df_hist[sample_date+'_0'][int(uid)]
                hist_vector = (cal_image_avg(pos_hist, df_image_lib) +
                               cal_image_avg(neg_hist, df_image_lib))
                last_uid = uid

            features["dense_float"].extend(hist_vector)

            # concate features in same prebatch
            for key in FEATURE_KEYS:
                batch_features[key].extend(features[key])
            batch_index += 1

            if ((cnt + 1) % args.prebatch) == 0:
                write_tf_example(writer, batch_features, args.skip_var_len)
                batch_features = init_batch_features()
                batch_index = 0
            if ((cnt + 1) % 10000) == 0:
                end_time = time.time()
                print("%.2f minutes, %d samples are processed." %
                      ((end_time-start_time) / 60.0, cnt + 1))
                if args.skip_var_len:
                    print("Var length features are skipped.")
    writer.close()
    write_minmax(dense_minmax, args.out_file)


def main(args):
    field_dict = load_field_dict(args.dict)
    df_hist = moving_avg(args.hist_file)
    df_image_lib = pd.read_csv(args.image_lib, sep='\t',
                               index_col=0, header=None)
    cate_voc_size = load_summary(args.summary)
    to_tfrecord(args, field_dict, cate_voc_size, df_hist, df_image_lib)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--in_file', type=str, required=True)
    parser.add_argument('-o', '--out_file', type=str, required=True)
    parser.add_argument('-d', '--dict', type=str, required=True)
    parser.add_argument('-t', '--hist_file', type=str, required=True)
    parser.add_argument('-l', '--image_lib', type=str, required=True)
    parser.add_argument('-p', '--prebatch', type=int, default=256)
    parser.add_argument('--skip_var_len', action="store_true", default=False)
    parser.add_argument('-s', '--summary', type=str, required=True)
    parser.add_argument('-m', '--smooth', type=int, default=7)

    main(parser.parse_args())
