#! /bin/sh
#
# train.sh
# Copyright (C) 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.
#


CUDA_VISIBLE_DEVICES=0 python trainer.py \
  --model=v4 --model_name outputs/v4 \
  --deep_layers=2048,1024,512,256 --cross_layers=5 \
  --learning_rate=0.0002 --epochs=5 \
  --data_per_valid 3000000 --patient_valid_passes 10 \
  --train_data /ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180310.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180311.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180312.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180313.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180314.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180315.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180316.0.libsvm.tf,/ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180317.0.libsvm.tf \
  --valid_data /ssd/users/xjfan/lockscreen/v4/0324__data_mobileads_alg_training-id_lz_data_20180318.0.libsvm.tf \
  --dense_minmax_dir /ssd/users/xjfan/lockscreen/v4/all_date.minmax.summary \
  --voc_dir /ssd/users/xjfan/lockscreen/v4/dxl_dicts.txt.summary \
  --prebatch 256 --batch_size 4 \
  --summaries_dir ./summaries/$1 \
  2>&1 | tee ./summaries/$1.log

cp train.sh ./summaries/$1/
mv ./summaries/$1.log ./summaries/$1/
