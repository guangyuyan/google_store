#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
generate image library from libsvm format data
"""

import argparse
from convert_to_tfrecord import load_field_dict
from gen_field_dicts import FIX_LEN_FLOAT

image_id_set = set()
outputs = []


def add_image_lib(image_id, image_dict, content):
    image_id_set.add(image_id)
    image_vector = [0] * len(FIX_LEN_FLOAT)
    for i in range(2, len(content)):
        feature = content[i]
        key_id, value = feature.split(':')
        if key_id in image_dict:
            value = float(value)
            image_vector[FIX_LEN_FLOAT.index(image_dict[key_id][0])] = value
    output = [image_id] + image_vector
    output = '\t'.join([str(x) for x in output])
    outputs.append(output)


def process_one_file(file, image_dict):
    with open(file) as fin:
        for line in fin:
            content = line.strip().split()
            user_id, image_id = content[0].split('_')
            if image_id not in image_id_set:
                add_image_lib(image_id, image_dict, content)


def main(args):
    field_dict = load_field_dict(args.dict)
    image_dict = {}
    for k in field_dict:
        if field_dict[k][0] in FIX_LEN_FLOAT:
            image_dict[k] = field_dict[k]
    with open(args.file_list) as flist:
        for line in flist:
            process_one_file(line.strip(), image_dict)
            print("%s has been processed." % line)

    with open(args.out_file, 'w') as fout:
        fout.write('\n'.join(outputs))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--file_list', type=str, required=True)
    parser.add_argument('-o', '--out_file', type=str, required=True)
    parser.add_argument('-d', '--dict', type=str, required=True)
    main(parser.parse_args())
