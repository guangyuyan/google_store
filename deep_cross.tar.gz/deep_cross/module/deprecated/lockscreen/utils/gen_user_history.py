#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
generate user history from libsvm format data
input is a file of path of data files
output row is uid, column is date_label
    label 1 means clicked history
    label 0 means impression history
"""

import argparse
import pandas as pd
import time

all_data = {}
HIST_DAYS = 3


def moving_avg(df):
    df.fillna('', inplace=True)
    for i in range(HIST_DAYS):
        df = df.shift(2, axis=1)
        df.fillna('', inplace=True)
        if i == 0:
            df_all = df
        else:
            df_all = df_all + df
    return df_all


def process_one_file(f_name):
    f_date = f_name.split('/')[-1].split('.')[0]
    with open(f_name) as fin:
        for line in fin:
            content = line.strip().split()
            user_id, image_id = content[0].split('_')
            label = content[1]
            col_name = f_date + '_' + label
            if user_id not in all_data:
                all_data[user_id] = {}
            if col_name not in all_data[user_id]:
                all_data[user_id][col_name] = ''
            all_data[user_id][col_name] += (image_id + '|')


def main(args):
    with open(args.file_list) as flist:
        for line in flist:
            process_one_file(line.strip())
            local_time = time.localtime()
            time_string = time.strftime("%Y-%m-%d %H:%M", local_time)
            print("%s %s has been processed." % (time_string, line.strip()))
    df = pd.DataFrame(all_data)
    df = df.transpose()
    df.to_csv(args.out_file, sep='\t')
    df_hist = moving_avg(df)
    df_hist.to_csv(args.out_file + '_hist_' + str(HIST_DAYS), sep='\t')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--file_list', type=str, required=True)
    parser.add_argument('-o', '--out_file', type=str, required=True)
    main(parser.parse_args())
