#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
remove flipped data from libsvm format data
flipped data means clicked event change to impression in latter logs
"""

import argparse
import time


def process_one_file(fpath, pos_set):
    with open(fpath) as fin, open(fpath+'_noFlip', 'w') as fout:
        for line in fin:
            content = line.strip().split()
            user_image = content[0]
            label = content[1]
            if label == '1':
                pos_set.add(user_image)
                fout.write(line)
            else:
                if user_image not in pos_set:
                    fout.write(line)


def main(args):
    file_list = []
    with open(args.file_list) as f:
        for line in f:
            file_list.append(line.strip())
    pos_set = set()
    start_time = time.time()
    for fpath in file_list:
        process_one_file(fpath, pos_set)
        end_time = time.time()
        print("%.2f minutes, processed %s" % ((end_time - start_time) / 60.0,
                                              fpath))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--file_list', type=str, required=True)
    main(parser.parse_args())
