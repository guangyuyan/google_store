#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
trainer
CUDA_VISIBLE_DEVICES=0 python trainer.py --model=v8 --train_data=train_256_compress.tfrecords --learning_rate=0.00001 --epochs=10 --data_per_valid 10000000 --valid_data valid_256_compress.tfrecords --model_name outputs/v8
"""


import tensorflow as tf
from build_model import build_model
# import threading


def main():
    flags = tf.app.flags.FLAGS
    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    model = build_model(flags)
    # coord = tf.train.Coordinator()
    model.build()
    with tf.Session(config=sess_config) as session:
        session.run([tf.global_variables_initializer(),
                     tf.local_variables_initializer(),
                     tf.tables_initializer(),
                     model.initializer()])
        model.train(session)
        # threads = []
        # for i in range(4):
        #     t = threading.Thread(target=model.train, args=(session, ))
        #     t.start()
        #     threads.append(t)
        # coord.join(threads)


if __name__ == "__main__":
    main()
