#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Build model
"""


import model_v1
import model_v2
import model_v3
import model_v4

import tensorflow as tf

tf.app.flags.DEFINE_bool("cross_bias", False, "use_bias in cross")
tf.app.flags.DEFINE_bool("renorm", False, "renorm in BN")
tf.app.flags.DEFINE_string("model", "v1", "model")
tf.app.flags.DEFINE_string("summaries_dir", "summaries", "summary dir")
tf.app.flags.DEFINE_string("train_data", "", "training data")
tf.app.flags.DEFINE_string("valid_data", "", "validating data")
tf.app.flags.DEFINE_string("dense_minmax_dir", "", "dense minmax summary file")
tf.app.flags.DEFINE_string("voc_dir", "", "vocabulary size summary dir")
tf.app.flags.DEFINE_integer("prebatch", 256, "prebatch size for tfrecord")
tf.app.flags.DEFINE_integer("batch_size", 4, "batch size")
tf.app.flags.DEFINE_integer("cross_layers", 6, "number of cross layers")
tf.app.flags.DEFINE_integer("embedding_size", 50, "embedding size")
tf.app.flags.DEFINE_integer("sparse_features", 26, "number of sparse features")
tf.app.flags.DEFINE_string("deep_layers", "1024,1024",
                           "sizes of deep layers, string delimited by comma")
tf.app.flags.DEFINE_integer("epochs", 10, "number of training epochs")
tf.app.flags.DEFINE_integer("patient_valid_passes", 2,
                            "number of valid passes before early stopping")
tf.app.flags.DEFINE_integer("data_per_valid", 41257216,
                            "number of data to train before validating")
tf.app.flags.DEFINE_integer("num_buckets", 100,
                            "number of buckets on continuous features")
tf.app.flags.DEFINE_integer("bucket_peak", 9, "tanh(9)=0.99999997")
tf.app.flags.DEFINE_integer("fm_order", 2, "FM net polynomial order")
tf.app.flags.DEFINE_integer("fm_rank", 2,
                            "Number of factors in low-rank appoximation.")
tf.app.flags.DEFINE_float("keep_prob", 1.0, "keep prob for dropout")


def build_model(flags):
    if flags.model == 'v1':
        model = model_v1.LockscreenDXLModel(flags)
    elif flags.model == 'v2':
        model = model_v2.DeepMultiplyModel(flags)
    elif flags.model == 'v3':
        model = model_v3.DeepCrossModel(flags)
    elif flags.model == 'v4':
        model = model_v4.LinearModel(flags)
    return model
