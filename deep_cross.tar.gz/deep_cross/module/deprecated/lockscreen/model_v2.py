#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep Multiple Model
  CUDA_VISIBLE_DEVICES=0 python trainer.py --model=$MODEL \
    --train_data /ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180215.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180216.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180217.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180218.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180219.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180220.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180221.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180222.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180223.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180224.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180225.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180226.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180227.libsvm.p256,/ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180228.libsvm.p256 \
    --epochs=10 --data_per_valid 100000000 \
    --valid_data /ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180301.libsvm.p256 \
    --dense_minmax_dir /ssd/users/xjfan/lockscreen/v2/0308_0308_data_20180228.libsvm.p256.summary \
    --voc_dir /ssd/users/xjfan/lockscreen/v2/dxl_0308_dict_m.txt.summary \
    --prebatch 256 --batch_size 4 \
    --model_name /ssd/criteo/outputs/lockscreen_${MODEL}.4 \
    --summaries_dir /ssd/criteo/summary/lockscreen_${MODEL}.4 \
    --learning_rate 0.0001 \
    --deep_layers 1024,1024 \

WARNING:tensorflow:Eval    3730432 loss=0.367525420541 roc = 0.788181900978 rate=76159.8766446
WARNING:tensorflow:A better loss 0.367525420541 found at /ssd/criteo/outputs/lockscreen_v2.6_best, steps=97655
"""


import tensorflow as tf

from model_v1 import LockscreenDXLModel


class DeepMultiplyModel(LockscreenDXLModel):
    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hiddens = [int(h) for h in self.flags.deep_layers.split(',')]
            return self.deep_multiply_net(inputs, hiddens, tf.nn.relu, False)
