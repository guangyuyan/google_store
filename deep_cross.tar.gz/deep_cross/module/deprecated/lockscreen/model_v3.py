#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 CloudBrain <byzhang@>
#
# Distributed under terms of the CloudBrain license.

"""
Deep Cross Model

WARNING:tensorflow:Eval    3730432 loss=0.368583776603 roc = 0.788618147373 rate=75722.9255363
WARNING:tensorflow:A better loss 0.368583776603 found at /ssd/criteo/outputs/lockscreen_v3.6_best, steps=97655
"""


import tensorflow as tf

from model_v1 import LockscreenDXLModel


class DeepCrossModel(LockscreenDXLModel):
    def build_network(self, features):
        with tf.device('/gpu:0'):
            inputs = self.build_features(features)
            hiddens = [int(h) for h in self.flags.deep_layers.split(',')]
            return self.deep_cross_net(inputs, hiddens, tf.nn.relu, False)
