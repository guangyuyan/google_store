#!/bin/bash -e
#
# build.sh
# Copyright (C) 2018 CloudBrain <chenp@>
#
# Distributed under terms of the CloudBrain license.
#

OS=${1}
TF_CONFIG=${2}
if [[ " centos ubuntu " != *" ${OS} "* ]] || \
   [[ " mkl legacy  " != *" ${TF_CONFIG} "* ]]; then
  echo "${0} <centos|ubuntu> [mkl|legacy]" 1>&2;
  exit 1
fi
case "${OS}" in
  centos) PKG="rpm";;
  ubuntu) PKG="deb";;
  *)
    echo "unkown packaging" >&2;
    exit 2;
    ;;
esac

set -e

DIR=$(dirname ${0})
TF_FILE="serving/Dockerfile.serving${TF_CONFIG:+.${TF_CONFIG}}"
TF_DOCKER="deepro.io/cloudbrain/tensorflow"
TF_TAG="serving-cpu-${OS}${TF_CONFIG:+-${TF_CONFIG}}"

jinja2 -Darch=${TF_CONFIG} Dockerfile.serving.j2 | tee ${TF_FILE}

docker build -t ${TF_DOCKER}:build-cpu-${OS} \
             -f ${DIR}/Dockerfile.${OS} \
             ${DIR}

docker build -t ${TF_DOCKER}:${TF_TAG} \
             -f ${DIR}/${TF_FILE} \
             --build-arg OS=${OS} \
             --build-arg PKG=${PKG} \
             ${DIR}

TF_EXTRACT=$(docker create ${TF_DOCKER}:${TF_TAG})
docker cp    ${TF_EXTRACT}:/usr/local/cloudbrain/. ${DIR}/serving/
docker rm -f ${TF_EXTRACT}
