#!/bin/bash
#
# start.sh
# Copyright (C) 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.
#

base=$(realpath $(dirname ${0})/..)
nohup \
env PATH=${base}/bin:${PATH} \
    LD_LIBRARY_PATH=${base}/lib64:${LD_LIBRARY_PATH} \
    OMP_NUM_THREADS=$(lscpu -p=CORE | grep -v ^# | wc -l) \
    OMP_WAIT_POLICY=PASSIVE \
    KMP_AFFINITY=granularity=fine,verbose,compact,1,0 \
tensorflow_model_server --port=9000 \
  --model_config_file=${base}/conf/models.conf \
  --platform_config_file=${base}/conf/platform.conf \
  > ${base}/logs/logfile.txt & echo $! > ${base}/.pid
