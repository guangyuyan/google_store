#!/bin/bash
#
# status.sh
# Copyright (C) 2018 CloudBrain <chenp@>
#
# Distributed under terms of the CloudBrain license.
#

base=$(realpath $(dirname ${0})/..)
if [[ -f ${base}/.pid ]]; then
  ps $(cat ${base}/.pid)
fi
