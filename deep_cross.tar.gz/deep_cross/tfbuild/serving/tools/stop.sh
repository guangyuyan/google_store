#!/bin/bash
#
# stop.sh
# Copyright (C) 2018 CloudBrain <tangkh@>
#
# Distributed under terms of the CloudBrain license.
#

base=$(realpath $(dirname ${0})/..)
if [[ -f ${base}/.pid ]]; then
  kill -9 $(cat ${base}/.pid) && rm -f ${base}/.pid
fi
