#!/bin/bash
#
# restart.sh
# Copyright (C) 2018 CloudBrain <chenp@>
#
# Distributed under terms of the CloudBrain license.
#

base=$(realpath $(dirname ${0})/..)
${base}/tools/stop.sh && ${base}/tools/start.sh
